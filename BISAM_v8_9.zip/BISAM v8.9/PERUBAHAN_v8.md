# BISAM v8.6 — Perubahan

1. **Kunci / buka soal** — Admin > *Kunci Soal*: kunci modul untuk semua peserta, atau buka kunci per peserta.
2. **Poin tidak dobel** — klik ganda "Selesai" dicegah; id pengerjaan unik; penulisan poin pakai transaksi.
3. **Nomor soal** — tiap kartu soal di Admin > Kelola Soal bernomor; form menampilkan "soal nomor N".
4. **Kunci otomatis** — setelah selesai mengerjakan modul, modul terkunci untuk peserta itu (hanya admin yang bisa membuka).
5. **Pauli & Kraepelin** tidak masuk poin/ranking.
6. **Navigasi** — "Ranking" dihapus dari menu depan; halaman baru `#/binjas` dan `#/psi` berisi penjelasan masing-masing.
7. **Gambar soal** — upload gambar di form soal (otomatis dikompres, disimpan di `questionImages`).
8. **Lokasi** — peta + koordinat di beranda & footer. ISI koordinat di `src/config/app.config.js` (`location`).
9. **Poin terbaik per modul** — mengerjakan ulang hanya memperbarui poin jika lebih besar. Total = jumlah poin terbaik tiap modul.

## Wajib setelah deploy
- Publish `src/firebase/firestore.rules.example` ke Firebase Console > Firestore > Rules (ada collection baru: `moduleLocks`, `userLocks`, `questionImages`).
- Admin > Kunci Soal > **Hitung Ulang Poin** (sekali) untuk merapikan poin lama yang dobel.
- Isi `latitude`/`longitude` di `app.config.js`.

## Tambahan (10–13)
10. Logo BISAM tampil di atas setiap soal (`public/assets/logo-soal.png`).
11. Soal tidak bisa diseleksi/disalin/diklik-kanan/diseret/dicetak; soal disembunyikan saat tab/jendela kehilangan fokus atau PrintScreen ditekan; ada watermark nama peserta. Catatan: screenshot tidak bisa 100% dicegah oleh browser.
12. Header halaman depan jadi menu hamburger di layar kecil (<=720px).
13. Hapus pengerjaan di Admin > Laporan langsung terhapus tanpa konfirmasi.

## Perbaikan buka kunci per peserta
- Buka kunci kini diverifikasi (dibaca ulang setelah dihapus) dan pesan error menampilkan penyebab asli (mis. permission-denied).
- Tombol "Buka semua milik <peserta>" untuk membuka semua kunci satu peserta sekaligus.

## Tampilan soal baru
- Logo BISAM jadi watermark besar transparan di balik kartu soal (`public/assets/logo-watermark.png`), label "SOAL n / total" biru, judul soal tebal, pilihan jawaban berbingkai biru muda.
- Header kuis memakai ikon berwarna + timer berikon stopwatch; ikon menu peserta berwarna (SVG, `src/config/icons.js`); menu "Ranking" diganti label "Rangking".
- v8.5: kartu soal dilebarkan penuh (batas 750px dihapus), watermark logo diperbesar & dibersihkan dari sudut hitam.
- v8.6: watermark logo berwarna biru muda & posisinya dikunci dari atas kartu (tidak bergeser saat jawaban/penjelasan muncul).
