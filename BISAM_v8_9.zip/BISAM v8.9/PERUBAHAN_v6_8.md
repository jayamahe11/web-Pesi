# BISAM v6.8 — Catatan Perubahan

Perbaikan tampilan (warna font & kontras) + perapihan Modul Ujian,
plus beberapa bug yang ditemukan saat pengecekan.

---

## 1. Warna font vs background

**Masalah:** judul halaman tidak terbaca di hampir semua halaman.

Penyebabnya dua aturan di `src/styles/pages.css`:

```css
.page-heading h1, .profile-title h1 { color: #ffffff !important; }
.modules-page h1 { color: #ffffff !important; }
```

Judul dipaksa putih, padahal area dashboard berlatar terang (#f6f8fc).
Selain itu `.stat-card p { color:#cbd5e1 }` membuat label "Modul /
Latihan selesai / Poin" hampir hilang di atas kartu putih.

**Perbaikan:** aturan tersebut dihapus, diganti file baru
`src/styles/theme.css` (dimuat paling akhir) berisi skala warna:

| Variabel      | Dipakai untuk               |
|---------------|-----------------------------|
| `--ink-900`   | judul                       |
| `--ink-700`   | teks isi                    |
| `--ink-500`   | keterangan / muted          |
| `--on-dark-*` | teks di atas blok gelap     |

Mode gelap (`body.dark`) ikut membalik variabel yang sama.

---

## 2. Modul Ujian — kotak kegedean

**Masalah:** kartu ujian jadi blok full-width bertumpuk, ikonnya melar
selebar kartu.

Penyebabnya class `.module-catalog-grid` hanya punya `align-items:
stretch` — `display: grid`-nya tidak pernah ditulis. Ikonnya juga hanya
diberi `background` tanpa `width`/`height`.

**Perbaikan:** `src/pages/user/ujian.page.js` ditulis ulang memakai
struktur dan class yang sama dengan Modul Latihan (`module-card`,
`module-icon`), plus baris meta untuk jumlah soal dan durasi. Kartu bisa
diklik di mana saja; tombol "Mulai Ujian" memakai `stopPropagation`.

---

## 3. Halaman Quiz

Keempat pilihan jawaban sebelumnya balok biru pekat semua, terlihat
seperti sudah terpilih. Sekarang netral (putih + border), lalu hijau
untuk jawaban benar dan merah untuk yang salah setelah dijawab.

`quiz.page.js`: `button.style.background = '#16a34a'` diganti class
`answer-btn--correct` / `answer-btn--wrong` agar warna diatur dari CSS.

---

## 4. Tampilan di HP  ← penting untuk deploy

Markup `.mobile-nav` sudah ada di `dashboard-layout.js`, tapi CSS-nya
hanya `display: none` dan tidak pernah diaktifkan. Akibatnya di HP
sidebar 252px tetap memakan layar dan konten terjepit jadi kolom sempit.

Sekarang di bawah 900px: sidebar disembunyikan, nav bawah aktif
(bisa di-scroll horizontal), konten diberi padding bawah.

---

## 5. Bug yang ditemukan di luar permintaan

**a. Halaman admin "Soal" mati total.**
`dataService.getQuestions()` dipanggil 4x di `questions.page.js` tapi
method-nya tidak ada di `data.service.js`. Halaman melempar error dan
router gagal render. → method `getQuestions()` ditambahkan.

**b. Halaman soal sangat berat.**
Setelah bisa jalan, 725 soal dirender sekaligus (tinggi DOM 130.000px).
→ ditambah kotak pencarian + 25 soal per halaman + tombol "Muat lagi".
Ukuran DOM turun dari 530 KB ke 27 KB.

**c. "undefined" di Laporan & Pengaturan.**
Default `settings` di `admin.service.js` hanya berisi
`defaultParticipantType`, padahal halaman membaca `passingScore`,
`autoAdvanceDelayMs`, `registrationOpen`, `maintenanceMode`.
→ default diisi (batas lulus 60, auto-next 500ms) dan pemulihan dari
localStorage diubah jadi *merge*, bukan *replace*, supaya data lama
tetap mendapat key baru.

**d. Durasi ujian salah.**
`modules.data.js` menyetel TIU/TWK/TKD ke 50 menit, kartu menampilkan
30 menit. → sekarang membaca `durationMinutes` dari data, dan daftar
modul ujian mengimpor `EXAM_MODULE_IDS` yang memang sudah diekspor.

---

## Yang BELUM dikerjakan / perlu diputuskan

1. **Mode ujian masih membocorkan kunci jawaban.** Di `/quiz`, jawaban
   benar dan pembahasan langsung muncul setiap kali peserta menjawab,
   sama seperti mode latihan. Untuk simulasi ujian sebaiknya ditahan
   sampai selesai. Ini perubahan perilaku, bukan tampilan, jadi
   sengaja tidak diubah sendiri.

2. **Path logo saat deploy.** `APP_CONFIG.logoUrl` di
   `src/config/app.config.js` menunjuk ke `/public/assets/logo-bisam.png`.
   Ini benar kalau seluruh folder di-deploy apa adanya (GitHub Pages,
   Netlify dengan publish directory = root). Kalau host memperlakukan
   `public/` sebagai root (Vercel dengan setting tertentu, atau nanti
   pindah ke Vite), path harus jadi `/assets/logo-bisam.png`. Berlaku
   juga untuk gambar soal di `public/assets/questions/`.

3. **Data masih localStorage.** `data-source.config.js` masih
   `provider: 'mock'`. Ranking dan riwayat belum sinkron antar
   perangkat sampai Firebase diaktifkan.
