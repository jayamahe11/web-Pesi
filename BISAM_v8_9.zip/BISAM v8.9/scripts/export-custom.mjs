#!/usr/bin/env node
/**
 * EXPORT-CUSTOM — Web (Firestore) -> kode
 * ------------------------------------------------------------------
 * Mengambil soal & modul yang dibuat manual lewat web (collection
 * `customQuestions`, `customModules`, gambar di `questionImages`) lalu
 * menulisnya sebagai kode ke `src/data/questions/custom.js`.
 * Gambar disimpan sebagai file di `public/assets/questions/custom/`.
 *
 * Pakai:
 *   npm run export:custom -- ./serviceAccountKey.json
 *
 * Opsi:
 *   --mirror         file dibuat persis sama dengan Firestore (soal yang sudah
 *                    dihapus di web ikut hilang dari file). TANPA opsi ini,
 *                    soal yang sudah ada di file TIDAK PERNAH dihapus: file
 *                    hanya ditambah/diperbarui (aman, tidak ada yang hilang).
 *   --inline-images  gambar ditulis sebagai data URL di dalam custom.js
 *                    (tanpa file gambar terpisah).
 */
import { mkdirSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import { initFirestore, parseArgs } from './lib/admin-init.mjs';
import { buildCustomFileSource } from '../src/utils/custom-export.js';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILE = path.join(ROOT, 'src', 'data', 'questions', 'custom.js');
const IMG_DIR = path.join(ROOT, 'public', 'assets', 'questions', 'custom');
const IMG_URL_PREFIX = '/public/assets/questions/custom';

const EXT = { 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };

function safeName(id) {
  return String(id).replace(/[^a-zA-Z0-9_-]/g, '_');
}

async function readExisting() {
  try {
    const mod = await import(pathToFileURL(FILE).href + `?t=${Date.now()}`);
    return { modules: mod.CUSTOM_MODULES ?? [], questions: mod.CUSTOM_QUESTIONS ?? [] };
  } catch {
    return { modules: [], questions: [] };
  }
}

async function main() {
  const { flags, credentialPath } = parseArgs();
  const mirror = flags.has('--mirror');
  const inline = flags.has('--inline-images');

  console.log('BISAM — Export soal manual: Firestore -> kode\n==============================================\n');
  const db = await initFirestore(credentialPath, 'export:custom');

  const [modSnap, qSnap, imgSnap] = await Promise.all([
    db.collection('customModules').get(),
    db.collection('customQuestions').get(),
    db.collection('questionImages').get(),
  ]);

  const images = new Map(imgSnap.docs.map((d) => [d.id, d.data().data]));
  const remoteModules = modSnap.docs.map((d) => ({ ...d.data(), id: d.id }));
  const remoteQuestions = [];

  if (!inline) mkdirSync(IMG_DIR, { recursive: true });

  for (const d of qSnap.docs) {
    const q = { ...d.data(), id: d.id };
    if (q.hasImage && images.get(d.id)) {
      const dataUrl = images.get(d.id);
      if (inline) {
        q.image = dataUrl;
      } else {
        const match = /^data:(image\/[a-z+.-]+);base64,(.*)$/i.exec(dataUrl);
        if (match) {
          const ext = EXT[match[1].toLowerCase()] ?? 'jpg';
          const name = `${safeName(d.id)}.${ext}`;
          writeFileSync(path.join(IMG_DIR, name), Buffer.from(match[2], 'base64'));
          q.image = `${IMG_URL_PREFIX}/${name}`;
        } else {
          q.image = dataUrl;
        }
      }
    }
    remoteQuestions.push(q);
  }

  let modules = remoteModules;
  let questions = remoteQuestions;
  let kept = 0;

  if (!mirror) {
    const existing = await readExisting();
    const remoteModIds = new Set(remoteModules.map((m) => String(m.id)));
    const remoteQIds = new Set(remoteQuestions.map((q) => String(q.id)));
    const keepMods = existing.modules.filter((m) => !remoteModIds.has(String(m.id)));
    const keepQs = existing.questions.filter((q) => !remoteQIds.has(String(q.id)));
    kept = keepMods.length + keepQs.length;
    modules = [...keepMods, ...remoteModules];
    questions = [...keepQs, ...remoteQuestions];
  }

  writeFileSync(FILE, buildCustomFileSource({ modules, questions }), 'utf-8');

  console.log(`Dari Firestore : ${remoteModules.length} modul, ${remoteQuestions.length} soal`);
  if (!mirror) console.log(`Dipertahankan dari file lama (tidak ada di Firestore): ${kept}`);
  console.log(`Ditulis ke     : src/data/questions/custom.js  (${modules.length} modul, ${questions.length} soal)`);
  console.log(inline ? 'Gambar         : disimpan inline (data URL)' : `Gambar         : ${IMG_DIR}`);
  process.exit(0);
}

main().catch((error) => {
  console.error('\n[export:custom] Gagal:', error);
  process.exit(1);
});
