#!/usr/bin/env node
/**
 * SEED FIREBASE — BISAM
 * ------------------------------------------------------------------
 * Mengirim seluruh katalog modul dan bank soal (di `src/firebase/seed/*.json`)
 * ke Firestore project Firebase kamu, memakai Firebase Admin SDK.
 *
 * PERSIAPAN:
 * 1. Di Firebase Console > Project Settings > Service Accounts, klik
 *    "Generate new private key". File JSON hasil download JANGAN dikomit ke
 *    git — simpan misalnya sebagai `serviceAccountKey.json` di root project.
 * 2. Install dependency admin SDK (sekali saja):
 *      npm install firebase-admin --save-dev
 * 3. Jalankan:
 *      node scripts/seed-firebase.mjs ./serviceAccountKey.json
 *    atau set env GOOGLE_APPLICATION_CREDENTIALS ke path file tsb lalu:
 *      node scripts/seed-firebase.mjs
 *
 * Script ini AMAN dijalankan berkali-kali (idempotent): setiap dokumen
 * ditulis dengan id yang sama sehingga menjalankan ulang hanya menimpa
 * (bukan menduplikasi) data.
 *
 * Collection yang di-seed:
 *   modules             <- src/firebase/seed/modules.json
 *   questions           <- src/firebase/seed/questions-public.json (tanpa jawaban)
 *   answerKeys          <- src/firebase/seed/answer-keys-private.json (jawaban+pembahasan)
 *   announcements, ranking, history, participants, schedules, users
 *                        <- seed kosong ([]), dilewati jika file kosong
 */

import { readFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import process from 'node:process';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SEED_DIR = path.join(__dirname, '..', 'src', 'firebase', 'seed');

const CREDENTIAL_ARG = process.argv.slice(2).find((a) => !a.startsWith('--'));
const PRUNE = process.argv.includes('--prune');

async function loadAdmin() {
  try {
    return await import('firebase-admin');
  } catch (error) {
    console.error(
      '\n[seed-firebase] Package "firebase-admin" belum terpasang.\n' +
      'Jalankan dulu: npm install firebase-admin --save-dev\n'
    );
    process.exit(1);
  }
}

function loadServiceAccount() {
  const credPath = CREDENTIAL_ARG || process.env.GOOGLE_APPLICATION_CREDENTIALS;

  if (!credPath) {
    console.error(
      '\n[seed-firebase] Tidak ada service account key.\n' +
      'Jalankan salah satu:\n' +
      '  node scripts/seed-firebase.mjs ./serviceAccountKey.json\n' +
      '  GOOGLE_APPLICATION_CREDENTIALS=./serviceAccountKey.json node scripts/seed-firebase.mjs\n'
    );
    process.exit(1);
  }

  const resolved = path.resolve(process.cwd(), credPath);
  if (!existsSync(resolved)) {
    console.error(`\n[seed-firebase] File service account tidak ditemukan: ${resolved}\n`);
    process.exit(1);
  }

  return JSON.parse(readFileSync(resolved, 'utf-8'));
}

function readSeed(filename) {
  const filePath = path.join(SEED_DIR, filename);
  if (!existsSync(filePath)) return [];
  const raw = readFileSync(filePath, 'utf-8').trim();
  if (!raw) return [];
  return JSON.parse(raw);
}

async function seedCollection(db, admin, collectionName, docs, idField = 'id') {
  if (!docs.length) {
    console.log(`  - ${collectionName}: kosong, dilewati`);
    return;
  }

  const BATCH_LIMIT = 400; // di bawah limit 500 operasi per batch Firestore
  let written = 0;

  for (let i = 0; i < docs.length; i += BATCH_LIMIT) {
    const batch = db.batch();
    const chunk = docs.slice(i, i + BATCH_LIMIT);

    chunk.forEach((item) => {
      const docId = String(item[idField]);
      const ref = db.collection(collectionName).doc(docId);
      batch.set(ref, item, { merge: true });
    });

    await batch.commit();
    written += chunk.length;
  }

  console.log(`  - ${collectionName}: ${written} dokumen ditulis`);
}


/**
 * --prune : hapus dokumen soal lama di Firestore yang TIDAK ada lagi di seed
 * (collection `questions` dan `answerKeys`). Dipakai saat bank soal diganti
 * total supaya tidak tersisa soal lama. Soal buatan admin (`customQuestions`)
 * tidak pernah disentuh.
 */
async function pruneCollection(db, collectionName, keepIds) {
  const snap = await db.collection(collectionName).get();
  const stale = snap.docs.filter((d) => !keepIds.has(d.id));
  for (let i = 0; i < stale.length; i += 400) {
    const batch = db.batch();
    stale.slice(i, i + 400).forEach((d) => batch.delete(d.ref));
    await batch.commit();
  }
  console.log(`  - ${collectionName}: ${stale.length} dokumen lama dihapus`);
}

async function main() {
  console.log('BISAM — Seed Firebase\n======================\n');

  const admin = await loadAdmin();
  const serviceAccount = loadServiceAccount();

  admin.default.initializeApp({
    credential: admin.default.credential.cert(serviceAccount),
  });

  const db = admin.default.firestore();

  console.log(`Project: ${serviceAccount.project_id}\n`);
  console.log('Mengirim data ke Firestore...');

  await seedCollection(db, admin, 'modules', readSeed('modules.json'));
  await seedCollection(db, admin, 'questions', readSeed('questions-public.json'));
  await seedCollection(db, admin, 'answerKeys', readSeed('answer-keys-private.json'));
  if (PRUNE) {
    console.log('\nMembersihkan soal lama (--prune)...');
    const keep = new Set(readSeed('questions-public.json').map((q) => String(q.id)));
    await pruneCollection(db, 'questions', keep);
    await pruneCollection(db, 'answerKeys', keep);
  }
  await seedCollection(db, admin, 'announcements', readSeed('announcements.json'));
  await seedCollection(db, admin, 'rankings', readSeed('ranking.json'));
  await seedCollection(db, admin, 'schedules', readSeed('schedules.json'));
  await seedCollection(db, admin, 'users', readSeed('users.json'));

  console.log('\nSelesai. Ubah provider di src/config/data-source.config.js menjadi "firebase" untuk memakai data ini.');
  process.exit(0);
}

main().catch((error) => {
  console.error('\n[seed-firebase] Gagal:', error);
  process.exit(1);
});
