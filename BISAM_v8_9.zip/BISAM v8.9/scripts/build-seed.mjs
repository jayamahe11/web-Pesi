#!/usr/bin/env node
/**
 * BUILD-SEED — kode -> src/firebase/seed/*.json
 * ------------------------------------------------------------------
 * Membuat ulang file seed dari bank soal bawaan di kode
 * (src/data/modules.data.js + src/data/questions/*.js):
 *   modules.json              <- MODULES
 *   questions-public.json     <- soal tanpa answer/explanation
 *   answer-keys-private.json  <- id + moduleId + answer + explanation
 *
 * Jalankan setiap habis mengubah file di src/data/questions/*.js, lalu
 *   npm run seed:firebase -- ./serviceAccountKey.json
 * untuk mengirimnya ke Firestore. Soal MANUAL (customQuestions) tidak
 * tersentuh oleh langkah ini.
 */
import { writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const SEED = path.join(ROOT, 'src', 'firebase', 'seed');
const load = (p) => import(pathToFileURL(path.join(ROOT, p)).href);

const { MODULES } = await load('src/data/modules.data.js');
const { QUESTIONS } = await load('src/data/questions.data.js');

const ids = new Set();
for (const q of QUESTIONS) {
  if (ids.has(q.id)) {
    console.error(`ID soal dobel: ${q.id} (${q.moduleId}). Perbaiki dulu.`);
    process.exit(1);
  }
  ids.add(q.id);
}

const pub = QUESTIONS.map(({ answer, explanation, ...rest }) => rest);
const keys = QUESTIONS.map(({ id, moduleId, answer, explanation }) => ({ id, moduleId, answer, explanation }));

writeFileSync(path.join(SEED, 'modules.json'), JSON.stringify(MODULES, null, 2));
writeFileSync(path.join(SEED, 'questions-public.json'), JSON.stringify(pub, null, 2));
writeFileSync(path.join(SEED, 'answer-keys-private.json'), JSON.stringify(keys, null, 2));

console.log(`modules.json: ${MODULES.length} | questions-public.json: ${pub.length} | answer-keys-private.json: ${keys.length}`);
