#!/usr/bin/env node
/**
 * IMPORT-CUSTOM — kode -> web (Firestore)
 * ------------------------------------------------------------------
 * Membaca `src/data/questions/custom.js` lalu menulis isinya ke Firestore
 * (`customModules`, `customQuestions`, dan gambar ke `questionImages`)
 * supaya tampil di web dan bisa diedit lagi lewat Admin > Kelola Soal.
 *
 * AMAN dijalankan berulang: dokumen ditulis dengan id yang sama
 * (menimpa, bukan menggandakan). Script ini TIDAK menghapus apa pun di
 * Firestore, dan TIDAK menyentuh soal bawaan (`questions`/`answerKeys`).
 *
 * Pakai:
 *   npm run import:custom -- ./serviceAccountKey.json
 *   npm run import:custom -- ./serviceAccountKey.json --dry    (cek saja)
 */
import { readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import { initFirestore, parseArgs } from './lib/admin-init.mjs';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const FILE = path.join(ROOT, 'src', 'data', 'questions', 'custom.js');

const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif' };

function imageToDataUrl(image) {
  if (!image) return null;
  if (image.startsWith('data:')) return image;

  // "/public/assets/..." -> <root>/public/assets/...
  const rel = image.replace(/^\/+/, '');
  const file = path.join(ROOT, rel);
  if (!existsSync(file)) {
    console.warn(`  ! file gambar tidak ditemukan: ${image}`);
    return null;
  }
  const ext = path.extname(file).slice(1).toLowerCase();
  return `data:${MIME[ext] ?? 'image/jpeg'};base64,${readFileSync(file).toString('base64')}`;
}

async function main() {
  const { flags, credentialPath } = parseArgs();
  const dry = flags.has('--dry');

  const mod = await import(pathToFileURL(FILE).href);
  const modules = mod.CUSTOM_MODULES ?? [];
  const questions = mod.CUSTOM_QUESTIONS ?? [];

  console.log(`BISAM — Import soal manual: kode -> Firestore${dry ? ' (DRY RUN)' : ''}\n===============================================\n`);
  console.log(`Di file custom.js: ${modules.length} modul, ${questions.length} soal\n`);

  const bad = questions.filter((q) => !q.id || !q.moduleId || !Array.isArray(q.options) || q.options.length < 2 || !q.answer);
  if (bad.length) {
    console.error('Soal berikut tidak lengkap (butuh id, moduleId, options >=2, answer):');
    bad.forEach((q) => console.error('  -', q.id ?? '(tanpa id)', String(q.question ?? '').slice(0, 60)));
    process.exit(1);
  }

  if (dry) {
    console.log('Dry run: tidak ada yang ditulis.');
    process.exit(0);
  }

  const db = await initFirestore(credentialPath, 'import:custom');
  const FieldValue = (await import('firebase-admin')).default.firestore.FieldValue;

  let batch = db.batch();
  let ops = 0;
  const flush = async () => {
    if (ops) await batch.commit();
    batch = db.batch();
    ops = 0;
  };
  const add = async (ref, data) => {
    batch.set(ref, data, { merge: true });
    if (++ops >= 400) await flush();
  };

  for (const m of modules) {
    const { id, custom, ...data } = m;
    await add(db.collection('customModules').doc(String(id)), { ...data, engine: 'quiz', updatedAt: FieldValue.serverTimestamp() });
  }

  let withImage = 0;
  for (const q of questions) {
    const { id, custom, image, ...data } = q;
    const dataUrl = imageToDataUrl(image);
    await add(db.collection('customQuestions').doc(String(id)), {
      ...data,
      hasImage: Boolean(dataUrl),
      updatedAt: FieldValue.serverTimestamp(),
    });
    if (dataUrl) {
      withImage += 1;
      // Gambar di dokumen terpisah (sama seperti saat diupload lewat web).
      await add(db.collection('questionImages').doc(String(id)), { data: dataUrl, updatedAt: FieldValue.serverTimestamp() });
    }
  }
  await flush();

  console.log(`Ditulis: ${modules.length} modul, ${questions.length} soal (${withImage} bergambar).`);
  console.log('Buka web > Admin > Kelola Soal (muat ulang) untuk melihat hasilnya.');
  process.exit(0);
}

main().catch((error) => {
  console.error('\n[import:custom] Gagal:', error);
  process.exit(1);
});
