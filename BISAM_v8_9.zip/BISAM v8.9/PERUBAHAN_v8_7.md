# BISAM v8.7 — Soal manual ⇄ kode

Soal yang diketik manual lewat web (Admin > Kelola Soal) disimpan di Firestore
(`customQuestions`, `customModules`, gambar di `questionImages`), terpisah dari
soal bawaan di kode. Mulai v8.7 soal manual itu punya "versi kode" juga:

    src/data/questions/custom.js     (CUSTOM_MODULES + CUSTOM_QUESTIONS)

## Alur

| Mau apa | Cara |
|---|---|
| Soal manual di web -> jadi kode | Tombol **⬇ Unduh kode soal manual** (Admin > Kelola Soal), simpan hasilnya sebagai `src/data/questions/custom.js`. Atau: `npm run export:custom -- ./serviceAccountKey.json` (gambar ikut jadi file di `public/assets/questions/custom/`). |
| Kode -> web | `npm run import:custom -- ./serviceAccountKey.json` (tambah `--dry` untuk cek dulu). Soal di `custom.js` muncul lagi di Kelola Soal dan tetap bisa diedit. |
| Update soal bawaan (file `src/data/questions/*.js`) | `npm run build:seed` lalu `npm run seed:firebase -- ./serviceAccountKey.json`. |

## Aturan aman

- `seed:firebase` hanya menulis `modules`, `questions`, `answerKeys`, dll. Tidak pernah menyentuh `customQuestions`, jadi soal manual tidak tertimpa.
- `import:custom` hanya menulis/menimpa dokumen dengan id yang sama, tidak menghapus apa pun.
- `export:custom` default-nya **menambah/memperbarui** isi `custom.js` (soal yang sudah ada di file tidak hilang walau sudah dihapus di web). Pakai `--mirror` kalau mau file persis sama dengan web, `--inline-images` kalau gambar mau ditanam di dalam `custom.js`.
- Boleh juga menulis soal langsung di `custom.js` (id unik, mis. `"q-ku-001"`), lalu `import:custom`.
- Mode `mock` (tanpa Firebase) ikut membaca `custom.js`, jadi soal manual tetap tampil saat development lokal.

## Lain-lain

- `scripts/build-seed.mjs` — membuat ulang `src/firebase/seed/*.json` dari kode (hasilnya identik dengan seed v8.6 saat dicek).
- `scripts/lib/admin-init.mjs` — helper bersama script Firebase.
- `src/utils/custom-export.js` — pembuat isi `custom.js` (dipakai tombol di web dan script Node, jadi formatnya selalu sama).
