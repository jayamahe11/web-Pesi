# BISAM v8.8 — Modul Ujian TWK#2, TIU#2, TKP#2

Tiga modul ujian baru (level sulit), masing-masing 50 soal. Modul lama (TIU, TWK, TKD)
tidak diubah sama sekali.

| Modul | id | ID soal | File |
|---|---|---|---|
| TWK#2 | `twk2` | 2601-2650 | `src/data/questions/twk2.js` |
| TIU#2 | `tiu2` | 2701-2750 | `src/data/questions/tiu2.js` |
| TKP#2 | `tkp2` | 2801-2850 | `src/data/questions/tkp2.js` |

- Muncul di halaman **Ujian** (terdaftar di `EXAM_MODULE_IDS`).
- Seed Firebase sudah dibuat ulang (`npm run build:seed`): 20 modul, 889 soal.
  Kirim ke Firestore dengan `npm run seed:firebase -- ./serviceAccountKey.json`.
- Soal manual buatan admin (`customQuestions`) tidak tersentuh.
- TKP#2: jawaban terbaik = pilihan bernilai 5. Skor tiap pilihan (1-5) ada di pembahasan.
  Aplikasi menghitung benar/salah berdasarkan pilihan terbaik saja.
- Durasi: TWK#2 50 menit, TIU#2 60 menit, TKP#2 50 menit (ubah di `modules.data.js`).

## Perbaikan 8.8.1 — modul baru tampil "0 soal"

Aplikasi mengambil daftar soal dari data lama (localStorage browser atau Firestore),
sehingga modul baru yang hanya ada di kode tampil 0 soal. Sekarang `admin.service.js`
otomatis menambahkan soal dari kode untuk modul yang belum punya soal sama sekali
(`mergeCodeQuestionsForNewModules`). Soal modul lama tidak disentuh, jadi soal yang
sudah dihapus/diedit admin tidak muncul kembali. Seed Firebase tetap disarankan agar
data di Firestore ikut lengkap: `npm run seed:firebase -- ./serviceAccountKey.json`.
