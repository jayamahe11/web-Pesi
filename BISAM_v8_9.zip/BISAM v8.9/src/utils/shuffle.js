/**
 * SHUFFLE.JS
 * ------------------------------------------------------------------
 * Fisher-Yates shuffle — mengacak urutan array tanpa mengubah array asli.
 * Dipakai supaya setiap peserta (dan setiap kali mengerjakan ulang)
 * mendapat urutan soal & urutan pilihan jawaban yang berbeda-beda,
 * sehingga tidak bisa saling contek lewat "soal nomor sekian".
 */
export function shuffleArray(list) {
  const result = [...list];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

/**
 * Mengacak urutan soal DAN urutan pilihan jawabannya masing-masing,
 * lalu menyesuaikan huruf jawaban (answer) agar tetap menunjuk ke
 * pilihan yang benar setelah diacak.
 */
export function shuffleQuestions(questions) {
  return shuffleArray(questions).map((item) => {
    if (!Array.isArray(item.options)) return item;

    const correctIndex = item.options.findIndex(
      (_, idx) => String.fromCharCode(65 + idx) === String(item.answer).toUpperCase()
    );

    const optionEntries = item.options.map((text, idx) => ({
      text,
      isCorrect: idx === correctIndex,
    }));

    const shuffledEntries = shuffleArray(optionEntries);
    const newAnswerIndex = shuffledEntries.findIndex((entry) => entry.isCorrect);

    return {
      ...item,
      options: shuffledEntries.map((entry) => entry.text),
      answer: String.fromCharCode(65 + (newAnswerIndex === -1 ? 0 : newAnswerIndex)),
    };
  });
}
