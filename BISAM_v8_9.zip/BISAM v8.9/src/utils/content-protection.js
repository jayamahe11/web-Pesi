/**
 * Pelindung konten soal (dipakai halaman kuis/ujian).
 *
 * Yang dilakukan:
 *  - menonaktifkan seleksi teks, salin/potong, klik kanan, seret gambar;
 *  - memblokir pintasan salin/simpan/cetak/inspeksi dan tombol PrintScreen;
 *  - menyembunyikan soal saat jendela kehilangan fokus / tab disembunyikan
 *    (banyak alat tangkap layar membuat jendela blur) dan saat dicetak;
 *  - menampilkan watermark nama peserta di atas soal agar bocoran bisa
 *    dilacak.
 *
 * BATASAN: browser TIDAK bisa benar-benar mencegah screenshot (tombol
 * screenshot HP/OS, alat perekam, atau foto dari kamera lain). Ini
 * pencegah untuk pemakaian biasa, bukan perlindungan mutlak.
 */
export function enableContentProtection({ root, watermark = '' } = {}) {
  if (!root) return () => {};

  root.classList.add('protected-content');

  if (watermark) {
    const text = String(watermark).replace(/[<>&"']/g, '');
    const svg =
      `<svg xmlns='http://www.w3.org/2000/svg' width='260' height='170'>` +
      `<text x='20' y='95' transform='rotate(-24 130 85)' font-family='Arial' ` +
      `font-size='15' fill='rgba(15,23,42,0.07)'>${text}</text></svg>`;
    root.style.setProperty('--watermark', `url("data:image/svg+xml,${encodeURIComponent(svg)}")`);
    root.classList.add('protected-content--watermark');
  }

  const stop = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const clearClipboard = () => {
    try {
      navigator.clipboard?.writeText?.('Soal dilindungi — tidak dapat disalin.');
    } catch (_) { /* diabaikan */ }
  };

  const hide = () => root.classList.add('is-hidden-secure');
  const show = () => {
    if (document.hasFocus() && !document.hidden) {
      root.classList.remove('is-hidden-secure');
    }
  };

  const onKeyDown = (event) => {
    const key = String(event.key || '').toLowerCase();
    const ctrl = event.ctrlKey || event.metaKey;

    if (key === 'printscreen' || event.code === 'PrintScreen') {
      clearClipboard();
      hide();
      setTimeout(show, 1500);
      stop(event);
      return;
    }

    // Mac: Cmd+Shift+3/4/5 (tangkap layar)
    if (event.metaKey && event.shiftKey && ['3', '4', '5'].includes(key)) {
      hide();
      setTimeout(show, 1500);
      return;
    }

    if (
      (ctrl && ['c', 'x', 'a', 's', 'p', 'u'].includes(key)) ||
      (ctrl && event.shiftKey && ['i', 'j', 'c', 's'].includes(key)) ||
      key === 'f12'
    ) {
      stop(event);
    }
  };

  const onKeyUp = (event) => {
    if (String(event.key).toLowerCase() === 'printscreen') {
      clearClipboard();
    }
  };

  document.addEventListener('contextmenu', stop, true);
  document.addEventListener('copy', stop, true);
  document.addEventListener('cut', stop, true);
  root.addEventListener('dragstart', stop, true);
  root.addEventListener('selectstart', stop, true);
  document.addEventListener('keydown', onKeyDown, true);
  document.addEventListener('keyup', onKeyUp, true);
  window.addEventListener('blur', hide);
  window.addEventListener('focus', show);
  document.addEventListener('visibilitychange', () => (document.hidden ? hide() : show()));
  window.addEventListener('beforeprint', hide);
  window.addEventListener('afterprint', show);

  return function disable() {
    root.classList.remove('protected-content', 'protected-content--watermark', 'is-hidden-secure');
    document.removeEventListener('contextmenu', stop, true);
    document.removeEventListener('copy', stop, true);
    document.removeEventListener('cut', stop, true);
    root.removeEventListener('dragstart', stop, true);
    root.removeEventListener('selectstart', stop, true);
    document.removeEventListener('keydown', onKeyDown, true);
    document.removeEventListener('keyup', onKeyUp, true);
    window.removeEventListener('blur', hide);
    window.removeEventListener('focus', show);
    window.removeEventListener('beforeprint', hide);
    window.removeEventListener('afterprint', show);
  };
}
