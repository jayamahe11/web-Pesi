/**
 * CUSTOM-EXPORT.JS
 * ------------------------------------------------------------------
 * Mengubah soal & modul BUATAN ADMIN (yang dibuat lewat web, disimpan di
 * Firestore: customQuestions / customModules) menjadi file kode
 * `src/data/questions/custom.js`.
 *
 * File ini murni JavaScript (tanpa DOM/Node API) sehingga dipakai oleh:
 *   - tombol "Unduh kode soal manual" di Admin > Kelola Soal  (browser)
 *   - scripts/export-custom.mjs                                (Node)
 * Jadi format file hasilnya selalu sama.
 */

export const CUSTOM_FILE_PATH = 'src/data/questions/custom.js';

// Field yang tidak ikut ditulis ke file (hanya status internal aplikasi).
const SKIP_KEYS = new Set(['custom', 'hasImage', 'updatedAt', 'createdAt']);

const QUESTION_ORDER = ['id', 'moduleId', 'category', 'question', 'options', 'answer', 'explanation', 'image'];
const MODULE_ORDER = ['id', 'title', 'icon', 'description', 'engine', 'itemCountLabel', 'typeLabel', 'durationMinutes', 'active'];

function pickInOrder(item, order) {
  const out = {};
  order.forEach((key) => {
    if (item[key] !== undefined && item[key] !== null && !SKIP_KEYS.has(key)) out[key] = item[key];
  });
  Object.keys(item).forEach((key) => {
    if (!(key in out) && !SKIP_KEYS.has(key) && item[key] !== undefined && item[key] !== null) {
      out[key] = item[key];
    }
  });
  return out;
}

export function cleanQuestion(question) {
  return pickInOrder(question, QUESTION_ORDER);
}

export function cleanModule(module) {
  const cleaned = pickInOrder(module, MODULE_ORDER);
  cleaned.engine = 'quiz';
  return cleaned;
}

const byId = (a, b) => String(a.id).localeCompare(String(b.id));

/**
 * @param {{modules?: object[], questions?: object[], generatedAt?: string}} data
 * @returns {string} isi file custom.js
 */
export function buildCustomFileSource({ modules = [], questions = [], generatedAt = new Date().toISOString() } = {}) {
  const mods = [...modules].map(cleanModule).sort(byId);
  const qs = [...questions].map(cleanQuestion).sort(byId);

  return `/**
 * CUSTOM.JS  —  SOAL & MODUL BUATAN ADMIN (versi kode)
 * ------------------------------------------------------------------
 * File ini dibuat OTOMATIS dari soal yang diketik manual lewat web
 * (Admin > Kelola Soal / Kelola Modul). Jangan khawatir soal manual hilang:
 * selama file ini ikut tersimpan, semua soal manual ada di dalam kode.
 *
 * Arah sinkronisasi:
 *   Web (Firestore) -> kode : npm run export:custom   atau tombol "Unduh kode soal manual"
 *   Kode -> Web (Firestore) : npm run import:custom
 *
 * Kamu juga boleh menambah/mengedit soal langsung di file ini, lalu jalankan
 * \`npm run import:custom\` supaya muncul di web. Pakai id yang unik
 * (mis. "q-ku-001") — id yang sama akan MENIMPA soal dengan id itu.
 *
 * Field "image" boleh berisi path file (mis. "/public/assets/questions/custom/q-ku-001.jpg")
 * atau data URL (data:image/...;base64,...).
 *
 * Terakhir dibuat : ${generatedAt}
 * Jumlah          : ${mods.length} modul, ${qs.length} soal
 */

export const CUSTOM_MODULES = ${JSON.stringify(mods, null, 2)};

export const CUSTOM_QUESTIONS = ${JSON.stringify(qs, null, 2)};
`;
}
