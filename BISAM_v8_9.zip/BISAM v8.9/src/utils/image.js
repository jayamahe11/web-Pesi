/**
 * Kompres gambar dari <input type="file"> menjadi data URL JPEG yang cukup
 * kecil untuk disimpan di Firestore (batas 1 MB per dokumen).
 *
 * - Sisi terpanjang dibatasi `maxSize` px.
 * - Kualitas diturunkan bertahap sampai ukurannya <= `maxBytes`.
 * - Latar transparan (PNG) diberi warna putih supaya tidak jadi hitam.
 */
export async function compressImageFile(
  file,
  { maxSize = 1000, maxBytes = 320 * 1024 } = {}
) {
  if (!file || !file.type?.startsWith('image/')) {
    throw new Error('File harus berupa gambar (JPG/PNG/WebP).');
  }

  const bitmapUrl = URL.createObjectURL(file);

  try {
    const img = await new Promise((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('Gambar tidak bisa dibaca.'));
      el.src = bitmapUrl;
    });

    let size = maxSize;
    let quality = 0.85;

    for (let attempt = 0; attempt < 8; attempt += 1) {
      const scale = Math.min(1, size / Math.max(img.width, img.height));
      const width = Math.max(1, Math.round(img.width * scale));
      const height = Math.max(1, Math.round(img.height * scale));

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, width, height);
      ctx.drawImage(img, 0, 0, width, height);

      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      // Perkiraan ukuran byte dari panjang base64.
      const bytes = Math.round((dataUrl.length - dataUrl.indexOf(',') - 1) * 0.75);

      if (bytes <= maxBytes) return dataUrl;

      quality = Math.max(0.5, quality - 0.1);
      size = Math.round(size * 0.85);
    }

    throw new Error('Gambar terlalu besar. Coba gambar dengan resolusi lebih kecil.');
  } finally {
    URL.revokeObjectURL(bitmapUrl);
  }
}
