/** Ikon berwarna (SVG inline) untuk menu peserta & judul halaman. */
const svg = (body) =>
  `<svg viewBox="0 0 32 32" width="26" height="26" aria-hidden="true" focusable="false">${body}</svg>`;

export const ICONS = {
  dashboard: svg(
    '<rect x="3" y="3" width="11" height="11" rx="2.5" fill="#3b82f6"/>' +
    '<rect x="18" y="3" width="11" height="11" rx="2.5" fill="#f97316"/>' +
    '<rect x="3" y="18" width="11" height="11" rx="2.5" fill="#22c55e"/>' +
    '<rect x="18" y="18" width="11" height="11" rx="2.5" fill="#a855f7"/>'
  ),
  modules: svg(
    '<rect x="3" y="3" width="17" height="17" rx="3" fill="#84cc16"/>' +
    '<rect x="10" y="10" width="19" height="19" rx="3" fill="#6366f1" fill-opacity=".92"/>' +
    '<rect x="14" y="8" width="12" height="12" rx="3" fill="#ec4899" fill-opacity=".55"/>'
  ),
  exam: svg(
    '<path d="M7 3h13l6 6v20H7z" fill="#f8fafc"/>' +
    '<path d="M20 3l6 6h-6z" fill="#cbd5e1"/>' +
    '<path d="M12 22l11-11 3 3-11 11-4 1z" fill="#f97316"/>' +
    '<path d="M12 22l-1 4 4-1z" fill="#fbbf24"/>'
  ),
  schedule: svg(
    '<rect x="3" y="6" width="26" height="23" rx="4" fill="#f8fafc"/>' +
    '<path d="M3 10a4 4 0 0 1 4-4h18a4 4 0 0 1 4 4v3H3z" fill="#ef4444"/>' +
    '<g fill="#3b82f6"><rect x="7" y="16" width="4" height="4" rx="1"/><rect x="14" y="16" width="4" height="4" rx="1"/><rect x="21" y="16" width="4" height="4" rx="1"/><rect x="7" y="22" width="4" height="4" rx="1"/><rect x="14" y="22" width="4" height="4" rx="1"/><rect x="21" y="22" width="4" height="4" rx="1"/></g>'
  ),
  history: svg(
    '<rect x="3" y="3" width="26" height="26" rx="4" fill="#f8fafc"/>' +
    '<rect x="7" y="16" width="5" height="9" rx="1.2" fill="#38bdf8"/>' +
    '<rect x="14" y="10" width="5" height="15" rx="1.2" fill="#2563eb"/>' +
    '<rect x="21" y="6" width="5" height="19" rx="1.2" fill="#1d4ed8"/>'
  ),
  ranking: svg(
    '<path d="M9 4h14v8a7 7 0 0 1-14 0z" fill="#fbbf24"/>' +
    '<path d="M9 7H4v2a5 5 0 0 0 5 5M23 7h5v2a5 5 0 0 1-5 5" fill="none" stroke="#f59e0b" stroke-width="2.2"/>' +
    '<rect x="14" y="19" width="4" height="5" fill="#f59e0b"/>' +
    '<rect x="9" y="24" width="14" height="4" rx="1.5" fill="#d97706"/>'
  ),
  stopwatch:
    '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">' +
    '<circle cx="12" cy="13.5" r="7.5"/><path d="M12 9.5v4l2.5 1.5M9.5 2.5h5M12 2.5V6M18.5 6.5l1.5-1.5"/></svg>',
};

/** Ikon besar untuk judul halaman kuis. */
export const titleIcon = (name) =>
  ICONS[name].replace('width="26" height="26"', 'width="40" height="40"');
