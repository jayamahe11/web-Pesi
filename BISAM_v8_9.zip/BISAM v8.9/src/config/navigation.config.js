import { ICONS } from './icons.js';

export const USER_NAVIGATION = [


  {
  path:'/dashboard',
  label:'Dashboard',
  icon:ICONS.dashboard
  },
  
  
  {
  path:'/modules',
  label:'Modul Latihan',
  icon:ICONS.modules
  },
  
  
  {
  path:'/ujian',
  label:'Modul Ujian',
  icon:ICONS.exam
  },
  
  
  {
  path:'/schedule',
  label:'Jadwal',
  icon:ICONS.schedule
  },
  
  
  {
  path:'/history',
  label:'Hasil & Riwayat',
  icon:ICONS.history
  },
  
  
  {
  path:'/ranking',
  label:'Rangking',
  icon:ICONS.ranking
  }
  
  
  ];
  
  
  
  
  
  
  export const ADMIN_NAVIGATION=[
  
  
  {
  path:'/admin/dashboard',
  label:'Dashboard',
  icon:'▦'
  },
  
  
  {
  path:'/admin/participants',
  label:'Peserta',
  icon:'♙'
  },
  
  
  {
  path:'/admin/modules',
  label:'Modul',
  icon:'▤'
  },
  
  
  {
  path:'/admin/questions',
  label:'Soal',
  icon:'?'
  },
  
  
  {
  path:'/admin/locks',
  label:'Kunci Soal',
  icon:'🔒'
  },
  
  
  {
  path:'/admin/schedule',
  label:'Jadwal',
  icon:'◷'
  },
  
  
  {
  path:'/admin/reports',
  label:'Hasil & Laporan',
  icon:'▧'
  },
  
  
  {
  path:'/admin/announcements',
  label:'Pengumuman',
  icon:'◉'
  },
  
  
  {
  path:'/admin/settings',
  label:'Pengaturan',
  icon:'⚙'
  }
  
  
  ];