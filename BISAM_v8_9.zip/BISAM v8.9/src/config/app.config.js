/**
 * Konfigurasi global aplikasi.
 * Ubah identitas aplikasi, durasi tes, dan pengaturan umum dari satu tempat.
 */
export const APP_CONFIG = Object.freeze({
  name: 'BISAM',
  fullName: 'Bintang Samudra BINJAS & PSI',
  year: 2026,
  logoUrl: '/public/assets/logo-bisam.png',
  defaultQuizDurationMinutes: 15,
  quizAutoAdvanceDelayMs: 500,
  storagePrefix: 'bisam_v6',

  /**
   * LOKASI BISAM (tampil di halaman depan & footer).
   * Isi `latitude` dan `longitude` dengan koordinat asli lokasi Bintang
   * Samudra. Cara cepat: buka Google Maps, klik kanan pada titik lokasi,
   * lalu klik angka koordinat paling atas untuk menyalinnya
   * (contoh format: -6.200000, 106.816666).
   * Selama latitude/longitude masih null, peta tidak ditampilkan dan
   * halaman hanya memberi tahu bahwa lokasi belum diisi.
   */
  location: {
    name: 'Bintang Samudra (BISAM)',
    address: '',
    latitude: null,
    longitude: null,
    zoom: 16,
  },
});
