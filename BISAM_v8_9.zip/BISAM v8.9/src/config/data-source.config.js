/**
 * Sumber data aplikasi.
 *
 * Sekarang memakai "mock" supaya project langsung jalan tanpa koneksi internet.
 * Setelah Firebase selesai dikonfigurasi, ubah provider menjadi "firebase"
 * dan implementasikan loader pada repositories/firebase.repository.js.
 */
export const DATA_SOURCE_CONFIG = Object.freeze({
  provider: 'firebase', // 'mock' | 'firebase'
});
