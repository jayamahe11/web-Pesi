const savedTheme = localStorage.getItem("theme");


if(savedTheme === "dark"){

document.body.classList.add("dark");

}

import { Router } from './app/router.js';
import { showToast } from './components/ui/toast.js';
import { authService } from './services/auth.service.js';
import { dataService } from './services/data.service.js';
import { DATA_SOURCE_CONFIG } from './config/data-source.config.js';


const root = document.getElementById('app');

const router = new Router(root);


document.addEventListener('click', (event) => {

    const logoutButton = event.target.closest('[data-action="logout"]');

    if (!logoutButton) return;


    authService.logout();

    showToast(
        'Anda telah keluar dari aplikasi.',
        'success'
    );


    router.navigate('/');

});



// --------------------------------------------------------------
// Kenapa boot lama bisa nge-crash total dengan pesan
// "Aplikasi gagal memuat data" / "Missing or insufficient permissions":
//
// 1) Saat provider = 'firebase', dataService.initialize() langsung
//    mengambil collection yang dilindungi security rules (butuh login).
//    Kalau ini dipanggil SEBELUM Firebase Auth sempat memulihkan sesi
//    yang tersimpan (atau memang belum ada yang login sama sekali),
//    Firestore menolak dengan permission-denied.
// 2) Kode lama membungkus itu dalam try/catch yang MENGGANTI SELURUH
//    ISI HALAMAN (root.innerHTML = ...pesan error...), jadi bukan cuma
//    datanya yang gagal, tapi seluruh app (termasuk halaman login)
//    ikut tidak bisa tampil sama sekali.
//
// Perbaikannya di bawah: tunggu status login Firebase selesai dicek
// dulu (authReady) baru query Firestore, dan kalaupun pemuatan data
// tetap gagal (mis. karena memang belum login), jangan hentikan
// seluruh aplikasi — cukup log + toast, lalu tetap jalankan router.
// Router sendiri sudah punya penjaga rute (isAllowed) yang otomatis
// mengarahkan ke /login untuk halaman yang butuh login.
// --------------------------------------------------------------

async function loadInitialData() {

    if (DATA_SOURCE_CONFIG.provider === 'firebase') {

        const { authReady } = await import('./firebase/config.js');

        await authReady;

    }

    try {

        await dataService.initialize();

    } catch (error) {

        console.error('[BISAM] Gagal memuat data awal:', error);

        showToast(
            'Sebagian data gagal dimuat. Silakan login lalu coba lagi.',
            'error'
        );

    }

}

await loadInitialData();

router.start();


// --------------------------------------------------------------
// Menu samping (HP): tombol hamburger membuka/menutup sidebar sebagai
// drawer. Otomatis menutup saat pilih menu, klik area gelap, tekan Esc,
// atau pindah halaman.
// --------------------------------------------------------------

function setMenu(open) {

    document.body.classList.toggle('menu-open', open);

    document
        .querySelector('[data-action="toggle-menu"]')
        ?.setAttribute('aria-expanded', String(open));

}

document.addEventListener('click', (event) => {

    if (event.target.closest('[data-action="toggle-menu"]')) {

        setMenu(!document.body.classList.contains('menu-open'));

        return;

    }

    if (
        event.target.closest('[data-action="close-menu"]') ||
        event.target.closest('.sidebar__link')
    ) {

        setMenu(false);

    }

});

document.addEventListener('keydown', (event) => {

    if (event.key === 'Escape') setMenu(false);

});

window.addEventListener('hashchange', () => setMenu(false));

window.addEventListener('resize', () => {

    if (window.innerWidth > 900) setMenu(false);

});
