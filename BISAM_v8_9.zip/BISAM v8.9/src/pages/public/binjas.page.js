import { bindInfoActions, infoPage } from './info-page.js';

export function binjasPage(router) {
  return {
    html: infoPage({
      tag: 'BINJAS',
      title: 'BINJAS — Bimbingan Jasmani',
      subtitle:
        '<strong>BINJAS</strong> adalah singkatan dari <strong>Bimbingan Jasmani</strong>: pembinaan kebugaran dan kemampuan fisik untuk menyiapkan calon peserta seleksi <strong>TNI, POLRI, dan Sekolah Kedinasan</strong>.',
      sections: [
        {
          icon: '🏃',
          title: 'Apa itu BINJAS?',
          text:
            'Seleksi masuk TNI, POLRI, dan banyak sekolah kedinasan memuat tes kesamaptaan jasmani. BINJAS adalah proses berlatih terarah agar tubuh siap menghadapi tes tersebut: bukan hanya kuat pada hari tes, tetapi terbiasa dengan pola latihan yang bertahap dan terukur.',
        },
        {
          icon: '📋',
          title: 'Yang biasanya diujikan',
          items: [
            'Lari (misalnya lari 12 menit) untuk daya tahan',
            'Pull-up / chinning untuk kekuatan tubuh bagian atas',
            'Sit-up dan push-up untuk kekuatan otot inti dan lengan',
            'Shuttle run untuk kelincahan dan kecepatan',
            'Renang pada seleksi tertentu',
          ],
        },
        {
          icon: '🎯',
          title: 'Apa fungsinya?',
          items: [
            'Meningkatkan <strong>daya tahan, kekuatan, dan kelincahan</strong> secara bertahap',
            'Mengukur <strong>kesiapan fisik</strong> sebelum tes sesungguhnya, sehingga kekurangan bisa diperbaiki lebih awal',
            'Membangun <strong>disiplin dan mental</strong> yang dibutuhkan dalam pendidikan kedinasan',
            'Mengurangi risiko cedera karena latihan dilakukan dengan teknik dan porsi yang benar',
          ],
        },
        {
          icon: '🧭',
          title: 'Bersama Bintang Samudra',
          text:
            'Setelah masuk ke akun, lihat menu <strong>Jadwal</strong> dan <strong>Pengumuman</strong> untuk informasi kegiatan dari pembina. Lengkapi dengan latihan akademik dan psikotes di platform ini agar persiapanmu seimbang.',
        },
      ],
      note:
        'Penjelasan di atas bersifat umum. Jenis tes, nilai ambang, dan standar penilaian berbeda tiap instansi dan tahun seleksi — selalu cek pengumuman resmi panitia seleksi.',
      actions: [
        { label: 'Daftar Sekarang', to: '/register' },
        { label: 'Lihat PSI', to: '/psi', secondary: true },
      ],
    }),

    mount() {
      bindInfoActions(router);
    },

    unmount() {},
  };
}
