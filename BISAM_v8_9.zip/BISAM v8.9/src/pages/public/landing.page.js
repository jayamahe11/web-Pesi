import { APP_CONFIG } from '../../config/app.config.js';
import { locationSection } from '../../components/ui/location-card.js';


export function landingPage(router) {


return {


html: `


<section class="landing-page">


<!-- HERO -->

<div class="landing-hero">


<img 
src="${APP_CONFIG.logoUrl}" 
class="landing-main-logo"
/>



<div class="landing-tag">

PLATFORM LATIHAN BINJAS & PSI

</div>



<h1>

Persiapkan Dirimu

<br>

Menjadi Insan Terbaik

</h1>



<p>

Platform latihan seleksi 
<strong>Sekolah Kedinasan, TNI & POLRI</strong>
dengan latihan akademik, psikotes,
dan evaluasi progres dalam satu sistem.

</p>




<div class="landing-actions">



<button 
class="landing-button"
id="register-btn">

Daftar Sekarang

</button>




<button 
class="landing-button secondary"
id="login-btn">

Masuk

</button>



</div>


</div>






<!-- FEATURES -->


<div class="landing-features">



<div class="landing-card">


<h3>

📘 Materi Terstruktur

</h3>


<p>

Kurikulum lengkap dan terarah
sesuai kebutuhan seleksi.

</p>


</div>





<div class="landing-card">


<h3>

📊 Latihan & Simulasi

</h3>


<p>

Ribuan soal, simulasi ujian
dan psikotes terupdate.

</p>


</div>







<div class="landing-card">


<h3>

🛡️ Evaluasi & Progres

</h3>


<p>

Pantau perkembangan belajar
secara berkala.

</p>


</div>



</div>



<!-- BINJAS & PSI -->

<div class="landing-links">

<a class="landing-card landing-card--link" href="#/binjas">
<h3>🏃 BINJAS</h3>
<p>Bimbingan Jasmani: latihan kebugaran untuk tes kesamaptaan seleksi.</p>
<span class="landing-card__more">Pelajari BINJAS →</span>
</a>

<a class="landing-card landing-card--link" href="#/psi">
<h3>🧠 PSI</h3>
<p>Psikologi: latihan psikotes kecerdasan, ketelitian, dan kepribadian.</p>
<span class="landing-card__more">Pelajari PSI →</span>
</a>

</div>


</section>

${locationSection()}

`,




mount(){



const registerButton =
document.getElementById(
'register-btn'
);



const loginButton =
document.getElementById(
'login-btn'
);




registerButton?.addEventListener(
'click',
()=>{

router?.navigate(
'/register'
);

}

);




loginButton?.addEventListener(
'click',
()=>{

router?.navigate(
'/login'
);

}

);



}



};



}