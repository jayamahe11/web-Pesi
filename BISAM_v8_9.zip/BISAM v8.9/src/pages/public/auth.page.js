import { APP_CONFIG } from "../../config/app.config.js";

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";

import {
  doc,
  getDoc,
  serverTimestamp,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";

import {
  auth,
  db,
  googleProvider
} from "../../firebase/config.js";

import {
  showToast
} from "../../components/ui/toast.js";

import {
  qs
} from "../../utils/dom.js";

import { authService } from '../../services/auth.service.js';
import { dataService } from '../../services/data.service.js';

// Setelah login berhasil, muat ULANG data dari Firestore (paksa, abaikan
// cache lama) karena percobaan pemuatan data saat app pertama kali dibuka
// (sebelum user ini login) kemungkinan besar gagal/kosong akibat security
// rules yang mewajibkan login. Dibungkus try/catch sendiri supaya kalau
// data gagal dimuat, itu TIDAK dianggap sebagai "login gagal".
async function reloadDataAfterLogin() {
  try {
    await dataService.initialize(true);
  } catch (error) {
    console.error('[BISAM] Gagal memuat data setelah login:', error);
  }
}


export function authPage(mode, router) {

  const isRegister = mode === "register";


  return {


    html: `

<section class="auth-shell auth-shell--modern">


<div class="auth-hero-panel">


<div class="auth-hero-panel__overlay"></div>


<div class="auth-hero-panel__content">


<img
class="auth-hero-panel__logo"
src="${APP_CONFIG.logoUrl}"
alt="${APP_CONFIG.fullName}"
>



<div class="auth-hero-panel__headline">

<h1>
Bintang Samudra
</h1>


<h2>
Persiapkan Dirimu
<br>
Menjadi Insan Terbaik
</h2>


<p>
Platform pelatihan seleksi
<strong>Sekolah Kedinasan, TNI & POLRI</strong>
dengan latihan akademik,
psikotes, dan evaluasi progres
dalam satu sistem.
</p>


</div>




<div class="auth-hero-features">


<div class="auth-hero-feature">

<div class="auth-hero-feature__icon">
📘
</div>

<h3>
Materi Terstruktur
</h3>

<p>
Kurikulum lengkap dan terarah sesuai kebutuhan seleksi.
</p>

</div>




<div class="auth-hero-feature">

<div class="auth-hero-feature__icon">
📊
</div>

<h3>
Latihan & Simulasi
</h3>

<p>
Ribuan soal, simulasi ujian dan psikotes terupdate.
</p>

</div>




<div class="auth-hero-feature">

<div class="auth-hero-feature__icon">
🛡️
</div>

<h3>
Evaluasi & Progres
</h3>

<p>
Pantau perkembangan belajar secara berkala.
</p>

</div>


</div>



<div class="auth-hero-panel__footer">

© ${APP_CONFIG.year} Bintang Samudra. All rights reserved.

</div>



</div>


</div>





<div class="auth-form-panel">


<div class="auth-card-modern">


<h2 class="auth-card-modern__title">

${isRegister ? "Buat Akun" : "Selamat Datang"}

</h2>


<p class="auth-card-modern__subtitle">

${isRegister ? "Create a new account" : "Login ke akun BISAM"}

</p>





<form id="auth-form">


${
isRegister
?
`

<div class="auth-field">

<label>
Nama Lengkap
</label>


<div class="auth-input-wrap">

<span class="auth-input-icon">
👤
</span>


<input
id="name"
type="text"
placeholder="Masukkan nama lengkap"
required
>


</div>

</div>

`
:
""
}




<div class="auth-field">


<label>
Email
</label>


<div class="auth-input-wrap">

<span class="auth-input-icon">
✉️
</span>


<input
id="email"
type="email"
placeholder="Masukkan email Anda"
required
>


</div>


</div>






<div class="auth-field">


<label>
Password
</label>


<div class="auth-input-wrap">


<span class="auth-input-icon">
🔐
</span>


<input
id="password"
type="password"
placeholder="Masukkan password Anda"
required
>


</div>


</div>






<button
class="auth-submit-btn"
type="submit"
>

${isRegister ? "SIGN UP" : "SIGN IN"}

<span>
→
</span>


</button>





<div class="auth-divider">

<span>
atau
</span>

</div>




<button
type="button"
id="google-login"
class="auth-google-btn"
>

<span class="auth-google-btn__icon">
G
</span>

Login dengan Google

</button>





<div class="auth-bottom-text">


${
isRegister
?

`
Sudah punya akun?

<a href="#/login">
Sign In Now!
</a>

`

:

`

Belum punya akun?

<a href="#/register">
Sign Up Now!
</a>

`

}


</div>




</form>



</div>


</div>



</section>


`,




mount(){



const googleBtn =
qs("#google-login");



googleBtn?.addEventListener(
"click",
async()=>{


try{


const result =
await signInWithPopup(
auth,
googleProvider
);



const user =
result.user;



const ref =
doc(
db,
"users",
user.uid
);



const snap =
await getDoc(ref);



if(!snap.exists()){


await setDoc(
ref,
{

nama:user.displayName,

email:user.email,

foto:user.photoURL,

role:"user",

createdAt:serverTimestamp()

}
);


}



authService.loginAsUser();

await reloadDataAfterLogin();

showToast(
"Login berhasil",
"success"
);

router.navigate(
"/dashboard"
);



}

catch(error){

console.error(error);


showToast(
"Gagal login Google",
"error"
);


}


});






qs("#auth-form")
?.addEventListener(
"submit",
async(e)=>{


e.preventDefault();



const email =
qs("#email").value;


const password =
qs("#password").value;



try{


if(isRegister){


const name =
qs("#name").value;



const result = await createUserWithEmailAndPassword(
auth,
email,
password
);



await updateProfile(
result.user,
{
displayName:name
}
);



await setDoc(
doc(
db,
"users",
result.user.uid
),

{

nama:name,

email:email,

role:"user",

createdAt:serverTimestamp()

}

);



authService.loginAsUser();

await reloadDataAfterLogin();

showToast(
"Akun berhasil dibuat",
"success"
);

router.navigate(
"/dashboard"
);



}

else{


  const result = await signInWithEmailAndPassword(
  auth,
  email,
  password
  );
  
  
  const user = result.user;
  
  
  // Ambil data role dari Firestore
  const userRef = doc(
  db,
  "users",
  user.uid
  );
  
  
  const userSnap = await getDoc(userRef);
  
  
  
  if(userSnap.exists()){
  
  
  const userData = userSnap.data();
  
  
  
  if(userData.role === "admin"){
  
  
  authService.loginAsAdmin();


  await reloadDataAfterLogin();
  
  
  showToast(
  "Login Admin berhasil",
  "success"
  );
  
  
  router.navigate(
  "/admin/dashboard"
  );
  
  
  
  }else{
  
  
  authService.loginAsUser();


  await reloadDataAfterLogin();
  
  
  showToast(
  "Login berhasil",
  "success"
  );
  
  
  router.navigate(
  "/dashboard"
  );
  
  
  }
  
  
  
  }else{
  
  
  showToast(
  "Data user tidak ditemukan",
  "error"
  );
  
  
  }
  
  
  
  }



}

catch(error){


console.error(error);


const code = error?.code || "";

const messages = {
  "auth/too-many-requests":
    "Terlalu banyak percobaan login. Tunggu 15–30 menit, atau reset password lewat 'Lupa password'.",
  "auth/network-request-failed":
    "Koneksi internet bermasalah. Coba lagi.",
  "auth/user-disabled":
    "Akun ini dinonaktifkan. Hubungi admin.",
  "auth/invalid-email":
    "Format email tidak valid.",
  "auth/email-already-in-use":
    "Email sudah terdaftar. Silakan login.",
  "auth/weak-password":
    "Password terlalu lemah (minimal 6 karakter)."
};

showToast(
messages[code] || "Email atau password salah",
"error"
);


}



});


}



};


}