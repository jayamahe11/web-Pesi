import { bindInfoActions, infoPage } from './info-page.js';

export function psiPage(router) {
  return {
    html: infoPage({
      tag: 'PSI',
      title: 'PSI — Psikologi (Psikotes)',
      subtitle:
        '<strong>PSI</strong> adalah singkatan dari <strong>Psikologi</strong>: rangkaian tes psikologi (psikotes) yang menilai cara berpikir, ketelitian, ketahanan kerja, dan kepribadian calon peserta seleksi <strong>TNI, POLRI, dan Sekolah Kedinasan</strong>.',
      sections: [
        {
          icon: '🧠',
          title: 'Apa itu PSI?',
          text:
            'Selain tes akademik dan jasmani, hampir semua seleksi kedinasan memiliki tes psikologi. Soalnya tidak diajarkan seperti pelajaran sekolah, tetapi sangat bisa dilatih: semakin sering berlatih, semakin cepat dan tenang kamu menjawab.',
        },
        {
          icon: '📋',
          title: 'Yang biasanya diujikan',
          items: [
            '<strong>Kecerdasan</strong>: logika, numerik, verbal, analogi, deret angka, penalaran analitis, spasial',
            '<strong>Ketelitian & kecepatan</strong>: tes ketelitian, kecepatan konsentrasi, serta Pauli dan Kraepelin',
            '<strong>Kepribadian</strong>: kecenderungan sikap kerja, stabilitas emosi, dan ketahanan menghadapi tekanan',
          ],
        },
        {
          icon: '🎯',
          title: 'Apa fungsinya?',
          items: [
            'Menilai <strong>kemampuan berpikir</strong> dan kecepatan memahami soal',
            'Melihat <strong>ketelitian, konsentrasi, dan ketahanan kerja</strong> saat bekerja lama di bawah waktu terbatas',
            'Menggambarkan <strong>kepribadian</strong> untuk menilai kecocokan dengan tuntutan pendidikan dan penugasan',
            'Bagi peserta latihan: mengenali <strong>jenis soal dan pola waktu</strong> sebelum tes sebenarnya',
          ],
        },
        {
          icon: '📚',
          title: 'Latihan PSI di BISAM',
          text:
            'Di menu <strong>Modul Latihan</strong> tersedia Logika Dasar, Numerik, Verbal, Sinonim &amp; Antonim, Analogi Kata, Deret Angka, Matematika Dasar, Penalaran Analitis, Spasial, Tes Ketelitian, Kecepatan Konsentrasi, Kepribadian Kerja, serta Pauli &amp; Kraepelin. Hasil latihan masuk ke riwayatmu, dan nilai terbaik tiap modul dipakai untuk peringkat.',
        },
      ],
      note:
        'Penjelasan di atas bersifat umum. Bentuk dan komponen psikotes dapat berbeda tiap instansi dan tahun seleksi — ikuti informasi resmi panitia seleksi.',
      actions: [
        { label: 'Daftar & Mulai Latihan', to: '/register' },
        { label: 'Lihat BINJAS', to: '/binjas', secondary: true },
      ],
    }),

    mount() {
      bindInfoActions(router);
    },

    unmount() {},
  };
}
