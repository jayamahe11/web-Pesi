import { escapeHtml } from '../../utils/html.js';

/**
 * Kerangka halaman informasi publik (dipakai BINJAS & PSI).
 *
 * sections: [{ icon, title, text?, items?: string[] }]
 */
export function infoPage({
  tag,
  title,
  subtitle,
  sections = [],
  note = '',
  actions = [],
}) {
  return `
    <section class="info-page">
      <div class="info-hero">
        <div class="landing-tag">${escapeHtml(tag)}</div>
        <h1>${escapeHtml(title)}</h1>
        <p>${subtitle}</p>
      </div>

      <div class="info-grid">
        ${sections.map((section) => `
          <article class="info-card">
            <h2><span aria-hidden="true">${section.icon ?? '•'}</span> ${escapeHtml(section.title)}</h2>
            ${section.text ? `<p>${section.text}</p>` : ''}
            ${section.items?.length ? `<ul>${section.items.map((item) => `<li>${item}</li>`).join('')}</ul>` : ''}
          </article>
        `).join('')}
      </div>

      ${note ? `<p class="info-note">${note}</p>` : ''}

      <div class="landing-actions info-actions">
        ${actions.map((action) => `
          <button class="landing-button ${action.secondary ? 'secondary' : ''}" type="button" data-go="${escapeHtml(action.to)}">${escapeHtml(action.label)}</button>
        `).join('')}
      </div>
    </section>
  `;
}

export function bindInfoActions(router) {
  document.querySelectorAll('[data-go]').forEach((button) => {
    button.addEventListener('click', () => router?.navigate(button.dataset.go));
  });
}
