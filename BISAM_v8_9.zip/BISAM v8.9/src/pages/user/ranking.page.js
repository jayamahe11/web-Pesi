import { pageHeading } from '../../components/ui/page-heading.js';
import { rankingRow } from '../../components/ui/ranking-row.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { badge } from '../../components/ui/badge.js';
import { dataService } from '../../services/data.service.js';
import { rankingService } from '../../services/ranking.service.js';
import { auth } from '../../firebase/config.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';

const QUIZ_TYPE_LABEL = {
  latihan: 'Latihan',
  ujian: 'Ujian',
  psikotes: 'Psikotes',
};

export async function userRankingPage() {
  const user = await dataService.getCurrentUser();
  const ranking = await dataService.getRanking();

  const myUid = auth.currentUser?.uid ?? null;
  const myIndex = ranking.findIndex((item) => item.uid === myUid);
  const myRank = myIndex === -1 ? null : myIndex + 1;

  return {
    html: `
      ${pageHeading({
        title: 'Ranking / Leaderboard',
        description: 'Peringkat semua peserta berdasarkan total poin latihan & ujian yang sudah dikerjakan. Klik nama untuk lihat riwayat modulnya.',
      })}

      <section class="ranking-layout">
        <article class="card">
          <div class="ranking-list section-gap--small">
            ${ranking.length
              ? ranking.map((item, index) => `
                  <div class="ranking-item">
                    ${rankingRow({
                      item,
                      position: index + 1,
                      currentUserId: myUid,
                    })}
                    <button
                      class="button button--outline button--small ranking-item__toggle"
                      type="button"
                      data-ranking-uid="${item.uid}"
                    >
                      Lihat riwayat
                    </button>
                    <div class="ranking-item__detail" data-ranking-detail="${item.uid}" hidden></div>
                  </div>
                `).join('')
              : emptyState({
                  title: 'Belum ada peserta pada leaderboard',
                  description: 'Leaderboard akan otomatis terisi setelah ada peserta yang menyelesaikan latihan atau ujian.',
                })}
          </div>
        </article>

        <aside class="card my-rank-card">
          <div class="metric-card__icon">★</div>
          <h2>Peringkat Saya</h2>
          <strong class="my-rank-card__position">${myRank ? `#${myRank}` : '—'}</strong>
          <p>${user?.name ?? 'Peserta'}</p>
          <span>${user?.points ?? 0} poin</span>
        </aside>
      </section>
    `,

    mount() {
      const loadedFor = new Set();

      qsa('[data-ranking-uid]').forEach((button) => {
        button.addEventListener('click', async () => {
          const uid = button.dataset.rankingUid;
          const detailBox = qs(`[data-ranking-detail="${uid}"]`);
          if (!detailBox) return;

          const isOpen = !detailBox.hidden;
          if (isOpen) {
            detailBox.hidden = true;
            return;
          }

          if (!loadedFor.has(uid)) {
            detailBox.innerHTML = '<p class="ranking-item__loading">Memuat riwayat...</p>';
            detailBox.hidden = false;

            const attempts = await rankingService.getAttempts(uid);
            loadedFor.add(uid);
            detailBox.dataset.attempts = JSON.stringify(attempts);
            renderDetail(detailBox, attempts, 'all');
          } else {
            detailBox.hidden = false;
          }
        });
      });

      function renderDetail(box, attempts, activeType) {
        if (!attempts.length) {
          box.innerHTML = '<p class="ranking-item__loading">Belum ada riwayat pengerjaan.</p>';
          return;
        }

        const filtered = activeType === 'all'
          ? attempts
          : attempts.filter((item) => item.quizType === activeType);

        box.innerHTML = `
          <div class="segmented-control segmented-control--small" data-ranking-filter="${box.dataset.attemptsUid ?? ''}">
            <button type="button" data-type="all" class="${activeType === 'all' ? 'is-active' : ''}">Semua</button>
            <button type="button" data-type="latihan" class="${activeType === 'latihan' ? 'is-active' : ''}">Latihan</button>
            <button type="button" data-type="ujian" class="${activeType === 'ujian' ? 'is-active' : ''}">Ujian</button>
          </div>
          <div class="ranking-item__attempts">
            ${filtered.length
              ? filtered.map((item) => `
                  <div class="ranking-item__attempt-row">
                    <span>${escapeHtml(item.moduleTitle)}</span>
                    ${badge(QUIZ_TYPE_LABEL[item.quizType] || 'Latihan')}
                    <strong>${item.score}</strong>
                  </div>
                `).join('')
              : '<p class="ranking-item__loading">Tidak ada riwayat untuk kategori ini.</p>'}
          </div>
        `;

        box.querySelectorAll('[data-type]').forEach((btn) => {
          btn.addEventListener('click', () => {
            renderDetail(box, attempts, btn.dataset.type);
          });
        });
      }
    },
  };
}
