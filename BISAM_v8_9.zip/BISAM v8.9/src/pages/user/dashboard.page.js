import { dataService } from '../../services/data.service.js';
import { escapeHtml } from '../../utils/html.js';

const MEDALS = ['🥇', '🥈', '🥉'];

function initialsOf(name = '') {
  const parts = String(name).trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '?';
  return parts.slice(0, 2).map((p) => p[0].toUpperCase()).join('');
}

export async function userDashboardPage() {

  const user = await dataService.getCurrentUser();

  const modules = dataService.getModules();

  const history = dataService.getHistory();

  const announcements = dataService.getAnnouncements().slice(0, 5);

  let top3 = [];

  try {
    top3 = (await dataService.getRanking()).slice(0, 3);
  } catch (error) {
    console.warn('[BISAM] Ranking dashboard gagal dimuat:', error);
  }

  return {

    html: `
<section class="dashboard-page">

  <div class="dash-top">

    <div class="welcome-card">
      <h1>Halo, ${escapeHtml(user?.name ?? 'Peserta')} 👋</h1>
      <p>Selamat datang kembali di BISAM Learning</p>
    </div>

    <div class="stat-card">
      <h3>📝</h3>
      <strong>${history.length}</strong>
      <p>Latihan selesai</p>
    </div>

    <div class="stat-card">
      <h3>⭐</h3>
      <strong>${user?.points ?? 0}</strong>
      <p>Poin</p>
    </div>

  </div>

  <div class="section-title">
    <h2>🔥 Latihan Terbaru</h2>
  </div>

  <div class="module-preview">
    ${modules.slice(0, 4).map((item) => `
      <a class="module-mini" href="#/modules">
        <h3>${item.icon ?? '📚'} ${escapeHtml(item.title)}</h3>
        <p>${escapeHtml(item.itemCountLabel ?? 'Latihan')}</p>
      </a>
    `).join('')}
  </div>

  <div class="dash-bottom">

    <article class="card dash-panel">
      <div class="dash-panel__head">
        <h2>📢 Papan Pengumuman</h2>
        <a href="#/announcements">Lihat semua</a>
      </div>

      ${announcements.length ? `
        <ul class="dash-list">
          ${announcements.map((item) => `
            <li>
              <small>${escapeHtml(item.date ?? '')}</small>
              <strong>${escapeHtml(item.title)}</strong>
            </li>
          `).join('')}
        </ul>
      ` : '<p class="dash-empty">Belum ada pengumuman.</p>'}
    </article>

    <article class="card dash-panel">
      <div class="dash-panel__head">
        <h2>🏆 Top 3 Ranking</h2>
        <a href="#/ranking">Lihat semua</a>
      </div>

      ${top3.length ? `
        <ul class="dash-rank">
          ${top3.map((item, index) => `
            <li>
              <span class="dash-rank__medal">${MEDALS[index]}</span>
              <span class="dash-rank__avatar">${escapeHtml(initialsOf(item.name))}</span>
              <span class="dash-rank__name">${escapeHtml(item.name)}</span>
              <span class="dash-rank__points">${item.points} poin</span>
            </li>
          `).join('')}
        </ul>
      ` : '<p class="dash-empty">Belum ada peserta di leaderboard.</p>'}
    </article>

  </div>

</section>
`,

    mount() {},

    unmount() {}

  };

}
