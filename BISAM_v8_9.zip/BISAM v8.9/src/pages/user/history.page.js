import { badge } from '../../components/ui/badge.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { dataService } from '../../services/data.service.js';
import { auth } from '../../firebase/config.js';

const LAST_QUIZ_RESULT_KEY = 'bisam_last_quiz_result';

export async function userHistoryPage() {
  const history = dataService.getHistory();
  const user = await dataService.getCurrentUser();
  const latestResult = getLatestQuizResult();
  const historyWithoutLatest = latestResult?.recordId
    ? history.filter((item) => item.id !== latestResult.recordId)
    : history;

  // Ranking nyata (leaderboard Firestore) dipakai hanya kalau ada hasil
  // terbaru yang mau ditampilkan, supaya halaman riwayat biasa tidak perlu
  // menunggu network call ini.
  const leaderboard = latestResult ? await dataService.getRanking() : [];
  const myUid = auth.currentUser?.uid ?? null;

  return {
    html: `
      ${pageHeading({
        title: latestResult ? 'Hasil Ujian' : 'Hasil & Riwayat',
        description: latestResult
          ? 'Setelah peserta menyelesaikan quiz, hasil akan tampil dalam bentuk dashboard ringkas seperti halaman hasil ujian.'
          : 'Riwayat akan terisi otomatis setelah Anda menyelesaikan latihan atau ujian.',
      })}

      ${latestResult ? renderResultDashboard(latestResult, user, leaderboard, myUid) : ''}

      <article class="card section-gap">
        <div class="card-heading">
          <div>
            <h2>Riwayat Pengerjaan</h2>
            <p>Daftar hasil latihan dan ujian yang pernah diselesaikan peserta.</p>
          </div>
          <div class="button-group">
            ${latestResult ? '<button class="button button--outline button--small" type="button" id="hide-latest-result">Tutup ringkasan hasil</button>' : ''}
            <a class="button button--soft button--small" href="#/modules">Mulai latihan</a>
            <a class="button button--primary button--small" href="#/ujian">Mulai ujian</a>
          </div>
        </div>

        ${history.length ? `
          <div class="table-scroll">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Modul</th>
                  <th>Tanggal</th>
                  <th>Skor</th>
                  <th>Poin</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                ${renderHistoryRows(latestResult, history, historyWithoutLatest)}
              </tbody>
            </table>
          </div>
        ` : emptyState({
          title: 'Belum ada riwayat',
          description: 'Akun ini masih baru. Selesaikan satu modul agar hasil pertama muncul.',
          action: '<a class="button button--primary" href="#/modules">Mulai Latihan</a>',
        })}
      </article>
    `,

    mount() {
      const hideButton = document.getElementById('hide-latest-result');
      if (hideButton) {
        hideButton.onclick = () => {
          sessionStorage.removeItem(LAST_QUIZ_RESULT_KEY);
          window.location.hash = '/history';
        };
      }
    },
  };
}

function getLatestQuizResult() {
  try {
    const raw = sessionStorage.getItem(LAST_QUIZ_RESULT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    console.error('Gagal membaca hasil quiz terakhir', error);
    return null;
  }
}

function renderResultDashboard(result, user, leaderboard = [], myUid = null) {
  const rankingText = buildRankingText(leaderboard, myUid);
  const score = Number(result.score ?? 0);
  const total = Number(result.total ?? 0);
  const correct = Number(result.rawScore ?? 0);
  const wrong = Number(result.wrong ?? Math.max(0, total - correct));
  const moduleIcon = result.moduleIcon ?? '📝';
  const moduleTitle = result.moduleTitle ?? 'Modul Quiz';
  const quizLabel = result.quizType === 'ujian' ? 'Ujian' : 'Latihan';
  const breakdown = Array.isArray(result.categoryBreakdown) ? result.categoryBreakdown : [];
  const questionRows = Array.isArray(result.questionRows) ? result.questionRows : [];

  return `
    <section class="result-dashboard section-gap--small">
      <div class="result-dashboard__hero welcome-card">
        <div>
          <h1>Halo, ${user?.name ?? 'Peserta'} 👋</h1>
          <p>${quizLabel} ${moduleTitle} sudah selesai. Berikut ringkasan hasil terbaru Anda.</p>
        </div>
        <div class="result-dashboard__meta">
          <span>${moduleIcon} ${moduleTitle}</span>
          <strong>${score}/100</strong>
        </div>
      </div>

      <article class="result-panel card">
        <div class="card-heading">
          <div>
            <h2>Exam Results Dashboard</h2>
            <p>Tampilan hasil otomatis setelah peserta menekan tombol selesai.</p>
          </div>
          <span class="result-status-pill">${result.statusLabel ?? scoreLabelFromPercent(score)}</span>
        </div>

        <div class="result-panel__top">
          <div class="result-score-card">
            <div class="result-score-ring" style="--progress:${score};">
              <div class="result-score-ring__inner">
                <span>Nilai</span>
                <strong>${score}/100</strong>
                <small>${result.statusLabel ?? scoreLabelFromPercent(score)}</small>
              </div>
            </div>
          </div>

          <div class="result-metrics-grid">
            ${renderMetricCard('✅', 'Benar', `${correct}/${total}`, `${score}% akurat`, 'success')}
            ${renderMetricCard('❌', 'Salah', `${wrong}/${total}`, `${Math.max(0, 100 - score)}% error`, 'danger')}
            ${renderMetricCard('🕒', 'Waktu', result.durationSpentLabel ?? '0:00', `Dari ${result.durationTotalLabel ?? '0:00'}`, 'info')}
            ${renderMetricCard('🏆', 'Ranking', rankingText.value, rankingText.caption, 'warning')}
          </div>
        </div>

        <div class="result-panel__body">
          <aside class="result-analysis-card">
            <div class="card-heading">
              <div>
                <h2>Analisis Jawaban</h2>
                <p>Ringkasan performa per kategori.</p>
              </div>
            </div>

            <div class="result-analysis-list">
              ${breakdown.length
                ? breakdown.map((item) => `
                  <div class="result-analysis-item">
                    <div>
                      <strong>${item.category}</strong>
                      <small>${item.correct} benar dari ${item.total} soal</small>
                    </div>
                    <div class="result-analysis-item__score">
                      <span>${item.percent}%</span>
                      <div class="progress-bar"><span style="width:${item.percent}%"></span></div>
                    </div>
                  </div>
                `).join('')
                : `
                  <div class="result-analysis-item">
                    <div>
                      <strong>Keseluruhan</strong>
                      <small>${correct} benar dari ${total} soal</small>
                    </div>
                    <div class="result-analysis-item__score">
                      <span>${score}%</span>
                      <div class="progress-bar"><span style="width:${score}%"></span></div>
                    </div>
                  </div>
                `}
            </div>
          </aside>

          <div class="result-question-card">
            <div class="card-heading">
              <div>
                <h2>Rincian Jawaban</h2>
                <p>Daftar jawaban peserta dan kunci jawaban yang benar.</p>
              </div>
            </div>

            <div class="table-scroll">
              <table class="data-table result-table">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Pertanyaan</th>
                    <th>Jawaban Kamu</th>
                    <th>Kunci Jawaban</th>
                  </tr>
                </thead>
                <tbody>
                  ${questionRows.map((item) => `
                    <tr class="${item.isCorrect ? 'result-row--correct' : 'result-row--wrong'}">
                      <td>${item.number}</td>
                      <td>
                        <strong>${item.question}</strong>
                        <small>${item.category}</small>
                      </td>
                      <td>${item.selected}</td>
                      <td>${item.correct}</td>
                    </tr>
                  `).join('')}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </article>
    </section>
  `;
}

function renderMetricCard(icon, label, value, caption, tone) {
  return `
    <article class="result-metric-card result-metric-card--${tone}">
      <div class="result-metric-card__icon">${icon}</div>
      <div>
        <span>${label}</span>
        <strong>${value}</strong>
        <small>${caption}</small>
      </div>
    </article>
  `;
}

function renderHistoryRows(latestResult, history, historyWithoutLatest) {
  const rows = [];

  if (latestResult?.recordId) {
    const matchingRecord = history.find((item) => item.id === latestResult.recordId);
    if (matchingRecord) {
      rows.push(renderHistoryRow(matchingRecord, true));
    }
  }

  const fallbackList = latestResult?.recordId ? historyWithoutLatest : history;
  rows.push(...fallbackList.map((item) => renderHistoryRow(item, false)));

  return rows.join('');
}

function renderHistoryRow(item, isLatest = false) {
  return `
    <tr${isLatest ? ' class="history-row--latest"' : ''}>
      <td><strong>${item.module}</strong>${isLatest ? '<small>Hasil terbaru</small>' : ''}</td>
      <td>${item.date}</td>
      <td>${formatHistoryScore(item)}</td>
      <td>+${item.points ?? 0}</td>
      <td>${badge(isLatest ? 'Terbaru' : item.status)}</td>
    </tr>
  `;
}

function formatHistoryScore(item) {
  const rawScore = item.rawScore ?? item.correct;
  const total = item.total ?? item.attempts;

  if (Number.isFinite(Number(rawScore)) && Number.isFinite(Number(total)) && Number(total) > 0) {
    return `${rawScore}/${total} (${item.score ?? 0}%)`;
  }

  return String(item.score ?? '-');
}

function buildRankingText(leaderboard = [], myUid = null) {
  const total = leaderboard.length;
  const myIndex = myUid ? leaderboard.findIndex((item) => item.uid === myUid) : -1;
  const myRank = myIndex === -1 ? null : myIndex + 1;

  if (myRank && total) {
    return {
      value: `#${myRank}/${total}`,
      caption: 'Posisi peserta saat ini',
    };
  }

  if (total) {
    return {
      value: `—/${total}`,
      caption: 'Belum masuk leaderboard',
    };
  }

  return {
    value: '—',
    caption: 'Belum ada data ranking',
  };
}

function scoreLabelFromPercent(scorePercent = 0) {
  if (scorePercent >= 85) return 'Sangat Baik';
  if (scorePercent >= 70) return 'Baik';
  if (scorePercent >= 55) return 'Cukup';
  return 'Perlu Latihan';
}
