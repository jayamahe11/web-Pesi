import { dataService } from '../../services/data.service.js';
import { lockService } from '../../services/lock.service.js';
import { showToast } from '../../components/ui/toast.js';
import { shuffleQuestions } from '../../utils/shuffle.js';
import { escapeHtml } from '../../utils/html.js';
import { ICONS, titleIcon } from '../../config/icons.js';
import { enableContentProtection } from '../../utils/content-protection.js';
import { auth } from '../../firebase/config.js';

const LAST_QUIZ_RESULT_KEY = 'bisam_last_quiz_result';

export async function userQuizPage(router){

let questions = [];
let currentIndex = 0;
let answers = {};
let timer = 30 * 60;
let initialTimer = 30 * 60;
let interval = null;
let activeModule = null;
let activeQuizType = 'latihan';
let finished = false;
let disableProtection = () => {};

// ------------------------------------------------------------------
// Penjaga akses: modul yang dikunci admin, atau yang sudah dikerjakan
// peserta ini (kunci otomatis), tidak boleh dimulai — walau URL dibuka
// langsung. Admin bisa membuka kunci lewat Admin > Kunci Soal.
// ------------------------------------------------------------------
const requestedModuleId = sessionStorage.getItem('activeModule');
const requestedType = sessionStorage.getItem('quizType') === 'ujian' ? 'ujian' : 'latihan';
const access = await lockService.getAccess(requestedModuleId);

if(access.locked){

  const backPath = requestedType === 'ujian' ? '/ujian' : '/modules';
  const lockedModule = dataService.getModuleById(requestedModuleId);

  return {
    html:`
    <section class="quiz-page">
      <div class="quiz-card lock-notice">
        <div class="lock-notice__icon">🔒</div>
        <h2>Soal Terkunci</h2>
        <p>
          ${access.reason === 'done'
            ? `Kamu sudah mengerjakan <strong>${escapeHtml(lockedModule?.title ?? 'modul ini')}</strong>, jadi soalnya otomatis terkunci. Hubungi admin kalau ingin mengerjakan ulang — nilai terbaikmu yang dipakai di ranking.`
            : `<strong>${escapeHtml(lockedModule?.title ?? 'Modul ini')}</strong> sedang dikunci oleh admin dan belum bisa dikerjakan.`}
        </p>
        <button class="button button--primary" type="button" id="lock-back">Kembali</button>
      </div>
    </section>`,
    mount(){
      document.getElementById('lock-back')?.addEventListener('click',()=>router.navigate(backPath));
    },
    unmount(){}
  };

}

return {

html:`
<section class="quiz-page">

<div class="quiz-header">
<h2 id="quiz-title">
${titleIcon('modules')} Modul Latihan
</h2>

<div class="timer-box">
${ICONS.stopwatch}
<span id="quiz-timer">
30:00
</span>
</div>
</div>

<div class="quiz-card">
<div id="quiz-content">
Memuat soal...
</div>
</div>

</section>
`,

async mount(){

const moduleId = sessionStorage.getItem('activeModule');
const quizType = sessionStorage.getItem('quizType');
activeQuizType = quizType === 'ujian' ? 'ujian' : 'latihan';
activeModule = dataService.getModuleById(moduleId);

const title = document.getElementById('quiz-title');
if(title){
  title.innerHTML = activeQuizType === 'ujian'
    ? `${titleIcon('exam')} Simulasi Ujian`
    : `${titleIcon('modules')} Modul Latihan`;
}

questions = shuffleQuestions(dataService.getQuestionsByModule(moduleId)).slice(0,50);

const durationMinutes = Number(activeModule?.durationMinutes ?? 30);
initialTimer = durationMinutes * 60;
 timer = initialTimer;

const timerElement = document.getElementById('quiz-timer');
if(timerElement){
  timerElement.innerText = formatDuration(timer);
}

if(!questions.length){
  document.getElementById('quiz-content').innerHTML=`
  <h3>
  Soal belum tersedia
  </h3>
  <p>
  Modul:
  ${moduleId}
  </p>
  `;
  return;
}

// Gambar soal disimpan terpisah; muat dulu sebelum soal ditampilkan.
await dataService.ensureQuestionImages(questions);

disableProtection = enableContentProtection({
  root: document.querySelector('.quiz-page') ?? document.getElementById('quiz-content'),
  watermark: auth.currentUser?.displayName || auth.currentUser?.email || 'BISAM',
});

renderQuestion();
startTimer();

},

unmount(){
clearInterval(interval);
disableProtection();
}

};

function renderQuestion(){

const item = questions[currentIndex];
const container = document.getElementById('quiz-content');

container.innerHTML = `
<div class="question-number">
Soal ${currentIndex+1} / ${questions.length}
</div>

<h3>
${item.question}
</h3>
${item.image ? `<div class="question-image"><img src="${item.image}" alt="Gambar soal" loading="lazy" draggable="false" /></div>` : ''}

<div class="options">
${item.options.map((option,index)=>{
const letter = String.fromCharCode(65+index);
return `
<button
class="answer-btn"
data-answer="${letter}"
>
${letter}. ${option}
</button>
`;
}).join('')}
</div>

<div id="feedback"></div>

<button
class="next-button"
id="next-btn"
style="display:none"
>
${currentIndex === questions.length-1 ? 'Selesai' : 'Soal Berikutnya'}
</button>
`;

 document.querySelectorAll('.answer-btn').forEach(button=>{
  button.onclick = ()=>{
    checkAnswer(button.dataset.answer, item.answer, item.explanation);
  };
 });
}

function checkAnswer(selected, correct, explanation){
const buttons = document.querySelectorAll('.answer-btn');

buttons.forEach(button=>{
  button.disabled = true;

  if(button.dataset.answer === correct){
    button.classList.add('answer-btn--correct');
  }

  if(button.dataset.answer === selected && selected !== correct){
    button.classList.add('answer-btn--wrong');
  }
});

const feedback = document.getElementById('feedback');
const explanationHtml = explanation ? `<p class="quiz-explanation">💡 ${explanation}</p>` : '';

if(selected === correct){
  feedback.innerHTML = `
  <h3 class="quiz-feedback quiz-feedback--correct">
  ✅ Jawaban Benar
  </h3>
  ${explanationHtml}
  `;
}else{
  feedback.innerHTML = `
  <h3 class="quiz-feedback quiz-feedback--wrong">
  ❌ Jawaban Salah
  </h3>
  <p>
  Jawaban benar:
  <b>${correct}</b>
  </p>
  ${explanationHtml}
  `;
}

answers[currentIndex] = selected;

const next = document.getElementById('next-btn');
next.style.display = 'block';
next.onclick = ()=>{
  // Cegah klik ganda: tanpa ini tombol "Selesai" yang diklik dua kali
  // bisa menyimpan hasil (dan poin) dua kali.
  next.disabled = true;
  nextQuestion();
};
}

function nextQuestion(){
currentIndex++;

if(currentIndex >= questions.length){
  finishQuiz('manual');
  return;
}

renderQuestion();
}

function startTimer(){
interval = setInterval(()=>{
  timer--;

  const timerElement = document.getElementById('quiz-timer');
  if(timerElement){
    timerElement.innerText = formatDuration(timer);
  }

  if(timer <= 0){
    clearInterval(interval);
    finishQuiz('timeout');
  }
},1000);
}

async function finishQuiz(reason = 'manual'){
// Hasil hanya boleh disimpan SEKALI per pengerjaan.
if(finished) return;
finished = true;

clearInterval(interval);

const total = questions.length;
let correct = 0;
const categoryMap = new Map();

const questionRows = questions.map((question,index)=>{
  const selected = answers[index] ?? '-';
  const isCorrect = selected === question.answer;

  if(isCorrect){
    correct++;
  }

  const category = question.category || activeModule?.title || 'Umum';
  if(!categoryMap.has(category)){
    categoryMap.set(category, {
      category,
      total: 0,
      correct: 0,
    });
  }

  const categoryEntry = categoryMap.get(category);
  categoryEntry.total += 1;
  if(isCorrect){
    categoryEntry.correct += 1;
  }

  return {
    number: index + 1,
    question: question.question || '(Soal bergambar)',
    category,
    selected,
    correct: question.answer,
    isCorrect,
  };
});

const wrong = total - correct;
const scorePercent = total ? Math.round((correct / total) * 100) : 0;
const points = correct;
const durationSpentSeconds = Math.max(0, initialTimer - timer);
const categoryBreakdown = Array.from(categoryMap.values()).map((item)=>({
  ...item,
  wrong: item.total - item.correct,
  percent: item.total ? Math.round((item.correct / item.total) * 100) : 0,
}));

const result = {
  moduleId: activeModule?.id ?? sessionStorage.getItem('activeModule') ?? '-',
  moduleTitle: activeModule?.title ?? 'Modul Quiz',
  moduleIcon: activeModule?.icon ?? '📝',
  quizType: activeQuizType,
  score: scorePercent,
  rawScore: correct,
  wrong,
  total,
  points,
  accuracy: scorePercent,
  durationSpentSeconds,
  durationSpentLabel: formatDuration(durationSpentSeconds),
  durationTotalSeconds: initialTimer,
  durationTotalLabel: formatDuration(initialTimer),
  completedAt: new Date().toISOString(),
  statusLabel: scoreLabelFromPercent(scorePercent),
  categoryBreakdown,
  questionRows,
  finishReason: reason,
};

const savedRecord = dataService.recordResult({
  moduleId: result.moduleId,
  moduleTitle: result.moduleTitle,
  score: result.score,
  points: result.points,
  detail: {
    quizType: result.quizType,
    moduleIcon: result.moduleIcon,
    rawScore: result.rawScore,
    wrong: result.wrong,
    total: result.total,
    accuracy: result.accuracy,
    durationSpentSeconds: result.durationSpentSeconds,
    durationSpentLabel: result.durationSpentLabel,
    durationTotalSeconds: result.durationTotalSeconds,
    durationTotalLabel: result.durationTotalLabel,
    completedAt: result.completedAt,
    statusLabel: result.statusLabel,
    categoryBreakdown: result.categoryBreakdown,
    questionRows: result.questionRows,
    finishReason: result.finishReason,
  }
});

sessionStorage.setItem(LAST_QUIZ_RESULT_KEY, JSON.stringify({
  ...result,
  recordId: savedRecord?.id ?? null,
}));

// Tunggu poin, kunci modul, dan riwayat tersimpan (maks. 6 detik) supaya
// modul sudah terkunci sebelum peserta kembali ke daftar modul.
const container = document.getElementById('quiz-content');
if(container){
  container.innerHTML = '<h3>Menyimpan hasil...</h3><p>Jangan tutup halaman ini.</p>';
}

await Promise.race([
  savedRecord?.ready ?? Promise.resolve(),
  new Promise((resolve)=>setTimeout(resolve, 6000)),
]);

showToast('Hasil tersimpan. Modul ini sekarang terkunci.', 'success');

router.navigate('/history');
}

function formatDuration(totalSeconds = 0){
const safeValue = Math.max(0, Number(totalSeconds) || 0);
const hour = Math.floor(safeValue / 3600);
const minute = Math.floor((safeValue % 3600) / 60);
const second = safeValue % 60;

if(hour > 0){
  return `${hour}:${String(minute).padStart(2,'0')}:${String(second).padStart(2,'0')}`;
}

return `${minute}:${String(second).padStart(2,'0')}`;
}

function scoreLabelFromPercent(scorePercent = 0){
if(scorePercent >= 85) return 'Sangat Baik';
if(scorePercent >= 70) return 'Baik';
if(scorePercent >= 55) return 'Cukup';
return 'Perlu Latihan';
}
}
