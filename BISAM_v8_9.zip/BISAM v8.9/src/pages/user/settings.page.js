import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { dataService } from '../../services/data.service.js';
import { qs } from '../../utils/dom.js';

export async function userSettingsPage() {
  const user = await dataService.getCurrentUser();

  return {
    html: `
      ${pageHeading({
        title: 'Pengaturan',
        description: 'Kelola profil dan data latihan akun.',
      })}

      <section class="grid grid--2">
        <form class="card" id="profile-form">
          <div class="card-heading">
            <div>
              <h2>Profil</h2>
              <p>Nama di sini akan dipakai di seluruh aplikasi (dashboard, ranking, riwayat) dan disimpan ke akun Anda.</p>
            </div>
          </div>

          <div class="form-field">
            <label for="profile-name">Nama</label>
            <input id="profile-name" name="name" value="${user?.name ?? ''}" required />
          </div>

          <div class="form-field">
            <label for="profile-email">Email</label>
            <input id="profile-email" name="email" type="email" value="${user?.email ?? ''}" disabled />
          </div>

          <div class="form-field">
            <label for="profile-whatsapp">WhatsApp</label>
            <input id="profile-whatsapp" name="whatsapp" value="${user?.whatsapp ?? ''}" />
          </div>

          <button class="button button--primary" type="submit">Simpan Profil</button>
        </form>

        <article class="card">
          <div class="card-heading">
            <div>
              <h2>Data Latihan</h2>
              <p>Reset hanya menghapus progres, hasil, dan poin latihan. Profil tetap tersimpan.</p>
            </div>
          </div>
          <div class="button-group">
            <button class="button button--outline" id="change-password" type="button">Ubah Password</button>
            <button class="button button--danger" id="reset-member-data" type="button">Reset Data Latihan</button>
          </div>
        </article>
      </section>
    `,

    mount() {
      qs('#profile-form')?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const form = new FormData(event.currentTarget);
        const submitButton = event.currentTarget.querySelector('button[type="submit"]');

        if (submitButton) submitButton.disabled = true;

        try {
          await dataService.updateCurrentUser({
            name: String(form.get('name') ?? '').trim(),
            whatsapp: String(form.get('whatsapp') ?? '').trim(),
          });
          showToast('Profil berhasil disimpan.', 'success');
          // Muat ulang route saat ini supaya nama baru langsung tampil
          // di sidebar/topbar dan halaman lain.
          window.location.reload();
        } catch (error) {
          console.error(error);
          showToast('Gagal menyimpan profil.', 'error');
        } finally {
          if (submitButton) submitButton.disabled = false;
        }
      });

      qs('#change-password')?.addEventListener('click', () => {
        showToast('Password akan dikelola oleh Firebase Authentication.', 'warning');
      });

      qs('#reset-member-data')?.addEventListener('click', () => {
        const confirmed = window.confirm('Hapus seluruh progres, hasil, dan poin latihan akun ini?');
        if (!confirmed) return;
        dataService.resetCurrentMember();
        showToast('Data latihan sudah dikembalikan seperti member baru.', 'success');
        window.location.hash = '#/dashboard';
      });
    },
  };
}
