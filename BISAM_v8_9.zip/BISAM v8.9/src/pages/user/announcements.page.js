import { emptyState } from '../../components/ui/empty-state.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { dataService } from '../../services/data.service.js';

export function userAnnouncementsPage() {
  const announcements = dataService.getAnnouncements();

  return {
    html: `
      ${pageHeading({
        title: 'Pengumuman',
        description: 'Informasi terbaru dari Bintang Samudra.',
      })}

      <section class="content-list content-list--cards">
        ${announcements.length ? announcements.map((item) => `
          <article class="card announcement-card">
            <small>${item.date}</small>
            <h2>${item.title}</h2>
            <p>${item.content}</p>
          </article>
        `).join('') : emptyState({
          title: 'Belum ada pengumuman',
          description: 'Pengumuman baru dari admin akan muncul di sini.',
        })}
      </section>
    `,
  };
}
