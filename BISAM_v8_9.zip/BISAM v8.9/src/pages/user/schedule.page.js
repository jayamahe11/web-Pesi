import { badge } from '../../components/ui/badge.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { dataService } from '../../services/data.service.js';

export function userSchedulePage() {
  const schedules = dataService.getSchedules();

  return {
    html: `
      ${pageHeading({
        title: 'Jadwal Tes',
        description: 'Jadwal yang dibuat admin akan tampil di halaman ini.',
      })}

      <section class="grid grid--2">
        ${schedules.length ? schedules.map((item) => `
          <article class="card schedule-card">
            <div class="card-heading">
              <div>
                <h2>${item.name}</h2>
                <p>${item.date}</p>
              </div>
              ${badge(item.status)}
            </div>
            <div class="schedule-card__meta">
              <span><small>Jam</small><strong>${item.time}</strong></span>
              <span><small>Durasi</small><strong>${item.duration}</strong></span>
            </div>
          </article>
        `).join('') : emptyState({
          title: 'Belum ada jadwal',
          description: 'Akun baru belum memiliki agenda tes terjadwal.',
        })}
      </section>
    `,
  };
}
