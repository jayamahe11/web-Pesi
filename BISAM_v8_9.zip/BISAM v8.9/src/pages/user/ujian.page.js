import { pageHeading } from '../../components/ui/page-heading.js';
import { dataService } from '../../services/data.service.js';
import { lockService } from '../../services/lock.service.js';
import { showToast } from '../../components/ui/toast.js';
import { EXAM_MODULE_IDS, moduleCategory } from '../../data/modules.data.js';
import { qsa } from '../../utils/dom.js';

const DEFAULT_DURATION_MINUTES = 30;

function card(module, reason = null) {
  const icon = module.icon ?? '📝';
  const title = module.title;
  const description = module.description ?? 'Simulasi ujian seleksi BISAM';
  const itemCount = module.itemCountLabel ?? '50 soal';
  const duration = `${module.durationMinutes ?? DEFAULT_DURATION_MINUTES} menit`;

  return `
    <article class="module-card module-card--exam ${reason ? 'module-card--locked' : ''}" data-module-id="${module.id}" data-lock="${reason ?? ''}">
      <div class="module-icon">${icon}</div>

      <h3>${title}</h3>
      <p>${description}</p>

      <div class="module-meta">
        <span class="module-meta__item module-meta__item--brand">${itemCount}</span>
        <span class="module-meta__item">⏱ ${duration}</span>
      </div>

      ${reason ? `<div class="module-lock-badge">${reason === 'done' ? '🔒 Sudah dikerjakan' : '🔒 Dikunci admin'}</div>` : ''}

      <button
        class="button button--primary button--block"
        type="button"
        data-start="${module.id}"
        ${reason ? 'aria-disabled="true"' : ''}
      >${reason ? 'Terkunci' : 'Mulai Ujian'}</button>
    </article>
  `;
}

export async function userExamPage(router) {
  const modules = dataService
    .getModules()
    .filter((module) => (
      module.custom
        ? module.active && moduleCategory(module) === 'ujian'
        : EXAM_MODULE_IDS.includes(module.id)
    ));

  const access = await lockService.getAccessMap();

  function startExam(moduleId) {
    if (!moduleId) return;

    const reason = access.reasonFor(moduleId);
    if (reason) {
      showToast(
        reason === 'done'
          ? 'Ujian ini sudah kamu kerjakan dan terkunci. Hubungi admin untuk membukanya.'
          : 'Ujian ini sedang dikunci oleh admin.',
        'warning'
      );
      return;
    }

    sessionStorage.setItem('quizType', 'ujian');
    sessionStorage.setItem('activeModule', moduleId);
    router.navigate('/quiz');
  }

  return {
    html: `
      <section class="modules-page exam-page">
        ${pageHeading({
          title: 'Modul Ujian',
          description: 'Simulasi ujian TIU, TWK, dan TKD dengan waktu terbatas.',
        })}

        <div class="modules-grid module-catalog-grid">
          ${modules.map((module) => card(module, access.reasonFor(module.id))).join('')}
        </div>
      </section>
    `,

    mount() {
      qsa('[data-module-id]').forEach((cardElement) => {
        cardElement.addEventListener('click', () => {
          startExam(cardElement.dataset.moduleId);
        });
      });

      qsa('[data-start]').forEach((button) => {
        button.addEventListener('click', (event) => {
          event.stopPropagation();
          startExam(button.dataset.start);
        });
      });
    },

    unmount() {},
  };
}
