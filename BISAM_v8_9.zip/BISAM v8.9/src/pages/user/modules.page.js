import { dataService } from '../../services/data.service.js';
import { lockService } from '../../services/lock.service.js';
import { moduleCategory } from '../../data/modules.data.js';
import { showToast } from '../../components/ui/toast.js';



export async function userModulesPage(router){



const modules = 
dataService
.getModules()
.filter(module => module.custom
    ? (module.active && moduleCategory(module) === 'latihan')
    : [
        "logika",
        "numerik",
        "verbal",
        "sinonim",
        "analogi",
        "deret",
        "matematika",
        "analitis",
        "ketelitian",
        "spasial",
        "konsentrasi",
        "kepribadian",
        "pauli-kraepelin"
    ]
    .includes(module.id)
);





// Status kunci: dikunci admin / sudah dikerjakan (kunci otomatis).
const access = await lockService.getAccessMap();

function lockInfo(module){
  if((module.engine ?? 'quiz') !== 'quiz') return null;
  const reason = access.reasonFor(module.id);
  if(!reason) return null;
  return reason === 'done'
    ? { reason, label:'🔒 Sudah dikerjakan', hint:'Minta admin membuka kunci untuk mengulang.' }
    : { reason, label:'🔒 Dikunci admin', hint:'Belum bisa dikerjakan.' };
}

return {



html:`


<section class="modules-page">



<div class="profile-title">


<h1>

📚 Modul Latihan

</h1>



<p>

Pilih latihan kemampuan dasar yang ingin dikerjakan

</p>


</div>







<div class="modules-grid">



${modules.map(module=>`



<article

class="module-card ${lockInfo(module) ? 'module-card--locked' : ''}"

data-module="${module.id}"

data-engine="${module.engine ?? 'quiz'}"

data-lock="${lockInfo(module)?.reason ?? ''}"

>



<div class="module-icon">

${module.icon ?? "📘"}

</div>





<h3>

${module.title}

</h3>





<p>

${module.description 
??
"Latihan psikotes dan kemampuan dasar"}

</p>





<span>

${module.itemCountLabel 
??
"50 soal"}

</span>

${lockInfo(module) ? `<div class="module-lock-badge" title="${lockInfo(module).hint}">${lockInfo(module).label}</div>` : ''}





</article>



`).join("")}




</div>




</section>


`,







mount(){



document
.querySelectorAll(".module-card")
.forEach(card=>{



card.addEventListener(
"click",
()=>{



const moduleId =
card.dataset.module;

const engine =
card.dataset.engine;

if(card.dataset.lock){

showToast(
card.dataset.lock === 'done'
? 'Modul ini sudah kamu kerjakan dan terkunci. Hubungi admin untuk membukanya.'
: 'Modul ini sedang dikunci oleh admin.',
'warning'
);

return;

}

if(engine === "pauli-kraepelin"){
router.navigate("/pauli-kraepelin");
return;
}





// jenis soal

sessionStorage.setItem(
"quizType",
"latihan"
);





// modul yang dipilih

sessionStorage.setItem(
"activeModule",
moduleId
);





// masuk halaman quiz

router.navigate(
"/quiz"
);



}

);



});



},






unmount(){



}





};



}