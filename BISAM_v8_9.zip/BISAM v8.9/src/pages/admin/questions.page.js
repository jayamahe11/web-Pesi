import { emptyState } from '../../components/ui/empty-state.js';
import { modal, openModal, closeModal, bindModalDismiss } from '../../components/ui/modal.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { dataService } from '../../services/data.service.js';
import { moduleCategory } from '../../data/modules.data.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';
import { compressImageFile } from '../../utils/image.js';
import { buildCustomFileSource } from '../../utils/custom-export.js';

function questionModal(modules) {
  return modal({
    id: 'question-modal',
    title: 'Soal',
    description: 'Opsi dipisahkan baris baru. Tandai jawaban benar dengan huruf (A, B, C, ...) sesuai urutan opsi.',
    size: 'lg',
    body: `
      <form id="question-form">
        <input type="hidden" name="id" />
        <div class="form-grid form-grid--2">
          <div class="form-field"><label>Modul</label><select name="moduleId" required>${modules.map((module) => `<option value="${escapeHtml(module.id)}">${escapeHtml(module.title)} — ${moduleCategory(module) === 'ujian' ? 'Ujian' : 'Belajar'}</option>`).join('')}</select></div>
          <div class="form-field"><label>Kategori</label><input name="category" placeholder="Opsional, default: nama modul" /></div>
          <div class="form-field form-field--full"><div class="question-number-hint" id="question-number-hint"></div></div>
          <div class="form-field form-field--full"><label>Pertanyaan</label><textarea name="question" rows="3" placeholder="Tulis pertanyaan di sini... (boleh kosong jika memakai gambar)"></textarea></div>
          <div class="form-field form-field--full">
            <label>Gambar Soal (opsional)</label>
            <input type="file" id="question-image-input" accept="image/*" />
            <div class="question-image-preview" id="question-image-preview" hidden>
              <img id="question-image-preview-img" alt="Pratinjau gambar soal" />
              <button class="button button--danger button--small" type="button" id="question-image-remove">Hapus gambar</button>
            </div>
            <small class="form-hint" id="question-image-hint">Bisa foto/gambar (JPG, PNG, WebP). Otomatis dikecilkan agar ringan. Pertanyaan teks tetap boleh diisi sebagai keterangan.</small>
          </div>
          <div class="form-field form-field--full"><label>Opsi Jawaban (satu opsi per baris)</label><textarea name="options" rows="4" required placeholder="Contoh:&#10;Opsi pertama&#10;Opsi kedua&#10;Opsi ketiga&#10;Opsi keempat"></textarea></div>
          <div class="form-field"><label>Jawaban Benar</label><select name="answer" required><option value="A">A</option><option value="B">B</option><option value="C">C</option><option value="D">D</option><option value="E">E</option></select></div>
          <div class="form-field form-field--full"><label>Pembahasan (opsional)</label><textarea name="explanation" rows="2" placeholder="Penjelasan jawaban..."></textarea></div>
        </div>
      </form>
    `,
    footer: '<button class="button button--outline" type="button" data-modal-close="question-modal">Batal</button><button class="button button--primary" type="submit" form="question-form">Simpan Soal</button>',
  });
}

export function adminQuestionsPage(router) {
  const modules = dataService.getModules().filter((module) => module.engine === 'quiz');
  const PAGE_SIZE = 25;
  let unbindModal = null;
  const preselected = dataService.getAdminUiState()?.selectedQuestionModuleId;
  let activeModuleFilter = modules.some((module) => module.id === preselected) ? preselected : 'all';
  let searchTerm = '';
  let visibleCount = PAGE_SIZE;

  const getModuleName = (id) => dataService.getModuleById(id)?.title ?? id;

  return {
    html: `
      ${pageHeading({
        title: '📝 Kelola Soal',
        description: `${dataService.getQuestions().length} soal tersimpan di seluruh modul.`,
        action: `<div class="button-group"><button class="button button--outline" id="export-custom" type="button" title="Unduh semua soal & modul buatan manual sebagai file kode (custom.js)">⬇ Unduh kode soal manual</button><button class="button button--primary" id="add-question" type="button" ${modules.length ? '' : 'disabled'}>+ Tambah Soal</button></div>`,
      })}

      <article class="card">
        <div class="toolbar toolbar--spread">
          <div class="toolbar__group">
            <input class="input input--compact" id="question-search" type="search" placeholder="Cari soal..." />
            <select class="input input--compact" id="question-module-filter">
              <option value="all">Semua Modul</option>
              ${modules.map((module) => `<option value="${escapeHtml(module.id)}">${escapeHtml(module.title)} — ${moduleCategory(module) === 'ujian' ? 'Ujian' : 'Belajar'}</option>`).join('')}
            </select>
          </div>
          <span class="toolbar__count" id="question-count"></span>
        </div>

        <div id="question-list" class="section-gap--small"></div>
      </article>
      ${questionModal(modules)}
    `,

    mount() {
      unbindModal = bindModalDismiss();
      const list = qs('#question-list');
      const form = qs('#question-form');
      const countLabel = qs('#question-count');

      function render() {
        const all = dataService.getQuestions();
        const keyword = searchTerm.trim().toLowerCase();

        // Nomor soal per modul (urut sesuai urutan di bank soal), supaya
        // admin tahu sudah berapa soal yang diberikan pada tiap modul.
        const numberById = new Map();
        const totalByModule = new Map();
        all.forEach((q) => {
          const next = (totalByModule.get(q.moduleId) ?? 0) + 1;
          totalByModule.set(q.moduleId, next);
          numberById.set(String(q.id), next);
        });

        const items = all.filter((q) => {
          const matchModule = activeModuleFilter === 'all' || q.moduleId === activeModuleFilter;
          if (!matchModule) return false;
          if (!keyword) return true;
          return `${q.question ?? ''} ${q.category ?? ''}`.toLowerCase().includes(keyword);
        });

        const shown = items.slice(0, visibleCount);
        const remaining = items.length - shown.length;

        const moduleTotalNote = activeModuleFilter !== 'all'
          ? ` — modul ini sudah punya ${totalByModule.get(activeModuleFilter) ?? 0} soal`
          : '';

        countLabel.textContent = (remaining > 0
          ? `Menampilkan ${shown.length} dari ${items.length} soal`
          : `${items.length} soal`) + moduleTotalNote;

        list.innerHTML = items.length
          ? shown.map((q) => `
              <div class="admin-card" data-question-row>
                <div class="admin-card__head">
                  <span class="question-number-badge" title="Soal ke-${numberById.get(String(q.id))} pada modul ${escapeHtml(getModuleName(q.moduleId))}">${numberById.get(String(q.id))}</span>
                  <div>
                    <h3>${escapeHtml(q.category || getModuleName(q.moduleId))}</h3>
                    <small>${escapeHtml(getModuleName(q.moduleId))} • Jawaban benar: ${escapeHtml(q.answer ?? '-')}${q.hasImage || q.image ? ' • 🖼 ada gambar' : ''}</small>
                  </div>
                </div>
                <p>${escapeHtml(q.question)}</p>
                ${q.hasImage || q.image ? `<div class="admin-question-thumb" data-thumb-for="${escapeHtml(q.id)}">${q.image ? `<img src="${escapeHtml(q.image)}" alt="Gambar soal" />` : ''}</div>` : ''}
                <div class="button-group button-group--nowrap">
                  <button class="button button--soft button--small" type="button" data-edit-question="${escapeHtml(q.id)}">Edit</button>
                  <button class="button button--danger button--small" type="button" data-delete-question="${escapeHtml(q.id)}">Hapus</button>
                </div>
              </div>
            `).join('') + (remaining > 0
              ? `<div class="question-load-more"><button class="button button--outline" type="button" id="load-more-questions">Muat ${Math.min(remaining, PAGE_SIZE)} soal lagi (${remaining} tersisa)</button></div>`
              : '')
          : emptyState({
              title: 'Belum ada soal pada modul ini',
              description: 'Klik "Tambah Soal" untuk menambahkan soal baru.',
            });

        // Gambar soal buatan admin dimuat terpisah (lazy).
        const needThumbs = shown.filter((q) => q.hasImage && !q.image);
        if (needThumbs.length) {
          dataService.ensureQuestionImages(needThumbs).then(() => {
            needThumbs.forEach((q) => {
              const box = qs(`[data-thumb-for="${CSS.escape(String(q.id))}"]`);
              if (box && q.image) box.innerHTML = `<img src="${escapeHtml(q.image)}" alt="Gambar soal" />`;
            });
          });
        }

        qs('#load-more-questions')?.addEventListener('click', () => {
          visibleCount += PAGE_SIZE;
          render();
        });

        qsa('[data-edit-question]').forEach((button) => {
          button.addEventListener('click', () => {
            const item = dataService.getQuestions().find((row) => String(row.id) === button.dataset.editQuestion);
            if (!item || !form) return;
            form.elements.id.value = item.id;
            form.elements.moduleId.value = item.moduleId ?? '';
            form.elements.moduleId.disabled = true;
            form.elements.category.value = item.category ?? '';
            form.elements.question.value = item.question ?? '';
            form.elements.options.value = (item.options ?? []).join('\n');
            form.elements.answer.value = item.answer ?? 'A';
            form.elements.explanation.value = item.explanation ?? '';
            setImageState({
              hasImage: Boolean(item.hasImage || item.image),
              image: item.image ?? null,
              // Soal bawaan aplikasi disimpan lokal, gambar hanya untuk soal buatan admin.
              allowImage: Boolean(item.custom),
              id: item.id,
              item,
            });
            updateNumberHint(item.moduleId, numberOfQuestion(item));
            openModal('question-modal');
          });
        });

        qsa('[data-delete-question]').forEach((button) => {
          button.addEventListener('click', async () => {
            const item = dataService.getQuestions().find((row) => String(row.id) === button.dataset.deleteQuestion);
            if (!item || !window.confirm('Hapus soal ini?')) return;

            try {
              if (item.custom) {
                await dataService.deleteCustomQuestion(item.id);
              } else {
                dataService.deleteQuestion(item.id);
              }
            } catch (error) {
              console.error('[BISAM] Gagal menghapus soal:', error);
              showToast('Gagal menghapus soal. Cek rules Firestore.', 'error');
              return;
            }

            showToast('Soal dihapus.', 'success');
            render();
          });
        });
      }

      const moduleFilterSelect = qs('#question-module-filter');
      if (moduleFilterSelect) moduleFilterSelect.value = activeModuleFilter;

      render();

      // ------------------------------------------------------------------
      // Gambar soal + nomor soal di form
      // ------------------------------------------------------------------
      const imageInput = qs('#question-image-input');
      const imagePreview = qs('#question-image-preview');
      const imagePreviewImg = qs('#question-image-preview-img');
      const imageHint = qs('#question-image-hint');
      const numberHint = qs('#question-number-hint');
      let imageState = { hasImage: false, image: null, allowImage: true, id: null, item: null };
      let pendingImage = null;   // data URL gambar baru yang dipilih
      let removeImage = false;   // true = hapus gambar lama

      function numberOfQuestion(item) {
        const sameModule = dataService.getQuestions().filter((q) => q.moduleId === item.moduleId);
        return sameModule.findIndex((q) => String(q.id) === String(item.id)) + 1;
      }

      function updateNumberHint(moduleId, number) {
        if (!numberHint) return;
        const total = dataService.getQuestions().filter((q) => q.moduleId === moduleId).length;
        numberHint.textContent = number
          ? `Mengedit soal nomor ${number} dari ${total} soal pada modul ini.`
          : `Ini akan menjadi soal nomor ${total + 1} (modul ini sudah punya ${total} soal).`;
      }

      function refreshImagePreview() {
        const src = pendingImage ?? (removeImage ? null : imageState.image);
        if (imagePreview && imagePreviewImg) {
          imagePreview.hidden = !src;
          if (src) imagePreviewImg.src = src;
        }
      }

      async function setImageState(next) {
        imageState = next;
        pendingImage = null;
        removeImage = false;
        if (imageInput) {
          imageInput.value = '';
          imageInput.disabled = !next.allowImage;
        }
        if (imageHint) {
          imageHint.textContent = next.allowImage
            ? 'Bisa foto/gambar (JPG, PNG, WebP). Otomatis dikecilkan agar ringan. Pertanyaan teks tetap boleh diisi sebagai keterangan.'
            : 'Soal bawaan aplikasi tidak bisa diberi gambar baru. Buat soal baru kalau ingin memakai gambar.';
        }
        refreshImagePreview();

        // Soal buatan admin: gambarnya disimpan terpisah, muat dulu untuk pratinjau.
        if (next.item && next.hasImage && !next.image) {
          await dataService.ensureQuestionImages([next.item]);
          if (imageState === next) {
            next.image = next.item.image ?? null;
            refreshImagePreview();
          }
        }
      }

      imageInput?.addEventListener('change', async () => {
        const file = imageInput.files?.[0];
        if (!file) return;
        try {
          pendingImage = await compressImageFile(file);
          removeImage = false;
          refreshImagePreview();
        } catch (error) {
          pendingImage = null;
          imageInput.value = '';
          showToast(error.message || 'Gambar gagal diproses.', 'danger');
          refreshImagePreview();
        }
      });

      qs('#question-image-remove')?.addEventListener('click', () => {
        pendingImage = null;
        removeImage = true;
        if (imageInput) imageInput.value = '';
        refreshImagePreview();
      });

      form?.elements.moduleId.addEventListener('change', () => {
        if (!form.elements.id.value) updateNumberHint(form.elements.moduleId.value, null);
      });

      const showAdd = () => {
        form?.reset();
        if (form) {
          form.elements.id.value = '';
          form.elements.moduleId.disabled = false;
          form.elements.moduleId.value = activeModuleFilter !== 'all' ? activeModuleFilter : (modules[0]?.id ?? '');
          form.elements.answer.value = 'A';
        }
        setImageState({ hasImage: false, image: null, allowImage: true, id: null, item: null });
        updateNumberHint(form?.elements.moduleId.value, null);
        openModal('question-modal');
      };

      qs('#add-question')?.addEventListener('click', showAdd);

      // Soal manual -> file kode. Isi file sama persis dengan hasil
      // `npm run export:custom` (src/data/questions/custom.js).
      qs('#export-custom')?.addEventListener('click', async (event) => {
        const button = event.currentTarget;
        const customQuestions = dataService.getQuestions().filter((q) => q.custom);
        const customModules = dataService.getModules().filter((m) => m.custom);

        if (!customQuestions.length && !customModules.length) {
          showToast('Belum ada soal/modul manual untuk diunduh.', 'error');
          return;
        }

        button.disabled = true;
        try {
          await dataService.ensureQuestionImages(customQuestions);
          const source = buildCustomFileSource({ modules: customModules, questions: customQuestions });
          const url = URL.createObjectURL(new Blob([source], { type: 'text/javascript;charset=utf-8' }));
          const link = document.createElement('a');
          link.href = url;
          link.download = 'custom.js';
          document.body.append(link);
          link.click();
          link.remove();
          window.setTimeout(() => URL.revokeObjectURL(url), 1000);
          showToast(`custom.js diunduh (${customQuestions.length} soal, ${customModules.length} modul). Simpan di src/data/questions/.`);
        } catch (error) {
          console.error('[BISAM] Gagal membuat custom.js:', error);
          showToast('Gagal membuat file kode soal manual.', 'error');
        } finally {
          button.disabled = false;
        }
      });

      qs('#question-module-filter')?.addEventListener('change', (event) => {
        activeModuleFilter = event.currentTarget.value;
        visibleCount = PAGE_SIZE;
        render();
      });

      qs('#question-search')?.addEventListener('input', (event) => {
        searchTerm = event.currentTarget.value;
        visibleCount = PAGE_SIZE;
        render();
      });

      form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const values = Object.fromEntries(new FormData(form).entries());
        const id = String(values.id || '');
        const existing = id
          ? dataService.getQuestions().find((row) => String(row.id) === id)
          : null;
        const options = String(values.options || '')
          .split('\n')
          .map((line) => line.trim())
          .filter(Boolean);

        const hasImageNow = Boolean(pendingImage) || (!removeImage && Boolean(imageState.hasImage || imageState.image));
        if (!String(values.question || '').trim() && !hasImageNow) {
          showToast('Isi pertanyaan atau tambahkan gambar soal.', 'danger');
          return;
        }

        if (options.length < 2) {
          showToast('Minimal 2 opsi jawaban diperlukan.', 'danger');
          return;
        }

        const answer = String(values.answer || 'A');
        const answerIndex = answer.charCodeAt(0) - 65;
        if (answerIndex < 0 || answerIndex >= options.length) {
          showToast(`Jawaban benar ${answer} tidak ada, opsi baru terisi ${options.length}.`, 'danger');
          return;
        }

        // Saat edit, select modul dikunci (disabled) sehingga tidak ikut
        // terkirim — ambil dari data soal aslinya.
        const moduleId = String(values.moduleId || existing?.moduleId || '');
        const module = dataService.getModuleById(moduleId);

        const payload = {
          moduleId,
          category: String(values.category || '').trim() || module?.title || '',
          question: String(values.question || '').trim(),
          options,
          answer,
          explanation: String(values.explanation || '').trim(),
        };

        const saveButton = qs('button[form="question-form"]');
        if (saveButton) saveButton.disabled = true;

        // Soal BARU (modul apa pun) dan soal buatan admin disimpan di
        // Firestore supaya langsung sampai ke semua peserta. Hanya soal
        // bawaan aplikasi yang diedit tetap tersimpan lokal.
        const saveShared = !id || Boolean(existing?.custom) || Boolean(module?.custom);

        try {
          if (saveShared) {
            await dataService.saveCustomQuestion({
              ...(existing ?? {}),
              ...payload,
              id: id || undefined,
              imageData: pendingImage || undefined,
              removeImage: removeImage && !pendingImage,
            });
          } else {
            dataService.updateQuestion(id, payload);
          }
        } catch (error) {
          console.error('[BISAM] Gagal menyimpan soal:', error);
          showToast('Gagal menyimpan soal. Pastikan rules Firestore terbaru sudah di-publish.', 'error');
          if (saveButton) saveButton.disabled = false;
          return;
        }

        if (saveButton) saveButton.disabled = false;
        closeModal('question-modal');
        const totalNow = dataService.getQuestions().filter((q) => q.moduleId === moduleId).length;
        showToast(id ? 'Soal diperbarui.' : `Soal ke-${totalNow} berhasil ditambahkan.`, 'success');
        render();
      });
    },

    unmount() {
      unbindModal?.();
    },
  };
}
