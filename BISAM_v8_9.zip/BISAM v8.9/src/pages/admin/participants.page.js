import { badge } from '../../components/ui/badge.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { modal, openModal, closeModal, bindModalDismiss } from '../../components/ui/modal.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { firebaseRepository } from '../../repositories/firebase.repository.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';

function formatDate(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '-';
  return new Intl.DateTimeFormat('id-ID', { day: '2-digit', month: 'short', year: 'numeric' }).format(date);
}

function participantModal() {
  return modal({
    id: 'participant-modal',
    title: 'Data Peserta',
    description: 'Isi data yang dibutuhkan untuk administrasi peserta.',
    size: 'lg',
    body: `
      <form id="participant-form">
        <input type="hidden" name="id" />
        <div class="form-grid form-grid--2">
          <div class="form-field"><label>Nama Lengkap</label><input name="name" required autocomplete="off" /></div>
          <div class="form-field"><label>Email</label><input name="email" type="email" autocomplete="off" /></div>
          <div class="form-field"><label>Nomor WhatsApp</label><input name="whatsapp" autocomplete="off" placeholder="08xxxxxxxxxx" /></div>
          <div class="form-field"><label>Jenis Program</label><select name="type"><option value="-">Belum diatur</option><option>BINJAS</option><option>PSI</option><option>BINJAS & PSI</option></select></div>
          <div class="form-field"><label>Instansi</label><input name="institution" autocomplete="off" placeholder="Opsional" /></div>
          <div class="form-field"><label>Status</label><select name="status"><option>Aktif</option><option>Nonaktif</option></select></div>
        </div>
      </form>
    `,
    footer: `
      <button class="button button--outline" type="button" data-modal-close="participant-modal">Batal</button>
      <button class="button button--primary" type="submit" form="participant-form">Simpan Peserta</button>
    `,
  });
}

export async function adminParticipantsPage(router) {
  // Sumber data: collection Firestore `users` — semua yang mendaftar lewat
  // email maupun Google otomatis muncul di sini.
  let participants = [];
  let loadError = null;

  try {
    participants = await firebaseRepository.getParticipants();
  } catch (error) {
    console.error('[BISAM] Gagal memuat peserta:', error);
    loadError = error;
  }

  let unbindModal = null;

  return {
    html: `
      ${pageHeading({
        title: 'Kelola Peserta',
        description: 'Data peserta yang mendaftar atau ditambahkan oleh administrator.',
        action: '<button class="button button--primary" id="add-participant" type="button">+ Tambah Peserta</button>',
      })}

      ${loadError ? `<div class="notice-box notice-box--neutral section-gap--small">Daftar peserta gagal dimuat (${escapeHtml(loadError?.code || loadError?.message || 'error')}). Pastikan akun ini berstatus admin dan security rules Firestore terbaru (<code>src/firebase/firestore.rules.example</code>) sudah di-publish.</div>` : ''}

      <article class="card">
        <div class="toolbar toolbar--spread">
          <div class="toolbar__group">
            <input class="input input--compact" id="participant-search" placeholder="Cari nama, email, atau instansi..." />
            <select class="input input--compact" id="participant-type"><option value="all">Semua Program</option><option>BINJAS</option><option>PSI</option><option>BINJAS & PSI</option></select>
            <select class="input input--compact" id="participant-status"><option value="all">Semua Status</option><option>Aktif</option><option>Nonaktif</option></select>
          </div>
          <span class="toolbar__count" id="participant-count">${participants.length} peserta</span>
        </div>

        ${participants.length ? `
          <div class="table-scroll">
            <table class="data-table">
              <thead><tr><th>Peserta</th><th>Kontak</th><th>Program</th><th>Instansi</th><th>Terdaftar</th><th>Status</th><th class="table-actions">Aksi</th></tr></thead>
              <tbody>
                ${participants.map((participant) => `
                  <tr data-participant-row data-search="${escapeHtml(`${participant.name} ${participant.email} ${participant.institution}`.toLowerCase())}" data-type="${escapeHtml(participant.type)}" data-status="${escapeHtml(participant.status)}">
                    <td><div class="table-person"><span class="table-person__avatar">${escapeHtml(participant.name?.slice(0, 1).toUpperCase() || 'P')}</span><div><strong>${escapeHtml(participant.name)}</strong><small>${escapeHtml(participant.loginMethod)} • ID: ${escapeHtml(String(participant.id).slice(0, 8))}</small></div></div></td>
                    <td><strong class="table-secondary">${escapeHtml(participant.email || '-')}</strong><small>${escapeHtml(participant.whatsapp || '-')}</small></td>
                    <td>${escapeHtml(participant.type || '-')}</td>
                    <td>${escapeHtml(participant.institution || '-')}</td>
                    <td>${formatDate(participant.registeredAt)}</td>
                    <td>${badge(participant.status)}</td>
                    <td class="table-actions"><div class="button-group button-group--nowrap"><button class="button button--soft button--small" type="button" data-edit-participant="${escapeHtml(participant.id)}">Edit</button><button class="button button--danger button--small" type="button" data-delete-participant="${escapeHtml(participant.id)}">Hapus</button></div></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          <div class="table-empty-filter" id="participant-filter-empty" hidden>Tidak ada peserta yang cocok dengan filter.</div>
        ` : emptyState({
          title: 'Belum ada peserta',
          description: 'Peserta baru akan muncul setelah mendaftar atau ditambahkan oleh administrator.',
          action: '<button class="button button--primary" type="button" id="empty-add-participant">+ Tambah Peserta</button>',
        })}
      </article>
      ${participantModal()}
    `,

    mount() {
      unbindModal = bindModalDismiss();
      const form = qs('#participant-form');
      const search = qs('#participant-search');
      const type = qs('#participant-type');
      const status = qs('#participant-status');
      const rows = qsa('[data-participant-row]');

      const showAddForm = () => {
        form?.reset();
        if (form) form.elements.id.value = '';
        openModal('participant-modal');
      };

      qs('#add-participant')?.addEventListener('click', showAddForm);
      qs('#empty-add-participant')?.addEventListener('click', showAddForm);

      const applyFilter = () => {
        const term = search?.value.trim().toLowerCase() ?? '';
        const selectedType = type?.value ?? 'all';
        const selectedStatus = status?.value ?? 'all';
        let visible = 0;

        rows.forEach((row) => {
          const matches = (!term || row.dataset.search.includes(term))
            && (selectedType === 'all' || row.dataset.type === selectedType)
            && (selectedStatus === 'all' || row.dataset.status === selectedStatus);
          row.hidden = !matches;
          if (matches) visible += 1;
        });

        if (qs('#participant-count')) qs('#participant-count').textContent = `${visible} peserta`;
        if (qs('#participant-filter-empty')) qs('#participant-filter-empty').hidden = visible !== 0;
      };

      search?.addEventListener('input', applyFilter);
      type?.addEventListener('change', applyFilter);
      status?.addEventListener('change', applyFilter);

      qsa('[data-edit-participant]').forEach((button) => {
        button.addEventListener('click', () => {
          const participant = participants.find((item) => item.id === button.dataset.editParticipant);
          if (!participant || !form) return;
          Object.entries(participant).forEach(([key, value]) => {
            if (form.elements[key]) form.elements[key].value = value ?? '';
          });
          openModal('participant-modal');
        });
      });

      qsa('[data-delete-participant]').forEach((button) => {
        button.addEventListener('click', async () => {
          const participant = participants.find((item) => item.id === button.dataset.deleteParticipant);
          if (!participant) return;
          if (!window.confirm(`Hapus peserta “${participant.name}”?\n\nData peserta dihapus dari daftar ini. Akun loginnya tidak ikut terhapus.`)) return;

          try {
            await firebaseRepository.deleteParticipant(participant.id);
            showToast('Peserta berhasil dihapus.', 'success');
            router.renderCurrentRoute();
          } catch (error) {
            console.error('[BISAM] Gagal menghapus peserta:', error);
            showToast('Gagal menghapus peserta. Cek rules Firestore.', 'error');
          }
        });
      });

      form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const values = Object.fromEntries(new FormData(form).entries());
        const id = String(values.id || '');
        const payload = {
          name: String(values.name || '').trim(),
          email: String(values.email || '').trim(),
          whatsapp: String(values.whatsapp || '').trim(),
          type: String(values.type || 'PSI'),
          institution: String(values.institution || '').trim() || '-',
          status: String(values.status || 'Aktif'),
        };
        if (!payload.name) return;

        try {
          if (id) await firebaseRepository.updateParticipant(id, payload);
          else await firebaseRepository.createParticipant(payload);
        } catch (error) {
          console.error('[BISAM] Gagal menyimpan peserta:', error);
          showToast('Gagal menyimpan peserta. Cek rules Firestore.', 'error');
          return;
        }

        closeModal('participant-modal');
        showToast(id ? 'Data peserta diperbarui.' : 'Peserta berhasil ditambahkan.', 'success');
        router.renderCurrentRoute();
      });

    },

    unmount() {
      unbindModal?.();
    },
  };
}
