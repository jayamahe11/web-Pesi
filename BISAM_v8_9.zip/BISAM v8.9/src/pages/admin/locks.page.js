import { pageHeading } from '../../components/ui/page-heading.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { showToast } from '../../components/ui/toast.js';
import { dataService } from '../../services/data.service.js';
import { lockService } from '../../services/lock.service.js';
import { rankingService } from '../../services/ranking.service.js';
import { moduleCategory } from '../../data/modules.data.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';

function lockErrorMessage(error) {
  const code = error?.code || '';

  if (code.includes('permission-denied')) {
    return 'Ditolak Firestore (permission-denied). Pastikan rules terbaru sudah di-publish dan dokumen users/{uid} akun admin ini berisi role = "admin".';
  }

  if (code === 'unauthenticated') {
    return error.message;
  }

  return `Gagal mengubah kunci${code ? ` (${code})` : ''}. ${error?.message ?? ''}`.trim();
}

function formatDate(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '-';
  return date.toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
}

/**
 * Admin > Kunci Soal
 *  1) Kunci modul untuk SEMUA peserta (peserta melihat modul bergembok).
 *  2) Kunci otomatis per peserta: modul yang sudah dikerjakan peserta
 *     terkunci untuk peserta itu; admin bisa membukanya agar peserta
 *     boleh mengulang (poin yang dipakai ranking = nilai terbaik).
 */
export async function adminLocksPage(router) {
  const modules = dataService
    .getModules()
    .filter((module) => module.engine === 'quiz');

  const globalLocked = await lockService.getGlobalLockedIds();

  let userLocks = [];
  let userLocksError = false;
  let userLocksErrorText = '';

  try {
    userLocks = await lockService.listAllUserLocks();
  } catch (error) {
    console.error('[BISAM] Gagal membaca kunci peserta:', error);
    userLocksError = true;
    userLocksErrorText = lockErrorMessage(error);
  }

  const lockedCount = modules.filter((module) => globalLocked.has(module.id)).length;

  return {
    html: `
      ${pageHeading({
        title: '🔒 Kunci Soal',
        description: 'Kunci atau buka modul latihan & ujian. Perubahan langsung berlaku untuk peserta.',
        action: `<div class="button-group">
          <button class="button button--outline" id="lock-all" type="button">Kunci Semua</button>
          <button class="button button--outline" id="unlock-all" type="button">Buka Semua</button>
        </div>`,
      })}

      <article class="card">
        <div class="card-heading">
          <div>
            <h2>Kunci Modul (semua peserta)</h2>
            <p>${lockedCount} dari ${modules.length} modul sedang dikunci. Modul terkunci tampil bergembok di sisi peserta dan tidak bisa dimulai.</p>
          </div>
        </div>

        <div class="table-scroll section-gap--small">
          <table class="data-table">
            <thead>
              <tr><th>Modul</th><th>Jenis</th><th>Jumlah Soal</th><th>Status</th><th class="table-actions">Aksi</th></tr>
            </thead>
            <tbody>
              ${modules.map((module) => {
                const locked = globalLocked.has(module.id);
                const isExam = moduleCategory(module) === 'ujian';
                return `
                  <tr>
                    <td><div class="table-module"><span class="table-module__icon">${escapeHtml(module.icon ?? '📘')}</span><div><strong>${escapeHtml(module.title)}</strong></div></div></td>
                    <td><span class="badge ${isExam ? 'badge--warning' : 'badge--success'}">${isExam ? 'Modul Ujian' : 'Modul Belajar'}</span></td>
                    <td>${dataService.getQuestionCountByModule(module.id)} soal</td>
                    <td><span class="badge ${locked ? 'badge--danger' : 'badge--success'}">${locked ? '🔒 Terkunci' : '🔓 Terbuka'}</span></td>
                    <td class="table-actions">
                      <button class="button ${locked ? 'button--soft' : 'button--danger'} button--small" type="button" data-toggle-lock="${escapeHtml(module.id)}" data-locked="${locked}">
                        ${locked ? 'Buka' : 'Kunci'}
                      </button>
                    </td>
                  </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
      </article>

      <article class="card section-gap">
        <div class="card-heading">
          <div>
            <h2>Hitung Ulang Poin Ranking</h2>
            <p>Poin ranking = jumlah nilai terbaik tiap modul (Pauli &amp; Kraepelin tidak dihitung). Klik tombol ini sekali untuk membersihkan poin lama yang sempat tercatat dobel akibat pengerjaan berulang.</p>
          </div>
          <button class="button button--primary" id="recalc-points" type="button">Hitung Ulang Poin</button>
        </div>
      </article>

      <article class="card section-gap">
        <div class="card-heading">
          <div>
            <h2>Kunci per Peserta</h2>
            <p>Setelah peserta selesai mengerjakan sebuah modul, modul itu otomatis terkunci untuk peserta tersebut. Klik <strong>Buka Kunci</strong> bila peserta boleh mengulang. Saat mengulang, poin modul hanya diperbarui ke nilai terbesar — tidak ditambah.</p>
          </div>
        </div>

        ${userLocksError
          ? `<div class="notice-box notice-box--neutral">Daftar kunci peserta gagal dimuat. ${escapeHtml(userLocksErrorText)}</div>`
          : userLocks.length
            ? `
              <div class="toolbar">
                <input class="input input--compact" id="user-lock-search" type="search" placeholder="Cari nama peserta atau modul..." />
              </div>
              <div class="table-scroll section-gap--small">
                <table class="data-table">
                  <thead>
                    <tr><th>Peserta</th><th>Modul</th><th>Nilai</th><th>Poin</th><th>Selesai</th><th class="table-actions">Aksi</th></tr>
                  </thead>
                  <tbody>
                    ${userLocks.map((item) => `
                      <tr data-user-lock-row data-search="${escapeHtml(`${item.name} ${item.email} ${item.moduleTitle}`.toLowerCase())}">
                        <td><strong>${escapeHtml(item.name)}</strong>${item.email ? `<small>${escapeHtml(item.email)}</small>` : ''}</td>
                        <td>${escapeHtml(item.moduleTitle)}</td>
                        <td>${item.lastScore}</td>
                        <td>${item.lastPoints}</td>
                        <td>${formatDate(item.lockedAt)}</td>
                        <td class="table-actions">
                          <button class="button button--soft button--small" type="button" data-unlock-user="${escapeHtml(item.id)}">Buka Kunci</button>
                          ${userLocks.filter((x) => x.uid === item.uid).length > 1
                            ? `<button class="button button--outline button--small" type="button" data-unlock-all-of="${escapeHtml(item.uid)}" title="Buka semua kunci milik ${escapeHtml(item.name)}">Buka semua milik ${escapeHtml(item.name)}</button>`
                            : ''}
                        </td>
                      </tr>`).join('')}
                  </tbody>
                </table>
              </div>`
            : emptyState({
                title: 'Belum ada modul yang terkunci otomatis',
                description: 'Daftar ini terisi saat peserta menyelesaikan latihan atau ujian.',
              })}
      </article>
    `,

    mount() {
      async function run(button, task, successMessage) {
        button.disabled = true;
        try {
          await task();
          showToast(successMessage, 'success');
          await router.renderCurrentRoute();
        } catch (error) {
          console.error('[BISAM] Gagal mengubah kunci:', error);
          showToast(lockErrorMessage(error), 'error');
          button.disabled = false;
        }
      }

      qsa('[data-toggle-lock]').forEach((button) => {
        button.addEventListener('click', () => {
          const module = modules.find((item) => item.id === button.dataset.toggleLock);
          if (!module) return;
          const nextLocked = button.dataset.locked !== 'true';

          run(
            button,
            () => lockService.setModuleLocked(module.id, nextLocked, module.title),
            nextLocked ? `${module.title} dikunci.` : `${module.title} dibuka.`
          );
        });
      });

      qs('#lock-all')?.addEventListener('click', (event) => {
        if (!window.confirm('Kunci SEMUA modul untuk semua peserta?')) return;
        run(event.currentTarget, () => lockService.setManyModulesLocked(modules, true), 'Semua modul dikunci.');
      });

      qs('#recalc-points')?.addEventListener('click', async (event) => {
        if (!window.confirm('Hitung ulang poin semua peserta dari riwayat pengerjaan?')) return;
        const button = event.currentTarget;
        button.disabled = true;
        try {
          const { participants } = await rankingService.recalculateAll();
          showToast(`Poin ${participants} peserta dihitung ulang.`, 'success');
        } catch (error) {
          console.error('[BISAM] Gagal menghitung ulang poin:', error);
          showToast('Gagal menghitung ulang. Pastikan rules Firestore terbaru sudah di-publish.', 'error');
        }
        button.disabled = false;
      });

      qs('#unlock-all')?.addEventListener('click', (event) => {
        run(event.currentTarget, () => lockService.setManyModulesLocked(modules, false), 'Semua modul dibuka.');
      });

      qsa('[data-unlock-user]').forEach((button) => {
        button.addEventListener('click', () => {
          run(
            button,
            () => lockService.unlockUser(button.dataset.unlockUser),
            'Kunci dibuka. Peserta boleh mengerjakan ulang.'
          );
        });
      });

      qsa('[data-unlock-all-of]').forEach((button) => {
        button.addEventListener('click', () => {
          const ids = userLocks
            .filter((item) => item.uid === button.dataset.unlockAllOf)
            .map((item) => item.id);

          run(
            button,
            () => lockService.unlockMany(ids),
            `${ids.length} kunci dibuka.`
          );
        });
      });

      qs('#user-lock-search')?.addEventListener('input', (event) => {
        const term = event.currentTarget.value.trim().toLowerCase();
        qsa('[data-user-lock-row]').forEach((row) => {
          row.hidden = Boolean(term) && !row.dataset.search.includes(term);
        });
      });
    },

    unmount() {},
  };
}
