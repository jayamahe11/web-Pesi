import { badge } from '../../components/ui/badge.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { modal, openModal, closeModal, bindModalDismiss } from '../../components/ui/modal.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { dataService } from '../../services/data.service.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';

function scheduleModal(modules) {
  return modal({
    id: 'schedule-modal',
    title: 'Jadwal Tes',
    description: 'Jadwal akan tampil kepada peserta setelah statusnya aktif/terjadwal.',
    size: 'lg',
    body: `
      <form id="schedule-form">
        <input type="hidden" name="id" />
        <div class="form-grid form-grid--2">
          <div class="form-field form-field--full"><label>Nama Jadwal</label><input name="name" required placeholder="Contoh: Simulasi PSI Batch 1" /></div>
          <div class="form-field"><label>Modul</label><select name="moduleId" required>${modules.map((module) => `<option value="${escapeHtml(module.id)}">${escapeHtml(module.title)}</option>`).join('')}</select></div>
          <div class="form-field"><label>Status</label><select name="status"><option>Terjadwal</option><option>Aktif</option><option>Selesai</option><option>Draft</option></select></div>
          <div class="form-field"><label>Tanggal</label><input name="date" type="date" required /></div>
          <div class="form-field"><label>Jam Mulai</label><input name="time" type="time" required /></div>
          <div class="form-field"><label>Durasi</label><input name="duration" required placeholder="Contoh: 90 menit" /></div>
        </div>
      </form>
    `,
    footer: '<button class="button button--outline" type="button" data-modal-close="schedule-modal">Batal</button><button class="button button--primary" type="submit" form="schedule-form">Simpan Jadwal</button>',
  });
}

export function adminSchedulePage(router) {
  const schedules = dataService.getSchedules();
  const modules = dataService.getModules().filter((module) => module.active);
  let unbindModal = null;

  const getModuleName = (id) => dataService.getModuleById(id)?.title ?? '-';

  return {
    html: `
      ${pageHeading({
        title: 'Kelola Jadwal',
        description: 'Atur jadwal pelaksanaan tes dan modul yang dapat diakses peserta.',
        action: `<button class="button button--primary" id="add-schedule" type="button" ${modules.length ? '' : 'disabled'}>+ Tambah Jadwal</button>`,
      })}

      <article class="card">
        <div class="toolbar toolbar--spread">
          <div class="toolbar__group"><select class="input input--compact" id="schedule-status"><option value="all">Semua Status</option><option>Terjadwal</option><option>Aktif</option><option>Selesai</option><option>Draft</option></select></div>
          <span class="toolbar__count">${schedules.length} jadwal</span>
        </div>

        ${schedules.length ? `
          <div class="table-scroll">
            <table class="data-table">
              <thead><tr><th>Jadwal</th><th>Modul</th><th>Tanggal</th><th>Jam</th><th>Durasi</th><th>Status</th><th class="table-actions">Aksi</th></tr></thead>
              <tbody>
                ${schedules.map((item) => `
                  <tr data-schedule-row data-status="${escapeHtml(item.status)}">
                    <td><strong>${escapeHtml(item.name)}</strong><small>ID: ${escapeHtml(item.id)}</small></td>
                    <td>${escapeHtml(getModuleName(item.moduleId))}</td>
                    <td>${escapeHtml(item.date || '-')}</td>
                    <td>${escapeHtml(item.time || '-')}</td>
                    <td>${escapeHtml(item.duration || '-')}</td>
                    <td>${badge(item.status)}</td>
                    <td class="table-actions"><div class="button-group button-group--nowrap"><button class="button button--soft button--small" type="button" data-edit-schedule="${escapeHtml(item.id)}">Edit</button><button class="button button--danger button--small" type="button" data-delete-schedule="${escapeHtml(item.id)}">Hapus</button></div></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          <div class="table-empty-filter" id="schedule-filter-empty" hidden>Tidak ada jadwal pada status tersebut.</div>
        ` : emptyState({
          title: 'Belum ada jadwal',
          description: 'Buat jadwal saat tes siap dibuka untuk peserta.',
          action: modules.length ? '<button class="button button--primary" id="empty-add-schedule" type="button">+ Buat Jadwal</button>' : '',
        })}
      </article>
      ${scheduleModal(modules)}
    `,

    mount() {
      unbindModal = bindModalDismiss();
      const form = qs('#schedule-form');
      const showAdd = () => {
        form?.reset();
        if (form) {
          form.elements.id.value = '';
          form.elements.status.value = 'Terjadwal';
          const today = new Date();
          form.elements.date.value = today.toISOString().slice(0, 10);
        }
        openModal('schedule-modal');
      };
      qs('#add-schedule')?.addEventListener('click', showAdd);
      qs('#empty-add-schedule')?.addEventListener('click', showAdd);

      qs('#schedule-status')?.addEventListener('change', (event) => {
        const selected = event.currentTarget.value;
        let visible = 0;
        qsa('[data-schedule-row]').forEach((row) => {
          const show = selected === 'all' || row.dataset.status === selected;
          row.hidden = !show;
          if (show) visible += 1;
        });
        if (qs('#schedule-filter-empty')) qs('#schedule-filter-empty').hidden = visible !== 0;
      });

      qsa('[data-edit-schedule]').forEach((button) => {
        button.addEventListener('click', () => {
          const item = dataService.getSchedules().find((row) => row.id === button.dataset.editSchedule);
          if (!item || !form) return;
          Object.entries(item).forEach(([key, value]) => { if (form.elements[key]) form.elements[key].value = value ?? ''; });
          openModal('schedule-modal');
        });
      });

      qsa('[data-delete-schedule]').forEach((button) => {
        button.addEventListener('click', () => {
          const item = dataService.getSchedules().find((row) => row.id === button.dataset.deleteSchedule);
          if (!item || !window.confirm(`Hapus jadwal “${item.name}”?`)) return;
          dataService.deleteSchedule(item.id);
          showToast('Jadwal dihapus.', 'success');
          router.renderCurrentRoute();
        });
      });

      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const values = Object.fromEntries(new FormData(form).entries());
        const id = String(values.id || '');
        const payload = {
          name: String(values.name || '').trim(), moduleId: String(values.moduleId || ''), date: String(values.date || ''),
          time: String(values.time || ''), duration: String(values.duration || '').trim(), status: String(values.status || 'Terjadwal'),
        };
        if (id) dataService.updateSchedule(id, payload); else dataService.createSchedule(payload);
        closeModal('schedule-modal');
        showToast(id ? 'Jadwal diperbarui.' : 'Jadwal berhasil dibuat.', 'success');
        router.renderCurrentRoute();
      });
    },

    unmount() { unbindModal?.(); },
  };
}
