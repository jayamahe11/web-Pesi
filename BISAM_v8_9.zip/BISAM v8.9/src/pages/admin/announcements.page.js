import { badge } from '../../components/ui/badge.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { modal, openModal, closeModal, bindModalDismiss } from '../../components/ui/modal.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { dataService } from '../../services/data.service.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';

function announcementModal() {
  return modal({
    id: 'announcement-modal',
    title: 'Pengumuman',
    description: 'Pesan ini akan langsung tampil di halaman Pengumuman milik peserta ketika status "Aktif".',
    size: 'lg',
    body: `
      <form id="announcement-form">
        <input type="hidden" name="id" />
        <div class="form-grid form-grid--2">
          <div class="form-field form-field--full">
            <label>Judul</label>
            <input name="title" required placeholder="Contoh: Jadwal Simulasi Batch 2" />
          </div>
          <div class="form-field form-field--full">
            <label>Isi Pesan</label>
            <textarea name="content" rows="4" required placeholder="Tulis pesan untuk peserta di sini..."></textarea>
          </div>
          <div class="form-field">
            <label>Status</label>
            <select name="status">
              <option value="Aktif">Aktif (tampil ke peserta)</option>
              <option value="Draft">Draft (belum tampil)</option>
            </select>
          </div>
        </div>
      </form>
    `,
    footer: '<button class="button button--outline" type="button" data-modal-close="announcement-modal">Batal</button><button class="button button--primary" type="submit" form="announcement-form">Kirim Pengumuman</button>',
  });
}

export function adminAnnouncementsPage(router) {
  const announcements = dataService.getAllAnnouncements();
  let unbindModal = null;

  return {
    html: `
      ${pageHeading({
        title: '📢 Pengumuman',
        description: 'Kirim informasi ke seluruh peserta BISAM. Pesan berstatus Aktif langsung tampil di halaman Pengumuman peserta.',
        action: '<button class="button button--primary" id="add-announcement" type="button">+ Tambah Pengumuman</button>',
      })}

      <article class="card">
        <div class="toolbar toolbar--spread">
          <span class="toolbar__count">${announcements.length} pengumuman</span>
        </div>

        <div id="announcement-list" class="section-gap--small"></div>
      </article>
      ${announcementModal()}
    `,

    mount() {
      unbindModal = bindModalDismiss();
      const list = qs('#announcement-list');
      const form = qs('#announcement-form');

      function render() {
        const items = dataService.getAllAnnouncements();

        list.innerHTML = items.length
          ? items.map((item) => `
              <div class="admin-card" data-announcement-row>
                <div class="admin-card__head">
                  <div>
                    <h3>${escapeHtml(item.title)}</h3>
                    <small>${escapeHtml(item.date || '-')}</small>
                  </div>
                  ${badge(item.status === 'Aktif' ? 'Aktif' : item.status)}
                </div>
                <p>${escapeHtml(item.content)}</p>
                <div class="button-group button-group--nowrap">
                  <button class="button button--soft button--small" type="button" data-edit-announcement="${escapeHtml(item.id)}">Edit</button>
                  <button class="button button--danger button--small" type="button" data-delete-announcement="${escapeHtml(item.id)}">Hapus</button>
                </div>
              </div>
            `).join('')
          : emptyState({
              title: 'Belum ada pengumuman',
              description: 'Klik "Tambah Pengumuman" untuk mengirim info pertama ke peserta.',
            });

        qsa('[data-edit-announcement]').forEach((button) => {
          button.addEventListener('click', () => {
            const item = dataService.getAllAnnouncements().find((row) => String(row.id) === button.dataset.editAnnouncement);
            if (!item || !form) return;
            form.elements.id.value = item.id;
            form.elements.title.value = item.title ?? '';
            form.elements.content.value = item.content ?? '';
            form.elements.status.value = item.status === 'Draft' ? 'Draft' : 'Aktif';
            openModal('announcement-modal');
          });
        });

        qsa('[data-delete-announcement]').forEach((button) => {
          button.addEventListener('click', () => {
            const item = dataService.getAllAnnouncements().find((row) => String(row.id) === button.dataset.deleteAnnouncement);
            if (!item || !window.confirm(`Hapus pengumuman "${item.title}"?`)) return;
            dataService.deleteAnnouncement(item.id);
            showToast('Pengumuman dihapus.', 'success');
            render();
          });
        });
      }

      render();

      const showAdd = () => {
        form?.reset();
        if (form) {
          form.elements.id.value = '';
          form.elements.status.value = 'Aktif';
        }
        openModal('announcement-modal');
      };

      qs('#add-announcement')?.addEventListener('click', showAdd);

      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const values = Object.fromEntries(new FormData(form).entries());
        const id = String(values.id || '');
        const payload = {
          title: String(values.title || '').trim(),
          content: String(values.content || '').trim(),
          status: String(values.status || 'Aktif'),
        };

        if (!payload.title || !payload.content) {
          showToast('Judul dan isi pesan wajib diisi.', 'danger');
          return;
        }

        if (id) {
          dataService.updateAnnouncement(id, payload);
        } else {
          dataService.createAnnouncement(payload);
        }

        closeModal('announcement-modal');
        showToast(id ? 'Pengumuman diperbarui.' : 'Pengumuman berhasil dikirim ke peserta.', 'success');
        render();
      });
    },

    unmount() {
      unbindModal?.();
    },
  };
}
