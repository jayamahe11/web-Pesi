import { metricCard } from '../../components/ui/metric-card.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { emptyState } from '../../components/ui/empty-state.js';
import { badge } from '../../components/ui/badge.js';
import { dataService } from '../../services/data.service.js';
import { firebaseRepository } from '../../repositories/firebase.repository.js';
import { downloadCsv } from '../../utils/csv.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';

const QUIZ_TYPE_LABEL = {
  latihan: 'Latihan',
  ujian: 'Ujian',
  psikotes: 'Psikotes',
};

function quizTypeLabel(type) {
  return QUIZ_TYPE_LABEL[type] || 'Latihan';
}

function formatDate(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
}

function aggregateModules(attempts) {
  const groups = new Map();
  attempts.forEach((item) => {
    const key = item.moduleId || item.moduleTitle;
    const current = groups.get(key) ?? { id: key, name: item.moduleTitle, total: 0, count: 0 };
    current.total += Number(item.score || 0);
    current.count += 1;
    groups.set(key, current);
  });
  return [...groups.values()]
    .map((item) => ({ ...item, score: Math.round((item.total / item.count) * 10) / 10 }))
    .sort((a, b) => b.score - a.score);
}

export async function adminReportsPage(router) {
  // Riwayat hasil lintas SEMUA peserta (bukan cuma perangkat admin ini),
  // lengkap dengan nama peserta yang mengerjakan. Butuh akun admin sesuai
  // firestore.rules.example, dan modul quiz/pauli sudah pernah dikerjakan
  // minimal 1x oleh peserta supaya ada datanya.
  const attempts = await firebaseRepository.getAllAttempts();
  const attemptsById = new Map(attempts.map((item) => [item.id, item]));

  // Tandai pengerjaan berulang: modul yang sama oleh peserta yang sama.
  // Urut dari yang paling lama supaya "ke-1" = pengerjaan pertama.
  const repeatNumber = new Map();
  const repeatCounter = new Map();
  [...attempts]
    .sort((a, b) => String(a.completedAt || '').localeCompare(String(b.completedAt || '')))
    .forEach((item) => {
      const key = `${item.userId}|${item.moduleId}`;
      const n = (repeatCounter.get(key) ?? 0) + 1;
      repeatCounter.set(key, n);
      repeatNumber.set(item.id, n);
    });

  const settings = dataService.getAdminSettings();
  const uniqueParticipants = new Set(attempts.map((item) => item.userId)).size;
  const average = attempts.length
    ? Math.round((attempts.reduce((sum, item) => sum + Number(item.score || 0), 0) / attempts.length) * 10) / 10
    : 0;
  const passed = attempts.filter((item) => Number(item.score || 0) >= Number(settings.passingScore)).length;
  const passRate = attempts.length ? Math.round((passed / attempts.length) * 100) : 0;
  const topModules = aggregateModules(attempts).slice(0, 5);

  const moduleOptions = [...new Map(attempts.map((item) => [item.moduleId, item.moduleTitle])).entries()];

  return {
    html: `
      ${pageHeading({
        title: 'Laporan & Hasil',
        description: `Riwayat pengerjaan seluruh peserta (bukan cuma perangkat ini), lengkap dengan nama peserta. Batas kelulusan saat ini ${settings.passingScore}.`,
        action: '<button class="button button--primary" id="export-report" type="button">Export CSV</button>',
      })}

      <section class="grid grid--4">
        ${metricCard({ label: 'Total Pengerjaan', value: attempts.length, icon: '▥' })}
        ${metricCard({ label: 'Rata-rata Skor', value: average, icon: '▧' })}
        ${metricCard({ label: 'Tingkat Kelulusan', value: `${passRate}%`, icon: '✓' })}
        ${metricCard({ label: 'Peserta Aktif', value: uniqueParticipants, icon: '♙' })}
      </section>

      <section class="grid grid--2 section-gap">
        <article class="card">
          <div class="card-heading"><div><h2>Performa Modul</h2><p>Urutan berdasarkan rata-rata skor hasil yang tersedia.</p></div></div>
          ${topModules.length ? `<div class="performance-list">${topModules.map((item, index) => `<div class="performance-row"><span>${index + 1}</span><div><strong>${escapeHtml(item.name)}</strong><small>${item.count} pengerjaan</small></div><b>${item.score}</b></div>`).join('')}</div>` : emptyState({ title: 'Belum ada hasil', description: 'Grafik dan peringkat modul akan terisi setelah peserta menyelesaikan tes.' })}
        </article>

        <article class="card">
          <div class="card-heading"><div><h2>Ringkasan Kelulusan</h2><p>Perhitungan mengikuti batas skor pada Pengaturan Sistem.</p></div></div>
          <div class="report-summary">
            <div><span class="report-summary__number">${passed}</span><small>Lulus</small></div>
            <div><span class="report-summary__number">${Math.max(0, attempts.length - passed)}</span><small>Belum Lulus</small></div>
            <div><span class="report-summary__number">${settings.passingScore}</span><small>Batas Nilai</small></div>
          </div>
          ${attempts.length === 0 ? `<div class="notice-box notice-box--neutral section-gap--small">Belum ada riwayat masuk. Pastikan security rules Firestore terbaru (lihat <code>src/firebase/firestore.rules.example</code>) sudah di-publish, dan akun ini memang berstatus admin di dokumen Firestore <code>users/&lt;uid&gt;</code>.</div>` : ''}
        </article>
      </section>

      <article class="card section-gap">
        <div class="card-heading">
          <div>
            <h2>Riwayat Hasil</h2>
            <p>Nama peserta, modul, dan nilai untuk setiap pengerjaan. Klik satu baris untuk lihat rincian jawaban per soal. Kalau ada peserta yang mengulang-ulang pengerjaan, hapus dengan tombol Hapus — poin peserta ikut dikurangi.</p>
          </div>
        </div>

        ${attempts.length ? `
          <div class="segmented-control" id="report-type-filter">
            <button class="is-active" type="button" data-type="all">Semua</button>
            <button type="button" data-type="latihan">Latihan</button>
            <button type="button" data-type="ujian">Ujian</button>
            <button type="button" data-type="psikotes">Psikotes</button>
          </div>

          <div class="form-field section-gap--small">
            <select class="input input--compact" id="report-module-filter">
              <option value="all">Semua Modul</option>
              ${moduleOptions.map(([id, name]) => `<option value="${escapeHtml(id)}">${escapeHtml(name)}</option>`).join('')}
            </select>
          </div>

          <div class="table-scroll section-gap--small">
            <table class="data-table">
              <thead>
                <tr>
                  <th>Nama Peserta</th>
                  <th>Modul</th>
                  <th>Tipe</th>
                  <th>Tanggal</th>
                  <th>Skor</th>
                  <th>Poin</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                ${attempts.map((item) => `
                  <tr
                    data-report-row
                    data-attempt-id="${item.id}"
                    data-module="${escapeHtml(item.moduleId)}"
                    data-type="${item.quizType || 'latihan'}"
                    class="report-row--clickable"
                  >
                    <td><strong>${escapeHtml(item.name || 'Peserta')}</strong></td>
                    <td>${escapeHtml(item.moduleTitle || '-')}${repeatNumber.get(item.id) > 1 ? `<small class="report-repeat">Pengerjaan ke-${repeatNumber.get(item.id)}</small>` : ''}</td>
                    <td>${badge(quizTypeLabel(item.quizType))}</td>
                    <td>${formatDate(item.completedAt)}</td>
                    <td><strong>${Number(item.score || 0)}</strong></td>
                    <td>${Number(item.points || 0)}</td>
                    <td><span class="badge ${Number(item.score || 0) >= settings.passingScore ? 'badge--success' : 'badge--warning'}">${Number(item.score || 0) >= settings.passingScore ? 'Lulus' : 'Belum Lulus'}</span></td>
                    <td><button class="button button--danger button--small" type="button" data-delete-attempt="${item.id}">Hapus</button></td>
                  </tr>
                  <tr class="report-detail-row" data-attempt-detail="${item.id}" hidden>
                    <td colspan="8"></td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        ` : emptyState({ title: 'Riwayat hasil masih kosong', description: 'Hasil akan muncul di sini setelah ada peserta yang menyelesaikan latihan, ujian, atau tes Pauli & Kraepelin.' })}
      </article>
    `,

    mount() {
      qsa('#report-type-filter button').forEach((button) => {
        button.addEventListener('click', () => {
          qsa('#report-type-filter button').forEach((btn) => btn.classList.remove('is-active'));
          button.classList.add('is-active');
          applyFilters();
        });
      });

      qs('#report-module-filter')?.addEventListener('change', applyFilters);

      function applyFilters() {
        const activeType = qs('#report-type-filter .is-active')?.dataset.type ?? 'all';
        const selectedModule = qs('#report-module-filter')?.value ?? 'all';

        qsa('[data-report-row]').forEach((row) => {
          const matchesType = activeType === 'all' || row.dataset.type === activeType;
          const matchesModule = selectedModule === 'all' || row.dataset.module === selectedModule;
          const visible = matchesType && matchesModule;
          row.hidden = !visible;

          const detailRow = qs(`[data-attempt-detail="${row.dataset.attemptId}"]`);
          if (detailRow) {
            detailRow.hidden = !visible || detailRow.dataset.open !== 'true';
          }
        });
      }

      qsa('[data-report-row]').forEach((row) => {
        row.addEventListener('click', (event) => {
          if (event.target.closest('[data-delete-attempt]')) return;

          const attemptId = row.dataset.attemptId;
          const detailRow = qs(`[data-attempt-detail="${attemptId}"]`);
          if (!detailRow) return;

          const isOpen = detailRow.dataset.open === 'true';

          if (isOpen) {
            detailRow.hidden = true;
            detailRow.dataset.open = 'false';
            return;
          }

          const attempt = attemptsById.get(attemptId);
          detailRow.querySelector('td').innerHTML = renderAttemptDetail(attempt);
          detailRow.hidden = false;
          detailRow.dataset.open = 'true';
        });
      });

      qsa('[data-delete-attempt]').forEach((button) => {
        button.addEventListener('click', async (event) => {
          event.stopPropagation();

          const attempt = attemptsById.get(button.dataset.deleteAttempt);
          if (!attempt) return;

          const points = Number(attempt.points || 0);


          button.disabled = true;
          button.textContent = 'Menghapus…';

          try {
            await firebaseRepository.deleteAttempt(attempt);
            showToast('Pengerjaan dihapus. Poin ranking dihitung ulang.', 'success');
            if (router?.renderCurrentRoute) {
              await router.renderCurrentRoute();
            } else {
              window.location.reload();
            }
          } catch (error) {
            console.error('[BISAM] Gagal menghapus pengerjaan:', error);
            showToast(
              'Gagal menghapus. Pastikan akun ini admin dan rules Firestore terbaru sudah di-publish.',
              'error'
            );
            button.disabled = false;
            button.textContent = 'Hapus';
          }
        });
      });

      qs('#export-report')?.addEventListener('click', () => {
        if (!attempts.length) {
          showToast('Belum ada data hasil untuk diekspor.', 'warning');
          return;
        }
        downloadCsv('bisam-laporan-hasil.csv', [
          ['Nama Peserta', 'Modul', 'Tipe', 'Tanggal', 'Skor', 'Benar', 'Salah', 'Poin', 'Status'],
          ...attempts.map((item) => [
            item.name,
            item.moduleTitle,
            quizTypeLabel(item.quizType),
            formatDate(item.completedAt),
            item.score,
            item.rawScore ?? '',
            item.wrong ?? '',
            item.points,
            Number(item.score || 0) >= settings.passingScore ? 'Lulus' : 'Belum Lulus',
          ]),
        ]);
        showToast('Laporan CSV berhasil dibuat.', 'success');
      });
    },
  };
}

function renderAttemptDetail(attempt) {
  if (!attempt) {
    return '<div class="notice-box notice-box--neutral">Data tidak ditemukan.</div>';
  }

  const breakdown = Array.isArray(attempt.categoryBreakdown) ? attempt.categoryBreakdown : [];
  const questionRows = Array.isArray(attempt.questionRows) ? attempt.questionRows : [];

  if (!breakdown.length && !questionRows.length) {
    return '<div class="notice-box notice-box--neutral">Belum ada rincian per soal untuk pengerjaan ini.</div>';
  }

  return `
    <div class="report-detail">
      ${breakdown.length ? `
        <div class="result-analysis-list section-gap--small">
          ${breakdown.map((item) => `
            <div class="result-analysis-item">
              <div>
                <strong>${escapeHtml(item.category)}</strong>
                <small>${item.correct} benar dari ${item.total} soal</small>
              </div>
              <div class="result-analysis-item__score">
                <span>${item.percent}%</span>
                <div class="progress-bar"><span style="width:${item.percent}%"></span></div>
              </div>
            </div>
          `).join('')}
        </div>
      ` : ''}

      ${questionRows.length ? `
        <div class="table-scroll section-gap--small">
          <table class="data-table result-table">
            <thead>
              <tr>
                <th>No</th>
                <th>Pertanyaan</th>
                <th>Jawaban Peserta</th>
                <th>Kunci Jawaban</th>
              </tr>
            </thead>
            <tbody>
              ${questionRows.map((item) => `
                <tr class="${item.isCorrect ? 'result-row--correct' : 'result-row--wrong'}">
                  <td>${item.number}</td>
                  <td><strong>${escapeHtml(item.question)}</strong><small>${escapeHtml(item.category ?? '')}</small></td>
                  <td>${escapeHtml(item.selected ?? '-')}</td>
                  <td>${escapeHtml(item.correct ?? '-')}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        </div>
      ` : ''}
    </div>
  `;
}
