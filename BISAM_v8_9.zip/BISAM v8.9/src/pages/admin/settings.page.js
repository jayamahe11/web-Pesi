import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { DATA_SOURCE_CONFIG } from '../../config/data-source.config.js';
import { dataService } from '../../services/data.service.js';
import { qs } from '../../utils/dom.js';

export function adminSettingsPage(router) {
  const settings = dataService.getAdminSettings();

  return {
    html: `
      ${pageHeading({
        title: 'Pengaturan Sistem',
        description: 'Konfigurasi operasional yang dapat dikelola tanpa mengubah source code halaman.',
      })}

      <section class="settings-admin-layout">
        <form class="card" id="system-settings-form">
          <div class="card-heading"><div><h2>Pengaturan Tes</h2><p>Nilai ini digunakan oleh latihan dan laporan pada mode lokal.</p></div></div>
          <div class="form-grid form-grid--2">
            <div class="form-field"><label>Batas Nilai Lulus</label><input name="passingScore" type="number" min="0" max="100" value="${settings.passingScore}" required /></div>
            <div class="form-field"><label>Auto-next Soal (ms)</label><input name="autoAdvanceDelayMs" type="number" min="0" max="5000" step="50" value="${settings.autoAdvanceDelayMs}" required /></div>
            <div class="form-field"><label>Program Default Peserta</label><select name="defaultParticipantType"><option ${settings.defaultParticipantType === 'BINJAS' ? 'selected' : ''}>BINJAS</option><option ${settings.defaultParticipantType === 'PSI' ? 'selected' : ''}>PSI</option><option ${settings.defaultParticipantType === 'BINJAS & PSI' ? 'selected' : ''}>BINJAS & PSI</option></select></div>
          </div>
          <div class="switch-list">
            <label class="switch-row"><span><strong>Pendaftaran Peserta</strong><small>Izinkan akun peserta baru dibuat.</small></span><input name="registrationOpen" type="checkbox" ${settings.registrationOpen ? 'checked' : ''} /></label>
            <label class="switch-row"><span><strong>Mode Maintenance</strong><small>Penanda kesiapan untuk implementasi production/Firebase.</small></span><input name="maintenanceMode" type="checkbox" ${settings.maintenanceMode ? 'checked' : ''} /></label>
          </div>
          <div class="settings-form-actions"><button class="button button--primary" type="submit">Simpan Pengaturan</button></div>
        </form>

        <aside class="settings-admin-side">
          <article class="card">
            <div class="card-heading"><div><h2>Status Data</h2><p>Environment penyimpanan yang digunakan sekarang.</p></div></div>
            <div class="integration-status"><span class="integration-status__icon">🔥</span><div><strong>${DATA_SOURCE_CONFIG.provider === 'firebase' ? 'Firebase' : 'Local / Mock'}</strong><small>${DATA_SOURCE_CONFIG.provider === 'firebase' ? 'Repository Firebase aktif.' : 'Aplikasi masih memakai localStorage + mock repository.'}</small></div><span class="badge ${DATA_SOURCE_CONFIG.provider === 'firebase' ? 'badge--success' : 'badge--warning'}">${DATA_SOURCE_CONFIG.provider === 'firebase' ? 'Aktif' : 'Development'}</span></div>
            <div class="notice-box notice-box--neutral section-gap--small">Untuk serah-terima production, aktifkan Firebase Auth + Firestore dan pertahankan Security Rules agar kunci jawaban tidak dapat dibaca peserta.</div>
          </article>

          <article class="card danger-zone">
            <div class="card-heading"><div><h2>Reset Workspace Admin</h2><p>Menghapus perubahan admin lokal dan mengembalikan modul/soal ke seed awal.</p></div></div>
            <button class="button button--danger" id="reset-admin-workspace" type="button">Reset Data Admin Lokal</button>
          </article>
        </aside>
      </section>
    `,

    mount() {
      qs('#system-settings-form')?.addEventListener('submit', (event) => {
        event.preventDefault();
        const form = event.currentTarget;
        const values = new FormData(form);
        dataService.updateAdminSettings({
          passingScore: Number(values.get('passingScore') || 60),
          autoAdvanceDelayMs: Number(values.get('autoAdvanceDelayMs') || 500),
          defaultParticipantType: String(values.get('defaultParticipantType') || 'PSI'),
          registrationOpen: form.elements.registrationOpen.checked,
          maintenanceMode: form.elements.maintenanceMode.checked,
        });
        showToast('Pengaturan sistem berhasil disimpan.', 'success');
      });

      qs('#reset-admin-workspace')?.addEventListener('click', () => {
        if (!window.confirm('Reset workspace admin lokal? Perubahan peserta, modul, soal, jadwal, dan pengumuman lokal akan dikembalikan ke kondisi awal.')) return;
        dataService.resetAdminWorkspace();
        showToast('Workspace admin dikembalikan ke kondisi awal.', 'success');
        router.navigate('/admin/dashboard');
      });
    },
  };
}
