import { badge } from '../../components/ui/badge.js';
import { modal, openModal, closeModal, bindModalDismiss } from '../../components/ui/modal.js';
import { pageHeading } from '../../components/ui/page-heading.js';
import { showToast } from '../../components/ui/toast.js';
import { dataService } from '../../services/data.service.js';
import { moduleCategory } from '../../data/modules.data.js';
import { qs, qsa } from '../../utils/dom.js';
import { escapeHtml } from '../../utils/html.js';

const CATEGORY_LABEL = {
  latihan: 'Modul Belajar',
  ujian: 'Modul Ujian',
};

function categoryPill(category) {
  const isExam = category === 'ujian';
  return `<span class="badge ${isExam ? 'badge--warning' : 'badge--success'}">${CATEGORY_LABEL[category]}</span>`;
}

function moduleModal() {
  return modal({
    id: 'module-modal',
    title: 'Pengaturan Modul',
    description: 'Modul baru berisi soal pilihan ganda. Setelah disimpan, tambahkan soalnya lewat tombol "Soal".',
    size: 'lg',
    body: `
      <form id="module-form">
        <input type="hidden" name="id" />
        <div class="form-grid form-grid--2">
          <div class="form-field"><label>Jenis Modul</label>
            <select name="category">
              <option value="latihan">Modul Belajar (Latihan)</option>
              <option value="ujian">Modul Ujian</option>
            </select>
          </div>
          <div class="form-field"><label>Nama Modul</label><input name="title" required /></div>
          <div class="form-field"><label>Ikon</label><input name="icon" maxlength="6" placeholder="📘" /></div>
          <div class="form-field"><label>Durasi (menit, 0 = bebas)</label><input name="durationMinutes" type="number" min="0" max="240" value="30" /></div>
          <div class="form-field form-field--full"><label>Deskripsi</label><textarea name="description" rows="3" required></textarea></div>
          <div class="form-field"><label>Status</label><select name="active"><option value="true">Aktif (tampil ke peserta)</option><option value="false">Draft (disembunyikan)</option></select></div>
        </div>
        <p class="form-hint" id="module-builtin-note" hidden>Ini modul bawaan aplikasi: jenisnya tidak bisa diubah, dan perubahan hanya berlaku sementara di browser ini.</p>
      </form>
    `,
    footer: '<button class="button button--outline" type="button" data-modal-close="module-modal">Batal</button><button class="button button--primary" type="submit" form="module-form" id="module-save">Simpan Modul</button>',
  });
}

export function adminModulesPage(router) {
  const modules = dataService.getModules();
  let unbindModal = null;

  return {
    html: `
      ${pageHeading({
        title: 'Kelola Modul',
        description: 'Buat modul belajar dan modul ujian, lalu isi soalnya. Modul buatan admin langsung tampil ke semua peserta.',
        action: `<div class="button-group">
          <button class="button button--primary" id="add-module-latihan" type="button">+ Modul Belajar</button>
          <button class="button button--primary" id="add-module-ujian" type="button">+ Modul Ujian</button>
        </div>`,
      })}

      <article class="card">
        <div class="toolbar toolbar--spread">
          <div class="toolbar__group">
            <input class="input input--compact" id="module-search" placeholder="Cari modul..." />
            <select class="input input--compact" id="module-category"><option value="all">Semua Jenis</option><option value="latihan">Modul Belajar</option><option value="ujian">Modul Ujian</option></select>
            <select class="input input--compact" id="module-status"><option value="all">Semua Status</option><option value="active">Aktif</option><option value="draft">Draft</option></select>
          </div>
          <span class="toolbar__count" id="module-count">${modules.length} modul</span>
        </div>

        <div class="table-scroll">
          <table class="data-table">
            <thead><tr><th>Modul</th><th>Jenis</th><th>Durasi</th><th>Konten</th><th>Status</th><th class="table-actions">Aksi</th></tr></thead>
            <tbody>
              ${modules.map((module) => {
                const category = moduleCategory(module);
                return `
                <tr data-module-row data-search="${escapeHtml(`${module.title} ${module.description}`.toLowerCase())}" data-status="${module.active ? 'active' : 'draft'}" data-category="${category}">
                  <td><div class="table-module"><span class="table-module__icon">${escapeHtml(module.icon)}</span><div><strong>${escapeHtml(module.title)}</strong><small>${escapeHtml(module.description)}</small>${module.custom ? '' : '<small class="report-repeat" style="color:#64748b">Bawaan</small>'}</div></div></td>
                  <td>${categoryPill(category)}</td>
                  <td>${Number(module.durationMinutes) ? `${Number(module.durationMinutes)} menit` : 'Bebas'}</td>
                  <td>${module.engine === 'quiz' ? `${dataService.getQuestionCountByModule(module.id)} soal` : 'Generator angka'}</td>
                  <td>${badge(module.active ? 'Aktif' : 'Draft')}</td>
                  <td class="table-actions"><div class="button-group button-group--nowrap">
                    ${module.engine === 'quiz' ? `<button class="button button--outline button--small" type="button" data-open-questions="${escapeHtml(module.id)}">Soal</button>` : ''}
                    <button class="button button--soft button--small" type="button" data-edit-module="${escapeHtml(module.id)}">Edit</button>
                    <button class="button button--danger button--small" type="button" data-delete-module="${escapeHtml(module.id)}">Hapus</button>
                  </div></td>
                </tr>`;
              }).join('')}
            </tbody>
          </table>
        </div>
        <div class="table-empty-filter" id="module-filter-empty" hidden>Tidak ada modul yang cocok dengan filter.</div>
      </article>
      ${moduleModal()}
    `,

    mount() {
      unbindModal = bindModalDismiss();
      const form = qs('#module-form');
      const search = qs('#module-search');
      const status = qs('#module-status');
      const categoryFilter = qs('#module-category');
      const rows = qsa('[data-module-row]');
      const builtinNote = qs('#module-builtin-note');

      const showAdd = (category) => {
        form?.reset();
        if (!form) return;
        form.elements.id.value = '';
        form.elements.category.value = category;
        form.elements.category.disabled = false;
        form.elements.durationMinutes.value = category === 'ujian' ? '50' : '30';
        form.elements.active.value = 'true';
        if (builtinNote) builtinNote.hidden = true;
        openModal('module-modal');
      };

      qs('#add-module-latihan')?.addEventListener('click', () => showAdd('latihan'));
      qs('#add-module-ujian')?.addEventListener('click', () => showAdd('ujian'));

      const applyFilter = () => {
        const term = search?.value.trim().toLowerCase() ?? '';
        const selectedStatus = status?.value ?? 'all';
        const selectedCategory = categoryFilter?.value ?? 'all';
        let visible = 0;
        rows.forEach((row) => {
          const show = (!term || row.dataset.search.includes(term))
            && (selectedStatus === 'all' || row.dataset.status === selectedStatus)
            && (selectedCategory === 'all' || row.dataset.category === selectedCategory);
          row.hidden = !show;
          if (show) visible += 1;
        });
        if (qs('#module-count')) qs('#module-count').textContent = `${visible} modul`;
        if (qs('#module-filter-empty')) qs('#module-filter-empty').hidden = visible !== 0;
      };
      search?.addEventListener('input', applyFilter);
      status?.addEventListener('change', applyFilter);
      categoryFilter?.addEventListener('change', applyFilter);

      qsa('[data-open-questions]').forEach((button) => {
        button.addEventListener('click', () => {
          dataService.setAdminUiState({ selectedQuestionModuleId: button.dataset.openQuestions });
          router.navigate('/admin/questions');
        });
      });

      qsa('[data-edit-module]').forEach((button) => {
        button.addEventListener('click', () => {
          const module = dataService.getModuleById(button.dataset.editModule);
          if (!module || !form) return;
          form.elements.id.value = module.id;
          form.elements.title.value = module.title;
          form.elements.icon.value = module.icon;
          form.elements.category.value = moduleCategory(module);
          form.elements.category.disabled = !module.custom;
          form.elements.durationMinutes.value = module.durationMinutes ?? 0;
          form.elements.description.value = module.description;
          form.elements.active.value = String(Boolean(module.active));
          if (builtinNote) builtinNote.hidden = Boolean(module.custom);
          openModal('module-modal');
        });
      });

      qsa('[data-delete-module]').forEach((button) => {
        button.addEventListener('click', async () => {
          const module = dataService.getModuleById(button.dataset.deleteModule);
          if (!module) return;
          const count = dataService.getQuestionCountByModule(module.id);
          if (!window.confirm(`Hapus modul “${module.title}”${count ? ` beserta ${count} soal` : ''}?`)) return;

          try {
            if (module.custom) {
              button.disabled = true;
              await dataService.deleteCustomModule(module.id);
            } else {
              dataService.deleteModule(module.id);
            }
          } catch (error) {
            console.error('[BISAM] Gagal menghapus modul:', error);
            showToast('Gagal menghapus modul. Cek rules Firestore.', 'error');
            button.disabled = false;
            return;
          }

          showToast('Modul berhasil dihapus.', 'success');
          router.renderCurrentRoute();
        });
      });

      form?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const values = Object.fromEntries(new FormData(form).entries());
        const id = String(values.id || '');
        const existing = id ? dataService.getModuleById(id) : null;
        const isBuiltin = Boolean(existing && !existing.custom);

        const payload = {
          title: String(values.title || '').trim(),
          icon: String(values.icon || '📘').trim() || '📘',
          durationMinutes: Number(values.durationMinutes || 0),
          description: String(values.description || '').trim(),
          active: values.active === 'true',
        };
        if (!payload.title) return;

        const saveButton = qs('#module-save');
        if (saveButton) saveButton.disabled = true;

        try {
          if (isBuiltin) {
            dataService.updateModule(id, payload);
          } else {
            // Hanya field milik modul yang dikirim ke Firestore (bukan data
            // progres peserta yang ikut menempel di getModuleById).
            await dataService.saveCustomModule({
              ...payload,
              id: id || undefined,
              category: existing ? moduleCategory(existing) : String(values.category || 'latihan'),
            });
          }
        } catch (error) {
          console.error('[BISAM] Gagal menyimpan modul:', error);
          showToast('Gagal menyimpan modul. Pastikan rules Firestore terbaru sudah di-publish.', 'error');
          if (saveButton) saveButton.disabled = false;
          return;
        }

        if (saveButton) saveButton.disabled = false;
        closeModal('module-modal');
        showToast(id ? 'Modul diperbarui.' : 'Modul berhasil dibuat. Sekarang tambahkan soalnya.', 'success');
        router.renderCurrentRoute();
      });
    },

    unmount() {
      unbindModal?.();
    },
  };
}
