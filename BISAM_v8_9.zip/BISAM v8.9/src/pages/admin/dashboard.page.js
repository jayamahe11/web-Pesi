


export function adminDashboardPage(){



return {


html:`


<section class="admin-page">



<h1>
⚙️ Admin Dashboard
</h1>


<p>
Kelola aplikasi BISAM
</p>





<div class="admin-grid">



<div class="admin-card">


<h2>
👥
</h2>

<h3>
Peserta
</h3>


<p>
Kelola peserta latihan
</p>


</div>





<div class="admin-card">


<h2>
📚
</h2>


<h3>
Soal
</h3>


<p>
Tambah dan edit soal
</p>


</div>





<div class="admin-card">


<h2>
📢
</h2>


<h3>
Pengumuman
</h3>


<p>
Informasi peserta
</p>


</div>




</div>





</section>



`,



mount(){},


unmount(){}



};


}