import { authService } from '../services/auth.service.js';
import { dataService } from '../services/data.service.js';



export async function profilePage(){


const user =
await dataService.getCurrentUser();



return {


html:`


<section class="profile-page">


<div class="profile-title">

<h1>
👤 Profil Saya
</h1>

<p>
Kelola akun dan pengaturan BISAM
</p>

</div>





<div class="profile-card">


<div class="profile-avatar">

${user?.initials ?? "PB"}

</div>



<div class="profile-info">


<h2>
${user?.name ?? "Peserta BISAM"}
</h2>


<p>
${user?.email ?? "Member BISAM"}
</p>


<span>
⭐ ${user?.points ?? 0} Poin
</span>


</div>


</div>









<div class="setting-card">


<h3>
👤 Akun
</h3>



<a
class="setting-item"
href="#/settings"
id="edit-profile">


<span>
Edit Profil
</span>


<span>
›
</span>


</a>



</div>







<div class="setting-card">


<h3>
🎨 Tampilan
</h3>



<div class="setting-item">


<span>
Mode Gelap
</span>


<button
class="theme-button"
data-theme="dark">

🌙

</button>


</div>



<div class="setting-item">


<span>
Mode Terang
</span>


<button
class="theme-button"
data-theme="light">

☀️

</button>


</div>



</div>









<div class="setting-card">


<h3>
🔔 Notifikasi
</h3>



<div class="setting-item">

<span>
Pengumuman

</span>


<input type="checkbox" checked>


</div>




<div class="setting-item">

<span>
Jadwal Latihan

</span>


<input type="checkbox" checked>


</div>



</div>







<div class="setting-card">


<h3>
ℹ️ Tentang BISAM
</h3>


<p>
BISAM Learning Platform
</p>


<p>
Version 1.0
</p>


</div>







<button
class="logout-button"
id="logout-btn">


🚪 Keluar Akun


</button>





</section>


`,





mount(){



/*
 THEME
*/


document
.querySelectorAll(".theme-button")
.forEach(btn=>{


btn.addEventListener(
"click",
()=>{


const theme =
btn.dataset.theme;



if(theme==="dark"){


document.body.classList.add(
"dark"
);


localStorage.setItem(
"theme",
"dark"
);


}
else{


document.body.classList.remove(
"dark"
);



localStorage.setItem(
"theme",
"light"
);


}


}

);



});







/*
 LOGOUT
*/


document
.getElementById("logout-btn")
?.addEventListener(
"click",
async()=>{


const ok =
confirm(
"Keluar dari akun?"
);



if(!ok)return;



await authService.logout();



window.location.hash="/login";


}

);




},




unmount(){}



};


}