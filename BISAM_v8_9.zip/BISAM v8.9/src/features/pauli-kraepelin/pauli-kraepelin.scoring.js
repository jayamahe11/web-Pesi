export function unitDigitSum(a, b) {
  return (Number(a) + Number(b)) % 10;
}

export function calculateAccuracy(correct, wrong) {
  const attempts = Number(correct) + Number(wrong);
  return attempts > 0 ? Math.round((Number(correct) / attempts) * 100) : 0;
}

export function calculatePauliResult(session) {
  const attempts = session.correct + session.wrong;
  const accuracy = calculateAccuracy(session.correct, session.wrong);
  return {
    attempts,
    correct: session.correct,
    wrong: session.wrong,
    accuracy,
    score: accuracy,
    points: session.correct,
  };
}
