export function generateNumberSequence(length = 2500) {
  return Array.from({ length }, () => Math.floor(Math.random() * 10));
}
