import { qs, qsa } from '../../utils/dom.js';
import { formatTimer } from '../../utils/formatters.js';
import { pauliKraepelinEngine } from './pauli-kraepelin.engine.js';
import { calculateAccuracy } from './pauli-kraepelin.scoring.js';
import { pauliKraepelinSetupMarkup } from './pauli-kraepelin.setup.js';
import { pauliKraepelinResultMarkup, pauliKraepelinTestMarkup } from './pauli-kraepelin.test.js';

function getInitialView() {
  const session = pauliKraepelinEngine.getSession();
  if (!session) return 'setup';
  if (session.finished) return 'result';
  return 'test';
}

function visibleNumbers(session) {
  const radius = 7;
  const start = Math.max(0, session.currentIndex - radius);
  const end = Math.min(session.numbers.length, session.currentIndex + radius + 2);
  return session.numbers.slice(start, end).map((value, offset) => ({
    value,
    absoluteIndex: start + offset,
  }));
}

export function pauliKraepelinPage(router) {
  let view = getInitialView();
  let timerId = null;
  let keyHandler = null;

  const htmlForView = () => {
    const session = pauliKraepelinEngine.getSession();
    if (view === 'setup' || !session) return pauliKraepelinSetupMarkup();
    if (view === 'result' || session.finished) {
      const result = pauliKraepelinEngine.finalizeResult();
      return pauliKraepelinResultMarkup(result);
    }
    return pauliKraepelinTestMarkup(session, formatTimer(pauliKraepelinEngine.getRemainingSeconds(session)));
  };

  const renderSequence = (session) => {
    const column = qs('#pk-number-column');
    if (!column) return;
    const items = visibleNumbers(session);
    column.innerHTML = items.map((item) => {
      const isPair = item.absoluteIndex === session.currentIndex || item.absoluteIndex === session.currentIndex + 1;
      const isPrimary = item.absoluteIndex === session.currentIndex;
      return `<div class="pk-number ${isPair ? 'is-pair' : ''} ${isPrimary ? 'is-primary' : ''}">${item.value}</div>`;
    }).join('');
  };

  const updateTestUI = (feedback = null) => {
    const session = pauliKraepelinEngine.getSession();
    if (!session || session.finished) {
      view = 'result';
      router.renderCurrentRoute();
      return;
    }

    const remaining = pauliKraepelinEngine.getRemainingSeconds(session);
    if (remaining <= 0) {
      pauliKraepelinEngine.finish('time');
      view = 'result';
      router.renderCurrentRoute();
      return;
    }

    const pair = pauliKraepelinEngine.getPair(session);
    if (qs('#pk-time')) qs('#pk-time').textContent = formatTimer(remaining);
    if (qs('#pk-correct')) qs('#pk-correct').textContent = session.correct;
    if (qs('#pk-wrong')) qs('#pk-wrong').textContent = session.wrong;
    if (qs('#pk-accuracy')) qs('#pk-accuracy').textContent = `${calculateAccuracy(session.correct, session.wrong)}%`;
    if (qs('#pk-number-a')) qs('#pk-number-a').textContent = pair.a;
    if (qs('#pk-number-b')) qs('#pk-number-b').textContent = pair.b;

    const lastAnswer = qs('#pk-last-answer');
    if (lastAnswer && feedback) {
      lastAnswer.textContent = feedback.correct
        ? `Benar • ${feedback.selected}`
        : `Salah • ${feedback.selected} (jawaban ${feedback.correctAnswer})`;
      lastAnswer.className = `pk-last-answer ${feedback.correct ? 'is-correct' : 'is-wrong'}`;
    }

    const workspace = qs('#pk-workspace');
    if (workspace && feedback) {
      workspace.classList.remove('is-correct-flash', 'is-wrong-flash');
      void workspace.offsetWidth;
      workspace.classList.add(feedback.correct ? 'is-correct-flash' : 'is-wrong-flash');
    }

    renderSequence(session);
  };

  const submitDigit = (digit) => {
    if (view !== 'test') return;
    const result = pauliKraepelinEngine.submitDigit(digit);
    if (!result.ok && result.finished) {
      view = 'result';
      router.renderCurrentRoute();
      return;
    }
    if (result.ok) updateTestUI(result);
  };

  const mountSetup = () => {
    qs('#pk-start')?.addEventListener('click', () => {
      const mode = qs('#pk-mode')?.value ?? 'pauli';
      const durationMinutes = Number(qs('#pk-duration')?.value ?? 5);
      pauliKraepelinEngine.start({ mode, durationMinutes });
      view = 'test';
      router.renderCurrentRoute();
    });
  };

  const mountTest = () => {
    qsa('[data-pk-digit]').forEach((button) => {
      button.addEventListener('click', () => submitDigit(Number(button.dataset.pkDigit)));
    });

    qs('#pk-finish')?.addEventListener('click', () => {
      pauliKraepelinEngine.finish('manual');
      view = 'result';
      router.renderCurrentRoute();
    });

    keyHandler = (event) => {
      if (event.repeat) return;
      if (/^[0-9]$/.test(event.key)) submitDigit(Number(event.key));
    };
    window.addEventListener('keydown', keyHandler);

    updateTestUI();
    timerId = window.setInterval(() => updateTestUI(), 250);
  };

  const mountResult = () => {
    qs('#pk-repeat')?.addEventListener('click', () => {
      pauliKraepelinEngine.reset();
      view = 'setup';
      router.renderCurrentRoute();
    });
  };

  return {
    html: htmlForView(),
    mount() {
      view = getInitialView();
      if (view === 'setup') mountSetup();
      if (view === 'test') mountTest();
      if (view === 'result') mountResult();
    },
    unmount() {
      if (timerId) window.clearInterval(timerId);
      if (keyHandler) window.removeEventListener('keydown', keyHandler);
    },
  };
}
