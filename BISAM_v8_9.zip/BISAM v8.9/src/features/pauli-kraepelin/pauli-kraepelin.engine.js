import { dataService } from '../../services/data.service.js';
import { storageService } from '../../services/storage.service.js';
import { generateNumberSequence } from './pauli-kraepelin.generator.js';
import { calculatePauliResult, unitDigitSum } from './pauli-kraepelin.scoring.js';

const SESSION_KEY = 'pauli_kraepelin_session';

function createSession({ mode, durationMinutes }) {
  const numbers = generateNumberSequence();
  const isKraepelin = mode === 'kraepelin';
  return {
    mode,
    durationMinutes: Number(durationMinutes),
    numbers,
    currentIndex: isKraepelin ? numbers.length - 2 : 0,
    direction: isKraepelin ? -1 : 1,
    correct: 0,
    wrong: 0,
    startedAt: Date.now(),
    endedAt: null,
    finishReason: null,
    finished: false,
    finalized: false,
  };
}

export const pauliKraepelinEngine = {
  reset() {
    storageService.remove(SESSION_KEY);
  },

  start({ mode = 'pauli', durationMinutes = 5 } = {}) {
    const session = createSession({ mode, durationMinutes });
    storageService.set(SESSION_KEY, session);
    return session;
  },

  getSession() {
    return storageService.get(SESSION_KEY, null);
  },

  getPair(session = this.getSession()) {
    if (!session) return null;
    const { numbers, currentIndex } = session;
    return {
      a: numbers[currentIndex],
      b: numbers[currentIndex + 1],
      correctAnswer: unitDigitSum(numbers[currentIndex], numbers[currentIndex + 1]),
    };
  },

  submitDigit(digit) {
    const session = this.getSession();
    if (!session || session.finished) return { ok: false };

    if (this.getRemainingSeconds(session) <= 0) {
      this.finish('time');
      return { ok: false, finished: true };
    }

    const pair = this.getPair(session);
    const selected = Number(digit);
    const correct = selected === pair.correctAnswer;

    const nextIndex = session.currentIndex + session.direction;
    const boundaryReached = nextIndex < 0 || nextIndex >= session.numbers.length - 1;

    const next = {
      ...session,
      currentIndex: boundaryReached ? session.currentIndex : nextIndex,
      correct: session.correct + (correct ? 1 : 0),
      wrong: session.wrong + (correct ? 0 : 1),
    };

    if (boundaryReached) {
      next.finished = true;
      next.endedAt = Date.now();
      next.finishReason = 'sequence';
    }

    storageService.set(SESSION_KEY, next);

    return {
      ok: true,
      correct,
      selected,
      correctAnswer: pair.correctAnswer,
      finished: next.finished,
    };
  },

  getRemainingSeconds(session = this.getSession()) {
    if (!session) return 0;
    const durationSeconds = session.durationMinutes * 60;
    const endReference = session.endedAt ?? Date.now();
    const elapsedSeconds = Math.floor((endReference - session.startedAt) / 1000);
    return Math.max(0, durationSeconds - elapsedSeconds);
  },

  finish(reason = 'manual') {
    const session = this.getSession();
    if (!session || session.finished) return session;
    const next = {
      ...session,
      finished: true,
      endedAt: Date.now(),
      finishReason: reason,
    };
    storageService.set(SESSION_KEY, next);
    return next;
  },

  getResult() {
    const session = this.getSession();
    if (!session) return null;
    return {
      ...calculatePauliResult(session),
      mode: session.mode,
      durationMinutes: session.durationMinutes,
      finishReason: session.finishReason,
    };
  },

  finalizeResult() {
    const session = this.getSession();
    if (!session) return null;
    const result = this.getResult();
    if (session.finalized) return result;

    dataService.recordResult({
      moduleId: 'pauli-kraepelin',
      moduleTitle: 'Pauli & Kraepelin',
      score: result.score,
      points: result.points,
      correct: result.correct,
      wrong: result.wrong,
      total: result.attempts,
      type: 'pauli-kraepelin',
      detail: {
        accuracy: result.accuracy,
        attempts: result.attempts,
        mode: result.mode,
        durationMinutes: result.durationMinutes,
      },
    });

    storageService.set(SESSION_KEY, { ...session, finalized: true });
    return result;
  },
};
