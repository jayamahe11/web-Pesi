export function pauliKraepelinSetupMarkup() {
  return `
    <section class="pk-shell">
      <div class="pk-heading-row">
        <div>
          <h1>Pauli & Kraepelin</h1>
          <p>Penjumlahan angka berdekatan untuk melatih kecepatan, ketelitian, kestabilan, dan daya tahan.</p>
        </div>
        <a class="button button--soft" href="#/modules">Keluar</a>
      </div>

      <div class="pk-setup-grid">
        <div class="form-field">
          <label for="pk-mode">Mode</label>
          <select id="pk-mode">
            <option value="pauli">Pauli — atas ke bawah</option>
            <option value="kraepelin">Kraepelin — bawah ke atas</option>
          </select>
        </div>

        <div class="form-field">
          <label for="pk-duration">Durasi</label>
          <select id="pk-duration">
            <option value="1">1 menit</option>
            <option value="3">3 menit</option>
            <option value="5" selected>5 menit</option>
            <option value="10">10 menit</option>
          </select>
        </div>
      </div>

      <div class="pk-instruction">
        Jumlahkan dua angka yang disorot, lalu pilih <strong>angka satuannya</strong>. Contoh 8 + 7 = 15, jawab 5. Setelah memilih angka 0–9, soal langsung berpindah tanpa tombol berikutnya.
      </div>

      <div class="button-group button-group--center pk-start-actions">
        <button class="button button--primary" id="pk-start" type="button">Mulai Latihan</button>
      </div>
    </section>
  `;
}
