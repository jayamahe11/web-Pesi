import { calculateAccuracy } from './pauli-kraepelin.scoring.js';

function stat(label, value, id) {
  return `
    <div class="pk-stat">
      <small>${label}</small>
      <strong id="${id}">${value}</strong>
    </div>
  `;
}

export function pauliKraepelinTestMarkup(session, remainingLabel) {
  const accuracy = calculateAccuracy(session.correct, session.wrong);
  return `
    <section class="pk-shell pk-shell--test">
      <div class="pk-heading-row">
        <div>
          <h1>Pauli & Kraepelin</h1>
          <p>${session.mode === 'pauli' ? 'Mode Pauli — atas ke bawah' : 'Mode Kraepelin — bawah ke atas'}</p>
        </div>
        <a class="button button--soft" href="#/modules">Keluar</a>
      </div>

      <div class="pk-stats">
        ${stat('Waktu', remainingLabel, 'pk-time')}
        ${stat('Benar', session.correct, 'pk-correct')}
        ${stat('Salah', session.wrong, 'pk-wrong')}
        ${stat('Akurasi', `${accuracy}%`, 'pk-accuracy')}
      </div>

      <div class="pk-workspace" id="pk-workspace">
        <div class="pk-number-column-wrap">
          <div class="pk-number-column" id="pk-number-column"></div>
        </div>

        <div class="pk-current-problem">
          <small>Jumlahkan dan ambil angka satuannya</small>
          <div class="pk-equation">
            <strong id="pk-number-a">0</strong>
            <span>+</span>
            <strong id="pk-number-b">0</strong>
          </div>
          <div class="pk-last-answer" id="pk-last-answer">Pilih jawaban 0–9</div>
        </div>
      </div>

      <div class="pk-keypad" aria-label="Pilihan jawaban angka">
        ${Array.from({ length: 10 }, (_, digit) => `
          <button type="button" data-pk-digit="${digit}">${digit}</button>
        `).join('')}
      </div>

      <div class="button-group button-group--center pk-end-actions">
        <button class="button button--danger" id="pk-finish" type="button">Akhiri Tes</button>
      </div>
    </section>
  `;
}

export function pauliKraepelinResultMarkup(result) {
  return `
    <section class="pk-shell">
      <div class="pk-result">
        <div class="pk-result__score">${result.accuracy}%</div>
        <h1>Latihan Selesai</h1>
        <p>Hasil Pauli & Kraepelin sudah masuk ke riwayat akun.</p>

        <div class="pk-stats pk-stats--result">
          ${stat('Percobaan', result.attempts, 'pk-result-attempts')}
          ${stat('Benar', result.correct, 'pk-result-correct')}
          ${stat('Salah', result.wrong, 'pk-result-wrong')}
          ${stat('Poin', `+${result.points}`, 'pk-result-points')}
        </div>

        <div class="button-group button-group--center">
          <button class="button button--outline" id="pk-repeat" type="button">Ulangi</button>
          <a class="button button--soft" href="#/history">Lihat Riwayat</a>
          <a class="button button--primary" href="#/modules">Semua Modul</a>
        </div>
      </div>
    </section>
  `;
}
