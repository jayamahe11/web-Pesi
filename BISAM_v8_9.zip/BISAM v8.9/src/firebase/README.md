# Persiapan Firebase BISAM — instalasi bersih

Project ini sengaja berjalan dengan data lokal terlebih dahulu agar UI dapat dites tanpa Firebase. Semua data peserta awal dibuat kosong: tidak ada nilai trial, riwayat trial, ranking contoh, peserta contoh, atau jadwal contoh.

## Collection yang disarankan

```text
users/{uid}
modules/{moduleId}
questions/{questionId}
answerKeys/{questionId}          # private: admin/server only
quizAttempts/{attemptId}
pauliAttempts/{attemptId}
rankings/{userId}
schedules/{scheduleId}
announcements/{announcementId}
```

## Data awal yang boleh di-seed

Folder `seed/` berisi katalog modul dan bank soal (hasil generate dari
`src/data/modules.data.js` dan `src/data/questions.data.js`). Data
member/aktivitas dibuat kosong:

```text
modules.json                  -> 16 modul (12 latihan + Pauli&Kraepelin + TIU/TWK/TKD)
questions-public.json         -> 725 soal, tanpa field jawaban (boleh dibaca client)
answer-keys-private.json      -> kunci jawaban + pembahasan per id soal
users.json                    -> []
ranking.json                  -> []
history.json                  -> []
participants.json             -> []
schedules.json                -> []
announcements.json            -> []
```

> Kalau bank soal diubah lewat file `src/data/questions/*.js`, regenerate
> ketiga file JSON di atas dengan menjalankan (dari root project):
> ```bash
> node -e "import('./src/data/modules.data.js').then(({MODULES})=>require('fs').writeFileSync('src/firebase/seed/modules.json', JSON.stringify(MODULES,null,2)))"
> ```
> lalu lakukan hal serupa untuk `questions.data.js` (pisahkan field
> `answer`/`explanation` ke `answer-keys-private.json`, sisanya ke
> `questions-public.json`).

Pauli & Kraepelin tidak menggunakan collection `questions`, karena engine membuat deretan angka pada saat tes dimulai.

## Mengirim (seed) data ke Firestore project kamu

1. Buat project Firebase (atau pakai project `bisam-83c21` yang sudah
   dikonfigurasi di `src/firebase/config.js`).
2. Di Firebase Console → Project Settings → Service Accounts, klik
   **Generate new private key**, simpan file JSON-nya di root project
   sebagai `serviceAccountKey.json` (jangan dikomit ke git — tambahkan ke
   `.gitignore`).
3. Install dependency admin SDK (sekali saja):
   ```bash
   npm install
   ```
   (`firebase-admin` sudah terdaftar di `devDependencies`).
4. Jalankan seeding:
   ```bash
   npm run seed:firebase -- ./serviceAccountKey.json
   ```
   Script `scripts/seed-firebase.mjs` akan mengirim seluruh isi `seed/*.json`
   ke collection Firestore yang sesuai (`modules`, `questions`, `answerKeys`,
   dst). Aman dijalankan berulang kali (menimpa, bukan menduplikasi).
5. Terapkan `firestore.rules.example` (copy ke `firestore.rules` lalu
   `firebase deploy --only firestore:rules`) supaya collection `answerKeys`
   hanya bisa dibaca akun admin.
6. Ubah `src/config/data-source.config.js`:
   ```js
   export const DATA_SOURCE_CONFIG = Object.freeze({
     provider: 'firebase',
   });
   ```
   Setelah ini, `src/repositories/firebase.repository.js` otomatis membaca
   `modules` + `questions` + `answerKeys` dari Firestore setiap kali
   `dataService.initialize()` dipanggil — tidak perlu kode tambahan.

## Pemisahan kunci jawaban

Untuk penggunaan nyata, jangan letakkan field jawaban benar pada dokumen soal yang dapat dibaca browser peserta. Simpan teks/pilihan pada `questions`, sedangkan kunci jawaban pada `answerKeys` yang hanya dapat dibaca admin atau backend. Jika feedback benar/salah harus langsung muncul, validasi jawaban melalui backend/Cloud Function.

## Jalur data source

```text
src/config/data-source.config.js
        ↓
src/services/data.service.js
        ↓
src/repositories/
├── mock.repository.js
└── firebase.repository.js
```

`firebase.repository.js` sudah berisi loader Firestore yang berfungsi
langsung (baca `modules`, `questions`, `answerKeys`, `rankings`,
`announcements`, `schedules`). Cukup ubah provider menjadi `firebase` setelah
data di-seed — tidak perlu menulis loader baru dari nol.

**Batasan saat ini:** operasi tulis dari panel admin (CRUD peserta, modul,
soal, jadwal, pengumuman) dan penyimpanan hasil kuis/pauli masih memakai
penyimpanan lokal (in-memory/localStorage) walaupun provider = 'firebase'.
`firebaseRepository.recordQuizAttempt()` dan `recordPauliAttempt()` sudah
disiapkan sebagai titik sambung ke collection `quizAttempts`/`pauliAttempts`;
panggil dari `memberService.recordResult()` saat siap memindahkan
penyimpanan hasil peserta ke Firestore. Untuk CRUD admin penuh ke Firestore,
tambahkan implementasi di `firebaseRepository.mutate()` lalu arahkan method
tulis di `dataService`/`adminService` untuk memanggilnya saat provider
'firebase' aktif.

## Data hasil user

Saat masih mode lokal, hasil disimpan di localStorage melalui:

```text
src/services/member.service.js
```

Nanti service ini dapat diganti menjadi operasi Firestore tanpa mengubah halaman user.

## Tambahan v6 — panel admin

Panel admin v6 memiliki CRUD lokal yang benar-benar berfungsi pada provider `mock`. Saat migrasi ke Firebase, tambahkan juga dokumen/collection konfigurasi, misalnya:

```text
systemSettings/app
```

Field yang digunakan UI saat ini:

```text
passingScore
autoAdvanceDelayMs
registrationOpen
maintenanceMode
defaultParticipantType
```

Kontrak adapter Firebase untuk read/write didokumentasikan pada `src/repositories/firebase.repository.js` dan `ADMIN-HANDOFF.md`.
