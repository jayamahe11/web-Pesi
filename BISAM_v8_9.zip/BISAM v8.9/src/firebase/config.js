// ===============================
// FIREBASE CONFIG BISAM
// ===============================


import {
  initializeApp
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-app.js";


import {
  getAnalytics
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-analytics.js";


import {
  getAuth,
  GoogleAuthProvider,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";


import {
  getFirestore
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";



// ===============================
// FIREBASE CONFIGURATION
// ===============================


const firebaseConfig = {


  apiKey:
  "AIzaSyASz0RmjGKkERynG1QrCmRaYRK3fGOQSt0",


  authDomain:
  "bisam-83c21.firebaseapp.com",


  projectId:
  "bisam-83c21",


  storageBucket:
  "bisam-83c21.firebasestorage.app",


  messagingSenderId:
  "389158948143",


  appId:
  "1:389158948143:web:c1bfc08bd36fb1abc325da",


  measurementId:
  "G-DP192QVD09"

};




// ===============================
// INITIALIZE FIREBASE
// ===============================


const app = initializeApp(firebaseConfig);




// ===============================
// ANALYTICS
// ===============================


try {


  getAnalytics(app);


} catch(error) {


  console.log(
      "Firebase Analytics tidak aktif"
  );


}




// ===============================
// AUTHENTICATION
// ===============================


export const auth = getAuth(app);


// ===============================
// AUTH READY PROMISE
// ===============================
// Saat halaman baru dibuka/direfresh, Firebase Auth butuh waktu sesaat
// untuk memulihkan sesi login yang tersimpan (dari IndexedDB) sebelum
// `auth.currentUser` terisi. Kalau kita langsung menembak Firestore
// sebelum proses ini selesai, `request.auth` di security rules masih
// `null` walau usernya sebenarnya sudah login -> Firestore menolak
// dengan "Missing or insufficient permissions".
//
// `authReady` resolve SEKALI, begitu status login pertama kali diketahui
// (baik itu ada user maupun tidak). Kode lain (mis. src/main.js) harus
// `await authReady` dulu sebelum melakukan query Firestore yang
// memerlukan login, supaya statusnya sudah pasti.
export const authReady = new Promise((resolve) => {
  const unsubscribe = onAuthStateChanged(auth, (user) => {
    unsubscribe();
    resolve(user);
  });
});




// ===============================
// FIRESTORE DATABASE
// ===============================


export const db = getFirestore(app);




// ===============================
// GOOGLE LOGIN PROVIDER
// ===============================


export const googleProvider =
new GoogleAuthProvider();



// Optional:
// supaya popup Google menampilkan akun terakhir
googleProvider.setCustomParameters({

  prompt: "select_account"

});