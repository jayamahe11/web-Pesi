
// BISAM Settings Page

const settingsMenu = [
  {
    title: "Akun Saya",
    items: [
      "Foto Profil",
      "Nama Pengguna",
      "Email",
      "Status Akun"
    ]
  },
  {
    title: "Tampilan",
    items: [
      "Mode Terang",
      "Mode Gelap",
      "Mengikuti Sistem"
    ]
  },
  {
    title: "Notifikasi",
    items: [
      "Pengumuman",
      "Jadwal Latihan",
      "Hasil Ujian"
    ]
  },
  {
    title: "Keamanan",
    items: [
      "Ubah Password",
      "Riwayat Login",
      "Keluar Semua Perangkat"
    ]
  },
  {
    title: "Tentang BISAM",
    items: [
      "Versi Aplikasi",
      "Bantuan",
      "Kebijakan Privasi"
    ]
  }
];

export default settingsMenu;
