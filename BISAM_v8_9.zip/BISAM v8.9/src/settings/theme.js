
// BISAM Theme Controller

export function setTheme(theme){
  localStorage.setItem("theme", theme);

  if(theme === "dark"){
    document.body.classList.add("dark");
  }else{
    document.body.classList.remove("dark");
  }
}

export function loadTheme(){
  const theme = localStorage.getItem("theme") || "light";
  setTheme(theme);
}
