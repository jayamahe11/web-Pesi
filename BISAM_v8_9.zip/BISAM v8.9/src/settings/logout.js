
// BISAM Logout

export function logout(){
  const confirmLogout = confirm(
    "Apakah Anda yakin ingin keluar?"
  );

  if(confirmLogout){
    localStorage.removeItem("user");
    window.location.href="/login";
  }
}
