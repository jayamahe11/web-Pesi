import { DATA_SOURCE_CONFIG } from '../config/data-source.config.js';

import { firebaseRepository } from '../repositories/firebase.repository.js';

import { mockRepository } from '../repositories/mock.repository.js';

import { adminService } from './admin.service.js';

import { memberService } from './member.service.js';

import { rankingService } from './ranking.service.js';



const EMPTY_DATA = Object.freeze({

  currentUser: null,

  modules: [],

  questions: [],

  ranking: [],

  history: [],

  participants: [],

  schedules: [],

  announcements: [],

});



let cache = {
  ...EMPTY_DATA
};


let initialSeed = {
  ...EMPTY_DATA
};


let initialized = false;


// Cache gambar soal (id soal -> data URL) supaya tidak diunduh berulang.
const questionImageCache = new Map();




function getRepository() {

  if (
    DATA_SOURCE_CONFIG.provider === 'firebase'
  ) {

    return firebaseRepository;

  }


  return mockRepository;

}





function getManagedModules() {

  return adminService.getModules();

}





function modulesWithMemberProgress() {


  const progress =
  memberService.getModuleProgress();


  const questions =
  adminService.getQuestions();



  return getManagedModules()
  .map((module)=>{


    const questionCount =
    questions.filter(
      (item)=>
      item.moduleId === module.id
    ).length;



    const itemCountLabel =
    module.engine === 'quiz'
    ?
    `${questionCount} soal`
    :
    module.itemCountLabel;



    return {

      ...module,


      itemCountLabel,


      ...(progress[module.id] ?? {})


    };


  });


}







export const dataService = {



  async initialize(force = false){


    if(initialized && !force){

      return cache;

    }



    const repository =
    getRepository();



    cache = {


      ...EMPTY_DATA,


      ...(await repository.loadAppData())


    };



    initialSeed =
    JSON.parse(
      JSON.stringify(cache)
    );



    adminService.initialize(cache);



    initialized = true;



    return cache;


  },






  isInitialized(){

    return initialized;

  },







  async getCurrentUser(){


    const user =
    await memberService.getProfile(

      cache.currentUser ??
      EMPTY_DATA.currentUser ??
      {}

    );


    return user || {
      name: "Peserta BISAM",
      status: "Peserta",
      initials: "PB",
      points: 0
    };


},








  getModules(){


    return modulesWithMemberProgress();


  },







  getModuleById(moduleId){


    return (
      modulesWithMemberProgress()
      .find(
        item =>
        item.id === moduleId
      )
      ??
      null
    );


  },








  getQuestions(){


    return adminService
    .getQuestions();


  },




  getQuestionsByModule(moduleId){


    return adminService
    .getQuestions()
    .filter(
      item =>
      item.moduleId === moduleId
    );


  },







  getQuestionById(questionId){


    return adminService
    .getQuestions()
    .find(
      item =>
      String(item.id)
      ===
      String(questionId)
    )
    ??
    null;


  },







  getQuestionCountByModule(moduleId){


    return adminService
    .getQuestions()
    .filter(
      item =>
      item.moduleId === moduleId
    )
    .length;


  },







  async getRanking(){

    // Leaderboard nyata lintas peserta (Firestore `rankings`), bukan
    // data contoh — aktif untuk siapa pun yang login dan menyelesaikan
    // latihan/ujian.
    return rankingService.getLeaderboard();

  },






  getHistory(){


    return memberService.getHistory();


  },







  getParticipants(){


    return adminService.getParticipants();


  },







  getSchedules(){


    return adminService.getSchedules();


  },







  getAnnouncements(){


    return adminService
    .getAnnouncements()
    .filter(
      item =>
      item.status !== 'Draft'
    );


  },







  getAllAnnouncements(){


    return adminService.getAnnouncements();


  },







  getAdminSettings(){


    return adminService.getSettings();


  },







  getAdminActivities(limit){


    return adminService.getActivities(limit);


  },







  getAdminUiState(){


    return adminService.getUiState();


  },







  setAdminUiState(changes){


    return adminService.setUiState(changes);


  },








  registerMember(payload){



    const profile =
    memberService.register(payload);




    adminService.createParticipant({

      id: profile.id,

      name: profile.name,

      email: profile.email,

      whatsapp: profile.whatsapp,

      type:
      adminService
      .getSettings()
      .defaultParticipantType,


      institution:'-',


      status:'Aktif',


      registeredAt:
      new Date().toISOString()


    });



    return profile;


  },







  async updateCurrentUser(changes){


    return memberService.updateProfile(

      changes,

      cache.currentUser ?? {}

    );


  },







  recordResult(payload){


    return memberService.recordResult(payload);


  },







  resetCurrentMember(){


    memberService.resetMemberData({

      keepProfile:true

    });


  },







  createParticipant(payload){

    return adminService.createParticipant(payload);

  },


  updateParticipant(id,changes){

    return adminService.updateParticipant(
      id,
      changes
    );

  },


  deleteParticipant(id){

    return adminService.deleteParticipant(id);

  },








  /**
   * Simpan modul buatan admin ke Firestore lalu samakan data di memori.
   * Modul baru otomatis bertipe quiz pilihan ganda.
   */
  async saveCustomModule(payload){
    const item = {
      ...payload,
      id: payload.id || `m-${Date.now().toString(36)}`,
      engine: 'quiz',
      typeLabel: 'Pilihan ganda',
    };
    await firebaseRepository.saveCustomModule(item);
    return adminService.upsertCustomModule(item);
  },

  async deleteCustomModule(id){
    await firebaseRepository.deleteCustomModule(id);
    adminService.removeCustomModule(id);
  },

  /**
   * Simpan soal buatan admin ke Firestore (dibagikan ke semua peserta).
   * Gambar (opsional) dikirim lewat `payload.imageData` (data URL) dan
   * disimpan terpisah di `questionImages`. `payload.removeImage = true`
   * menghapus gambar yang sudah ada.
   */
  async saveCustomQuestion(payload){
    const { imageData, removeImage, image: _loadedImage, custom: _custom, ...rest } = payload;

    const id = rest.id || `q-${Date.now().toString(36)}${Math.random().toString(36).slice(2,6)}`;

    const hadImage = Boolean(rest.hasImage);

    let hasImage = hadImage;
    if (imageData) hasImage = true;
    if (removeImage) hasImage = false;

    const item = { ...rest, id, hasImage };

    if (imageData) {
      await firebaseRepository.saveQuestionImage(id, imageData);
    } else if (removeImage && hadImage) {
      await firebaseRepository.deleteQuestionImage(id);
    }

    await firebaseRepository.saveCustomQuestion(item);

    let image = null;
    if (imageData) {
      image = imageData;
      questionImageCache.set(String(id), imageData);
    } else if (removeImage) {
      questionImageCache.delete(String(id));
    } else if (hasImage) {
      image = questionImageCache.get(String(id)) ?? null;
    }

    return adminService.upsertCustomQuestion({
      ...item,
      ...(image ? { image } : {})
    });
  },

  /**
   * Pastikan gambar soal (yang disimpan terpisah) sudah terisi di objek
   * soal. Soal bawaan yang sudah punya `image` (path file) tidak disentuh.
   */
  async ensureQuestionImages(questions = []){
    await Promise.all(
      questions
      .filter((q)=>q.hasImage && !q.image)
      .map(async (q)=>{
        const key = String(q.id);

        if(!questionImageCache.has(key)){
          try{
            questionImageCache.set(
              key,
              await firebaseRepository.getQuestionImage(key)
            );
          }catch(error){
            console.warn('[BISAM] Gagal memuat gambar soal', key, error);
            return;
          }
        }

        const cached = questionImageCache.get(key);
        if(cached) q.image = cached;
      })
    );

    return questions;
  },

  async deleteCustomQuestion(id){
    await firebaseRepository.deleteCustomQuestion(id);
    adminService.removeCustomQuestion(id);
  },

  createModule(payload){

    return adminService.createModule(payload);

  },


  updateModule(id,changes){

    return adminService.updateModule(
      id,
      changes
    );

  },


  deleteModule(id){

    return adminService.deleteModule(id);

  },







  createQuestion(payload){

    return adminService.createQuestion(payload);

  },


  updateQuestion(id,changes){

    return adminService.updateQuestion(
      id,
      changes
    );

  },


  deleteQuestion(id){

    return adminService.deleteQuestion(id);

  },







  createSchedule(payload){

    return adminService.createSchedule(payload);

  },


  updateSchedule(id,changes){

    return adminService.updateSchedule(
      id,
      changes
    );

  },


  deleteSchedule(id){

    return adminService.deleteSchedule(id);

  },







  createAnnouncement(payload){

    return adminService.createAnnouncement(payload);

  },


  updateAnnouncement(id,changes){

    return adminService.updateAnnouncement(
      id,
      changes
    );

  },


  deleteAnnouncement(id){

    return adminService.deleteAnnouncement(id);

  },


  updateAdminSettings(changes){


    return adminService.updateSettings(changes);


  },


  resetAdminWorkspace(){


    adminService.resetOperationalData(
      initialSeed
    );


  }


};