import { QUESTIONS, QUESTION_BANK_REVISION, REPLACED_MODULE_IDS } from '../data/questions.data.js';
import { MODULES } from '../data/modules.data.js';
import { storageService } from './storage.service.js';

const PERSIST_KEY = 'admin_store';

const DEFAULT_MODULES = MODULES;
let store = {

modules: DEFAULT_MODULES,

questions: [],

participants: [],

schedules: [],

announcements: [],

settings: {

// Nilai default wajib ada. Tanpa ini halaman Laporan & Pengaturan
// menampilkan "undefined" dan perhitungan kelulusan jadi NaN.
passingScore: 60,

autoAdvanceDelayMs: 500,

defaultParticipantType: "BINJAS & PSI",

registrationOpen: true,

maintenanceMode: false

},

activities: [],

uiState:{}

};

/**
 * Simpan bagian data yang bisa diubah admin (soal, peserta, jadwal,
 * pengumuman, pengaturan) ke localStorage.
 *
 * KENAPA INI PERLU:
 * Tanpa ini, data yang dibuat admin (mis. pengumuman baru) hanya hidup di
 * memori tab browser itu saja. Begitu peserta membuka aplikasi di tab lain
 * atau me-refresh halaman, initialize() dipanggil ulang dari nol dan
 * pengumuman admin tadi hilang -- karena itulah pengumuman "tidak masuk" ke
 * peserta. Dengan disimpan ke localStorage, tab/refresh manapun di browser
 * yang sama akan membaca data admin yang paling baru.
 *
 * CATATAN: localStorage bersifat per-browser, jadi ini belum menyelesaikan
 * sinkronisasi lintas perangkat/lintas browser -- itu perlu backend
 * Firebase (lihat src/firebase/README.md) yang menulis ke Firestore.
 */
function persist(){

  storageService.set(PERSIST_KEY, {

    // Soal buatan admin disimpan di Firestore, bukan di localStorage.
    questions: store.questions.filter((q) => !q.custom),

    // Penanda revisi bank soal bawaan (lihat QUESTION_BANK_REVISION).
    bankRevision: QUESTION_BANK_REVISION,

    participants: store.participants,

    schedules: store.schedules,

    announcements: store.announcements,

    settings: store.settings,

  });

}




/**
 * Saat bank soal suatu modul diganti total di kode, soal lama bisa masih
 * tersimpan di localStorage browser atau di Firestore. Fungsi ini membuang
 * SEMUA soal lama milik modul yang diganti, lalu memakai soal dari kode.
 */
function replaceRevisedModules(base) {
  const replaced = new Set(REPLACED_MODULE_IDS);
  return [
    ...base.filter((q) => !replaced.has(q.moduleId)),
    ...QUESTIONS.filter((q) => replaced.has(q.moduleId)),
  ];
}

/**
 * Modul baru yang ditambahkan di kode (mis. twk2, tiu2, tkp2) belum ada di
 * data lama yang tersimpan di localStorage / Firestore, sehingga tampil
 * "0 soal". Fungsi ini menambahkan soal dari kode HANYA untuk modul yang
 * belum punya satu soal pun di daftar dasar. Soal modul lama tidak disentuh,
 * jadi soal yang sudah dihapus/diedit admin tidak muncul kembali.
 */
function mergeCodeQuestionsForNewModules(base) {
  const known = new Set(base.map((q) => q.moduleId));
  const extra = QUESTIONS.filter((q) => !known.has(q.moduleId));
  return extra.length ? [...base, ...extra] : base;
}

export const adminService = {




    initialize(data={}){

        const persisted = storageService.get(PERSIST_KEY, null);
        const bankOutdated = persisted?.bankRevision !== QUESTION_BANK_REVISION;

        store = {


        ...store,



        // Modul bawaan + modul buatan admin (dari Firestore). Array baru
        // supaya konstanta DEFAULT_MODULES tidak ikut termodifikasi.
        modules:
        [
          ...DEFAULT_MODULES,
          ...(data.customModules ?? []).map((item)=>({
            ...item,
            engine:'quiz',
            custom:true
          }))
        ],

        questions:
        [
          ...mergeCodeQuestionsForNewModules(
            (()=>{
              const base = persisted?.questions?.length
                ?
                persisted.questions.filter((q)=>!q.custom)
                :
                data.questions?.length
                ?
                data.questions
                :
                [...QUESTIONS];
              return bankOutdated ? replaceRevisedModules(base) : base;
            })()
          ),
          // Urut berdasarkan id (berisi timestamp) supaya nomor soal di
          // Admin > Kelola Soal stabil dan sesuai urutan pembuatan.
          ...[...(data.customQuestions ?? [])]
          .sort((a,b)=>String(a.id).localeCompare(String(b.id)))
          .map((item)=>({
            ...item,
            custom:true
          }))
        ],



        participants:
        persisted?.participants ?? data.participants ?? [],



        schedules:
        persisted?.schedules ?? data.schedules ?? [],



        announcements:
        persisted?.announcements ?? data.announcements ?? [],



        // Digabung (bukan diganti) supaya store lama yang tersimpan di
        // localStorage tetap mendapat key baru seperti passingScore.
        settings: {
          ...store.settings,
          ...(data.settings ?? {}),
          ...(persisted?.settings ?? {})
        }



        };


        },







/*
=====================
MODULE
=====================
*/


getModules(){


return store.modules.length ? store.modules : DEFAULT_MODULES;


},



/* Modul & soal buatan admin (sudah tersimpan di Firestore; ini
   hanya menyamakan data di memori aplikasi) */

upsertCustomModule(item){
const module={...item,engine:'quiz',custom:true};
const index=store.modules.findIndex(
m=>String(m.id)===String(module.id)
);
if(index===-1){
store.modules.push(module);
}else{
store.modules[index]=module;
}
return module;
},

removeCustomModule(id){
store.modules=store.modules.filter(
m=>String(m.id)!==String(id)
);
store.questions=store.questions.filter(
q=>!(q.custom && String(q.moduleId)===String(id))
);
},

upsertCustomQuestion(item){
const question={...item,custom:true};
const index=store.questions.findIndex(
q=>String(q.id)===String(question.id)
);
if(index===-1){
store.questions.push(question);
}else{
store.questions[index]=question;
}
return question;
},

removeCustomQuestion(id){
store.questions=store.questions.filter(
q=>String(q.id)!==String(id)
);
},

createModule(payload){


const item={


id:
Date.now(),


...payload


};



store.modules.push(item);



return item;


},




updateModule(id,changes){


const index =
store.modules.findIndex(
item=>String(item.id)===String(id)
);



if(index!==-1){


store.modules[index]={

...store.modules[index],

...changes

};


}


return store.modules[index];


},





deleteModule(id){


store.modules =
store.modules.filter(
item=>String(item.id)!==String(id)
);


},









/*
=====================
QUESTIONS
=====================
*/


getQuestions(){


return store.questions;


},





createQuestion(payload){


const item={


id:
Date.now(),


...payload


};



store.questions.push(item);



persist();


return item;


},






updateQuestion(id,changes){


const index =
store.questions.findIndex(
q=>String(q.id)===String(id)
);



if(index!==-1){


store.questions[index]={

...store.questions[index],

...changes

};


}


persist();


return store.questions[index];


},





deleteQuestion(id){


store.questions =

store.questions.filter(

q=>String(q.id)!==String(id)

);


persist();

},









/*
=====================
PARTICIPANTS
=====================
*/


getParticipants(){


return store.participants;


},




createParticipant(payload){


const item={


id:
Date.now(),


...payload


};



store.participants.push(item);



persist();


return item;


},




updateParticipant(id,changes){


const index =
store.participants.findIndex(
p=>String(p.id)===String(id)
);



if(index!==-1){


store.participants[index]={

...store.participants[index],

...changes

};


}


persist();


return store.participants[index];


},




deleteParticipant(id){


store.participants =

store.participants.filter(

p=>String(p.id)!==String(id)

);


persist();

},









/*
=====================
SCHEDULE
=====================
*/


getSchedules(){


return store.schedules;


},



createSchedule(payload){


const item={


id:
Date.now(),


...payload


};



store.schedules.push(item);



persist();


return item;


},




updateSchedule(id,changes){


const index =
store.schedules.findIndex(
x=>String(x.id)===String(id)
);



if(index!==-1){


store.schedules[index]={

...store.schedules[index],

...changes

};


}


persist();


return store.schedules[index];


},




deleteSchedule(id){


store.schedules =

store.schedules.filter(

x=>String(x.id)!==String(id)

);


persist();

},









/*
=====================
ANNOUNCEMENT
=====================
*/


getAnnouncements(){


return store.announcements;


},




createAnnouncement(payload){


const item={


id:
Date.now(),


status:"Published",


date:
new Date().toLocaleDateString("id-ID"),


...payload


};



store.announcements.push(item);



persist();


return item;


},




updateAnnouncement(id,changes){


const index =
store.announcements.findIndex(
x=>String(x.id)===String(id)
);



if(index!==-1){


store.announcements[index]={

...store.announcements[index],

...changes

};


}


persist();


return store.announcements[index];


},




deleteAnnouncement(id){


store.announcements =

store.announcements.filter(

x=>String(x.id)!==String(id)

);


persist();

},







/*
=====================
SETTING
=====================
*/


getSettings(){


return store.settings;


},




updateSettings(changes){


store.settings={


...store.settings,


...changes


};


persist();


return store.settings;


},









/*
=====================
ACTIVITY
=====================
*/


getActivities(limit=10){


return store.activities.slice(
0,
limit
);


},









/*
=====================
UI STATE
=====================
*/


getUiState(){


return store.uiState;


},




setUiState(changes){


store.uiState={


...store.uiState,


...changes


};



return store.uiState;


},









/*
=====================
RESET
=====================
*/


resetOperationalData(seed){


store={


...store,


...seed


};


persist();


}



};