import { storageService } from './storage.service.js';
import { DATA_SOURCE_CONFIG } from '../config/data-source.config.js';

const ROLE_KEY = 'role';

export const authService = {
  getRole() {
    return storageService.get(ROLE_KEY, 'guest');
  },

  loginAsUser() {
    storageService.set(ROLE_KEY, 'user');
  },

  loginAsAdmin() {
    storageService.set(ROLE_KEY, 'admin');
  },

  logout() {
    storageService.remove(ROLE_KEY);
    storageService.clearQuiz();
    storageService.remove('pauli_kraepelin_session');

    // Tanpa ini, status "role" lokal terhapus tapi sesi Firebase Auth
    // sebenarnya masih aktif (tersimpan di browser) -> kalau app dibuka
    // lagi, Firestore masih menganggap user login walau UI mengira sudah
    // logout. Sign out juga dari Firebase supaya keduanya konsisten.
    if (DATA_SOURCE_CONFIG.provider === 'firebase') {
      import('../firebase/config.js').then(({ auth }) => {
        import('https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js')
          .then(({ signOut }) => signOut(auth))
          .catch((error) => console.warn('[BISAM] Gagal sign out Firebase:', error));
      });
    }
  },

  isUser() {
    return this.getRole() === 'user';
  },

  isAdmin() {
    return this.getRole() === 'admin';
  },
};
