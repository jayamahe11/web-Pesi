import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  where,
  writeBatch,
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";

import { auth, db } from "../firebase/config.js";

/**
 * lockService
 * ------------------------------------------------------------------
 * Dua jenis kunci untuk soal (modul latihan & ujian):
 *
 * 1) KUNCI ADMIN (global)  -> collection `moduleLocks/{moduleId}`
 *    Admin mengunci/membuka sebuah modul untuk SEMUA peserta lewat
 *    Admin > Kunci Soal. Peserta melihat modul bergembok dan tidak bisa
 *    memulainya.
 *
 * 2) KUNCI OTOMATIS PER PESERTA -> collection `userLocks/{uid__moduleId}`
 *    Begitu peserta selesai mengerjakan sebuah modul, modul itu otomatis
 *    terkunci untuk peserta tersebut. Hanya admin yang bisa membuka
 *    kuncinya (Admin > Kunci Soal > Kunci per Peserta). Kalau dibuka dan
 *    peserta mengerjakan ulang, poin modul itu hanya DIPERBARUI ke nilai
 *    terbesar (bukan ditambah) — lihat rankingService.submitModuleBest().
 *
 * Kalau Firestore menolak membaca (mis. rules belum di-publish), kunci
 * dianggap "tidak ada" supaya aplikasi tidak macet; warning dicatat di
 * console.
 */

const GLOBAL = "moduleLocks";
const PER_USER = "userLocks";

export function userLockId(uid, moduleId) {
  return `${uid}__${moduleId}`;
}

export const lockService = {
  /** Set id modul yang dikunci admin. */
  async getGlobalLockedIds() {
    try {
      const snap = await getDocs(collection(db, GLOBAL));
      return new Set(
        snap.docs
          .filter((d) => d.data()?.locked)
          .map((d) => d.id)
      );
    } catch (error) {
      console.warn("[lockService] Gagal membaca kunci admin:", error?.message ?? error);
      return new Set();
    }
  },

  /** Set id modul yang sudah dikerjakan (terkunci otomatis) oleh peserta ini. */
  async getUserLockedIds(uid = auth.currentUser?.uid) {
    if (!uid) return new Set();

    try {
      const snap = await getDocs(
        query(collection(db, PER_USER), where("uid", "==", uid))
      );
      return new Set(
        snap.docs
          .filter((d) => d.data()?.locked !== false)
          .map((d) => d.data().moduleId)
      );
    } catch (error) {
      console.warn("[lockService] Gagal membaca kunci peserta:", error?.message ?? error);
      return new Set();
    }
  },

  /** Satu panggilan untuk halaman daftar modul. */
  async getAccessMap() {
    const [admin, done] = await Promise.all([
      this.getGlobalLockedIds(),
      this.getUserLockedIds(),
    ]);

    return {
      admin,
      done,
      /** 'admin' | 'done' | null */
      reasonFor(moduleId) {
        if (admin.has(moduleId)) return "admin";
        if (done.has(moduleId)) return "done";
        return null;
      },
    };
  },

  async getAccess(moduleId) {
    const map = await this.getAccessMap();
    const reason = map.reasonFor(moduleId);
    return { locked: Boolean(reason), reason };
  },

  /** Peserta: kunci modul otomatis setelah selesai dikerjakan. */
  async lockForCurrentUser({ moduleId, moduleTitle, score = 0, points = 0 } = {}) {
    const user = auth.currentUser;
    if (!user || !moduleId) return;

    try {
      await setDoc(
        doc(db, PER_USER, userLockId(user.uid, moduleId)),
        {
          uid: user.uid,
          name: user.displayName || user.email || "Peserta",
          email: user.email || null,
          moduleId: String(moduleId),
          moduleTitle: moduleTitle || String(moduleId),
          locked: true,
          lastScore: Number(score) || 0,
          lastPoints: Number(points) || 0,
          lockedAt: serverTimestamp(),
        }
      );
    } catch (error) {
      console.warn("[lockService] Gagal mengunci modul:", error?.message ?? error);
    }
  },

  /* ----------------------------- ADMIN ----------------------------- */

  async setModuleLocked(moduleId, locked, moduleTitle = "") {
    const ref = doc(db, GLOBAL, String(moduleId));

    if (!locked) {
      await deleteDoc(ref);
      return;
    }

    await setDoc(ref, {
      moduleId: String(moduleId),
      moduleTitle,
      locked: true,
      updatedAt: serverTimestamp(),
    });
  },

  async setManyModulesLocked(modules, locked) {
    for (let i = 0; i < modules.length; i += 400) {
      const batch = writeBatch(db);

      modules.slice(i, i + 400).forEach((module) => {
        const ref = doc(db, GLOBAL, String(module.id));

        if (locked) {
          batch.set(ref, {
            moduleId: String(module.id),
            moduleTitle: module.title || "",
            locked: true,
            updatedAt: serverTimestamp(),
          });
        } else {
          batch.delete(ref);
        }
      });

      await batch.commit();
    }
  },

  async listAllUserLocks() {
    const snap = await getDocs(collection(db, PER_USER));

    return snap.docs
      .map((d) => {
        const data = d.data() || {};
        const lockedAt = data.lockedAt?.toDate?.()?.toISOString?.() ?? null;
        return {
          id: d.id,
          uid: data.uid,
          name: data.name || "Peserta",
          email: data.email || "",
          moduleId: data.moduleId,
          moduleTitle: data.moduleTitle || data.moduleId,
          lastScore: Number(data.lastScore || 0),
          lastPoints: Number(data.lastPoints || 0),
          lockedAt,
        };
      })
      .sort((a, b) => String(b.lockedAt || "").localeCompare(String(a.lockedAt || "")));
  },

  /**
   * Buka kunci satu modul milik satu peserta. Setelah dihapus, dibaca ulang
   * untuk memastikan benar-benar hilang (kalau tidak, dianggap gagal).
   */
  async unlockUser(lockId) {
    if (!auth.currentUser) {
      const error = new Error('Sesi login habis. Masuk ulang sebagai admin.');
      error.code = 'unauthenticated';
      throw error;
    }

    const ref = doc(db, PER_USER, lockId);
    await deleteDoc(ref);

    const check = await getDoc(ref);
    if (check.exists()) {
      const error = new Error('Kunci masih ada setelah dihapus.');
      error.code = 'still-exists';
      throw error;
    }
  },

  /** Buka kunci banyak modul sekaligus (mis. semua milik satu peserta). */
  async unlockMany(lockIds = []) {
    for (const id of lockIds) {
      await this.unlockUser(id);
    }
  },
};
