import {
  doc,
  getDoc,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";


import {
  updateProfile as updateAuthProfile
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-auth.js";


import {
  auth,
  db
} from "../firebase/config.js";


import {
  storageService
} from "./storage.service.js";


import {
  rankingService
} from "./ranking.service.js";


import {
  firebaseRepository
} from "../repositories/firebase.repository.js";


import {
  lockService
} from "./lock.service.js";



const KEYS = Object.freeze({

  profile: "member_profile",

  history: "member_history",

  points: "member_points",

  moduleProgress: "member_module_progress",

  moduleBest: "member_module_best",

});


// Modul yang TIDAK ikut ranking/poin & tidak dikunci otomatis.
const NON_RANKED_MODULES = ["pauli-kraepelin"];





function initialsFromName(name = "") {


  const parts =
  name
  .trim()
  .split(/\s+/)
  .filter(Boolean);



  if(!parts.length)
      return "MB";



  return parts
  .slice(0,2)
  .map(
      part =>
      part[0]?.toUpperCase() ?? ""
  )
  .join("");

}





export const memberService = {



  async getProfile(fallbackProfile = {}) {


      let firebaseProfile = {};



      const user = auth.currentUser;



      if(user){


          firebaseProfile = {


              email:user.email,


              name:
              user.displayName ||
              user.email,


              uid:user.uid


          };



          try{


              const ref =
              doc(
                  db,
                  "users",
                  user.uid
              );



              const snap =
              await getDoc(ref);



              if(snap.exists()){


                  firebaseProfile = {


                      ...firebaseProfile,


                      ...snap.data()


                  };


              }



          }
          catch(error){


              console.error(
                  "Gagal mengambil data user Firestore",
                  error
              );


          }



      }




      const saved =
      storageService.get(
          KEYS.profile,
          null
      );




      let points =
      Number(
          storageService.get(
              KEYS.points,
              saved?.points ?? 0
          )
      );


      // Poin resmi ada di Firestore `rankings/{uid}` (itu yang dikoreksi
      // admin saat menghapus pengerjaan ganda). Kalau dokumennya ada,
      // pakai itu dan samakan penyimpanan lokal.
      if(user){

          try{

              const rankSnap =
              await getDoc(
                  doc(db, "rankings", user.uid)
              );

              if(rankSnap.exists()){

                  points =
                  Math.max(
                      0,
                      Number(rankSnap.data().points || 0)
                  );

                  storageService.set(
                      KEYS.points,
                      points
                  );

              }

          }
          catch(error){

              console.warn(
                  "Gagal membaca poin ranking",
                  error
              );

          }

      }




      const profile = {


          ...fallbackProfile,


          ...saved,


          ...firebaseProfile


      };




      return {

        ...profile,
    
    
        name:
        profile.name ||
        profile.nama ||
        profile.displayName ||
        profile.email ||
        "Peserta",
    
    
        nama:
        profile.nama ||
        profile.name ||
        profile.displayName ||
        profile.email ||
        "Peserta",
    
    
        displayName:
        profile.displayName ||
        profile.name ||
        profile.nama ||
        profile.email ||
        "Peserta",
    
    
        initials:
        initialsFromName(
            profile.name ||
            profile.nama ||
            profile.email
        ),
    
    
        points,
    
    
        rank:null,
    
    
        status:
        points > 0
        ? "Peserta Aktif"
        : "Member Baru"
    
    };


  },






  register({
      name,
      email,
      whatsapp
  }){


      const profile = {


          id:
          `local-${Date.now()}`,



          name:
          name.trim(),



          email:
          email.trim(),



          whatsapp:
          whatsapp.trim(),



          initials:
          initialsFromName(name),



          points:0,



          rank:null,



          status:
          "Member Baru"


      };




      storageService.set(
          KEYS.profile,
          profile
      );



      storageService.set(
          KEYS.points,
          0
      );



      storageService.set(
          KEYS.history,
          []
      );



      storageService.set(
          KEYS.moduleProgress,
          {}
      );



      return profile;


  },






  async updateProfile(
      changes={},
      fallbackProfile={}
  ){


      const current =
      await this.getProfile(
          fallbackProfile
      );


      const nextName =
      changes.name ??
      current.name;


      // Sinkronkan perubahan ke akun Firebase (bukan cuma localStorage)
      // supaya nama peserta SELALU sesuai nama pemilik akun di semua
      // perangkat/halaman (sidebar, dashboard, ranking, dll).
      const user = auth.currentUser;

      if(user){

          try{

              if(
                  changes.name &&
                  changes.name !== current.name
              ){

                  await updateAuthProfile(
                      user,
                      { displayName: changes.name }
                  );

              }

              await setDoc(
                  doc(db, "users", user.uid),
                  {
                      nama: nextName,
                      email:
                      changes.email ??
                      current.email ??
                      user.email,
                      whatsapp:
                      changes.whatsapp ??
                      current.whatsapp ??
                      "",
                  },
                  { merge: true }
              );

          }
          catch(error){

              console.error(
                  "Gagal menyinkronkan profil ke Firebase",
                  error
              );

          }

      }


      const next = {


          ...current,


          ...changes,



          initials:
          initialsFromName(
              nextName
          )


      };



      storageService.set(
          KEYS.profile,
          next
      );



      return next;


  },






  getHistory(){


      return storageService.get(
          KEYS.history,
          []
      );


  },






  getModuleProgress(){


      return storageService.get(
          KEYS.moduleProgress,
          {}
      );


  },






  recordResult(data){



      const history =
      this.getHistory();



      const now =
      new Date();



      const record = {


          id:
          `${data.moduleId}-${now.getTime()}`,



          moduleId:
          data.moduleId,



          module:
          data.moduleTitle,



          date:
          now.toLocaleDateString(
              "id-ID"
          ),



          score:
          data.score,



          points:
          NON_RANKED_MODULES.includes(data.moduleId)
          ? 0
          : (data.points || 0),



          status:
          "Selesai",



          createdAt:
          now.toISOString(),



          ...data.detail


      };




      const isPauli =
      NON_RANKED_MODULES.includes(data.moduleId);


      storageService.set(
          KEYS.history,
          [
              record,
              ...history
          ]
      );


      // Poin lokal = jumlah poin TERBAIK tiap modul (bukan dijumlah tiap
      // kali mengerjakan). Pauli & Kraepelin tidak ikut poin.
      if(!isPauli){

          const bestMap =
          storageService.get(
              KEYS.moduleBest,
              {}
          );

          bestMap[data.moduleId] =
          Math.max(
              Number(bestMap[data.moduleId] || 0),
              Number(data.points || 0)
          );

          storageService.set(
              KEYS.moduleBest,
              bestMap
          );

          storageService.set(
              KEYS.points,
              Object.values(bestMap).reduce(
                  (sum, value) =>
                  sum + (Number(value) || 0),
                  0
              )
          );

      }


      const authUser = auth.currentUser;

      const quizType =
      data.detail?.quizType ||
      (isPauli
        ? 'psikotes'
        : 'latihan');

      const pending = [];


      if(!isPauli){

          // Poin terbaik per modul ke leaderboard bersama (Firestore).
          pending.push(
              rankingService.submitModuleBest({
                  moduleId: data.moduleId,
                  points: data.points || 0,
                  name:
                  authUser?.displayName ||
                  authUser?.email ||
                  undefined,
                  email:
                  authUser?.email ||
                  undefined,
              })
          );

          // Ringkasan untuk halaman Ranking.
          pending.push(
              rankingService.recordAttempt({
                  moduleTitle: data.moduleTitle,
                  quizType,
                  score: data.score,
                  points: data.points || 0,
                  attemptKey: record.id,
              })
          );

          // Otomatis kunci modul ini untuk peserta; hanya admin yang bisa
          // membukanya lagi.
          pending.push(
              lockService.lockForCurrentUser({
                  moduleId: data.moduleId,
                  moduleTitle: data.moduleTitle,
                  score: data.score,
                  points: data.points || 0,
              })
          );

      }


      // Rincian lengkap (termasuk jawaban per soal) hanya untuk admin &
      // pemilik akun — dipakai halaman Admin > Laporan & Hasil.
      if(authUser){

          const attemptPayload = {

              userId: authUser.uid,

              attemptKey: record.id,

              name:
              authUser.displayName ||
              authUser.email ||
              'Peserta',

              moduleId: data.moduleId,

              moduleTitle: data.moduleTitle,

              quizType,

              score: data.score,

              // Pauli & Kraepelin: tidak bernilai poin ranking.
              points: isPauli ? 0 : (data.points || 0),

              rawScore:
              data.detail?.rawScore ??
              data.correct ??
              null,

              wrong:
              data.detail?.wrong ??
              data.wrong ??
              null,

              total:
              data.detail?.total ??
              data.total ??
              null,

              categoryBreakdown:
              data.detail?.categoryBreakdown ?? null,

              questionRows:
              data.detail?.questionRows ?? null,

              completedAt:
              data.detail?.completedAt ??
              now.toISOString(),

          };

          pending.push(
              isPauli
              ? firebaseRepository.recordPauliAttempt(attemptPayload)
              : firebaseRepository.recordQuizAttempt(attemptPayload)
          );

      }


      // `ready` = janin semua penulisan ke Firestore sudah selesai (dipakai
      // halaman kuis supaya kunci modul sudah tersimpan sebelum pindah
      // halaman). Tidak ikut tersimpan ke localStorage.
      Object.defineProperty(
          record,
          'ready',
          {
              value: Promise.allSettled(pending),
              enumerable: false
          }
      );


      return record;


  },







  resetMemberData({
      keepProfile=true
  }={}){


      const profile =
      keepProfile
      ?
      storageService.get(
          KEYS.profile,
          null
      )
      :
      null;




      Object.values(KEYS)
      .forEach(
          key =>
          storageService.remove(key)
      );




      if(
          keepProfile &&
          profile
      ){


          storageService.set(
              KEYS.profile,
              {


                  ...profile,


                  points:0,


                  rank:null,


                  status:
                  "Member Baru"


              }
          );


      }



  }



};