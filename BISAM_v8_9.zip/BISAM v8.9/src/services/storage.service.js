import { APP_CONFIG } from '../config/app.config.js';

const prefix = APP_CONFIG.storagePrefix;

function key(name) {
  return `${prefix}_${name}`;
}

export const storageService = {
  get(name, fallback = null) {
    const raw = localStorage.getItem(key(name));
    if (raw === null) return fallback;

    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  },

  set(name, value) {
    localStorage.setItem(key(name), JSON.stringify(value));
  },

  remove(name) {
    localStorage.removeItem(key(name));
  },

  clearQuiz() {
    [
      'quiz_index',
      'quiz_answers',
      'quiz_started_at',
      'quiz_locked',
      'quiz_module_id',
      'quiz_finalized',
    ].forEach((name) => this.remove(name));
  },
};
