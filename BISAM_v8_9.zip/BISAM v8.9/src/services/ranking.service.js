import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  where,
  writeBatch,
} from "https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js";

import { auth, db } from "../firebase/config.js";

/**
 * rankingService
 * ------------------------------------------------------------------
 * Leaderboard nyata lintas peserta (bukan mock, bukan localStorage).
 * Setiap peserta yang menyelesaikan latihan/ujian akan menambah poin
 * miliknya sendiri di collection Firestore `rankings/{uid}`. Semua
 * peserta yang login bisa membaca seluruh isi collection ini sehingga
 * leaderboard (top 1, 2, 3, dst) otomatis terisi siapa pun yang memakai
 * aplikasi — tidak perlu setup tambahan per akun.
 *
 * PENTING: supaya penulisan ke `rankings/{uid}` diizinkan, security rules
 * Firestore project harus mengizinkan pemilik akun menulis dokumennya
 * sendiri. Lihat `src/firebase/firestore.rules.example` (bagian
 * `match /rankings/{userId}`) dan publish rules tersebut ke Firebase
 * Console > Firestore Database > Rules.
 */

const RANKING_COLLECTION = "rankings";
const DEFAULT_LEADERBOARD_LIMIT = 100;

/**
 * ATURAN POIN (penting):
 *  - Poin ranking = JUMLAH dari poin TERBAIK tiap modul (`moduleBest`).
 *  - Mengerjakan ulang modul yang sama TIDAK menambah poin; poin modul itu
 *    hanya diperbarui kalau hasil barunya lebih besar dari sebelumnya.
 *  - Pauli & Kraepelin tidak ikut ranking (hanya modul pilihan ganda).
 *  - Perhitungan memakai transaksi Firestore, jadi kalau fungsi terpanggil
 *    dua kali (klik ganda, koneksi lambat) hasilnya tetap sama.
 */

function sumBest(moduleBest = {}) {
  return Object.values(moduleBest).reduce(
    (total, value) => total + (Number(value) || 0),
    0
  );
}

/** Bangun peta {moduleId: poinTerbesar} dari kumpulan pengerjaan quiz. */
export function bestFromAttempts(attempts = []) {
  const best = {};

  attempts.forEach((item) => {
    if (!item?.moduleId) return;
    const key = String(item.moduleId);
    best[key] = Math.max(best[key] ?? 0, Number(item.points) || 0);
  });

  return best;
}

export const rankingService = {
  /**
   * Catat hasil sebuah modul ke leaderboard: simpan poin TERBESAR per
   * modul, lalu hitung ulang total poin peserta. Non-blocking: kalau gagal
   * hanya dicatat sebagai warning.
   */
  async submitModuleBest({ moduleId, points = 0, name, email } = {}) {
    const user = auth.currentUser;
    const value = Math.max(0, Number(points) || 0);

    if (!user || !moduleId) {
      return null;
    }

    const ref = doc(db, RANKING_COLLECTION, user.uid);
    const key = String(moduleId);

    try {
      // Data lama (sebelum aturan "poin terbaik") belum punya `moduleBest`.
      // Bangun dari riwayat pengerjaan peserta sendiri supaya poin lama
      // yang tercatat dobel ikut terkoreksi.
      let rebuilt = null;
      const first = await getDoc(ref);

      if (!first.exists() || !first.data()?.moduleBest) {
        const attemptsSnap = await getDocs(
          query(collection(db, "quizAttempts"), where("userId", "==", user.uid))
        );
        rebuilt = bestFromAttempts(attemptsSnap.docs.map((d) => d.data()));
      }

      return await runTransaction(db, async (tx) => {
        const snap = await tx.get(ref);
        const current = snap.exists() ? snap.data() : {};

        const best = { ...(current.moduleBest ?? rebuilt ?? {}) };
        const previous = Number(best[key]) || 0;
        const improved = value > previous || !(key in best);

        best[key] = Math.max(previous, value);

        const total = sumBest(best);

        tx.set(
          ref,
          {
            uid: user.uid,
            name: name || current.name || user.displayName || user.email || "Peserta",
            email: email || current.email || user.email || null,
            moduleBest: best,
            points: total,
            updatedAt: serverTimestamp(),
          },
          { mergeFields: ["uid", "name", "email", "moduleBest", "points", "updatedAt"] }
        );

        return { total, best: best[key], previous, improved };
      });
    } catch (error) {
      console.warn(
        "[rankingService] Gagal memperbarui ranking di Firestore:",
        error?.message ?? error
      );
      return null;
    }
  },

  /**
   * ADMIN: hitung ulang poin SEMUA peserta dari riwayat quizAttempts
   * (poin terbaik per modul, tanpa Pauli & Kraepelin). Dipakai untuk
   * membersihkan poin lama yang tercatat dobel.
   */
  async recalculateAll() {
    const [attemptsSnap, rankingSnap] = await Promise.all([
      getDocs(collection(db, "quizAttempts")),
      getDocs(collection(db, RANKING_COLLECTION)),
    ]);

    const byUser = new Map();

    attemptsSnap.docs.forEach((d) => {
      const data = d.data();
      if (!data.userId) return;
      const entry = byUser.get(data.userId) ?? { name: data.name, attempts: [] };
      entry.name = entry.name || data.name;
      entry.attempts.push(data);
      byUser.set(data.userId, entry);
    });

    const existing = new Map(rankingSnap.docs.map((d) => [d.id, d.data()]));
    const uids = new Set([...byUser.keys(), ...existing.keys()]);

    const writes = [];

    uids.forEach((uid) => {
      const attempts = byUser.get(uid)?.attempts ?? [];
      const moduleBest = bestFromAttempts(attempts);
      const old = existing.get(uid) ?? {};

      writes.push({
        ref: doc(db, RANKING_COLLECTION, uid),
        data: {
          uid,
          name: old.name || byUser.get(uid)?.name || "Peserta",
          email: old.email ?? null,
          moduleBest,
          points: sumBest(moduleBest),
          updatedAt: serverTimestamp(),
        },
      });
    });

    for (let i = 0; i < writes.length; i += 400) {
      const batch = writeBatch(db);
      writes.slice(i, i + 400).forEach(({ ref, data }) => {
        batch.set(ref, data, {
          mergeFields: ["uid", "name", "email", "moduleBest", "points", "updatedAt"],
        });
      });
      await batch.commit();
    }

    return { participants: writes.length };
  },

  /**
   * Mengambil leaderboard nyata (semua peserta), terurut dari poin
   * tertinggi ke terendah. Posisi 1/2/3 tinggal diambil dari urutan
   * index array ini (lihat `ranking.page.js`).
   */
  async getLeaderboard(limitCount = DEFAULT_LEADERBOARD_LIMIT) {
    try {
      const rankingQuery = query(
        collection(db, RANKING_COLLECTION),
        orderBy("points", "desc"),
        limit(limitCount)
      );

      const snapshot = await getDocs(rankingQuery);

      return snapshot.docs.map((docSnap) => {
        const data = docSnap.data() || {};
        return {
          uid: docSnap.id,
          name: data.name || "Peserta",
          points: Number(data.points || 0),
        };
      });
    } catch (error) {
      console.warn(
        "[rankingService] Gagal memuat leaderboard dari Firestore:",
        error?.message ?? error
      );
      return [];
    }
  },

  /**
   * Simpan RINGKASAN satu kali pengerjaan (nama modul, tipe latihan/ujian,
   * nilai) ke sub-collection publik `rankings/{uid}/attempts`. Ini yang
   * dipakai halaman Ranking supaya peserta lain bisa lihat "si A barusan
   * ngerjain modul apa & dapat nilai berapa" tanpa membuka jawaban detail
   * per soal (itu hanya untuk admin & pemilik akun, lihat quizAttempts).
   */
  async recordAttempt({ moduleTitle, quizType, score, points, attemptKey } = {}) {
    const user = auth.currentUser;

    if (!user) {
      return;
    }

    try {
      // Id dokumen = attemptKey supaya pemanggilan ganda tidak membuat
      // dua baris riwayat yang sama.
      const attemptsRef = attemptKey
        ? doc(db, RANKING_COLLECTION, user.uid, "attempts", String(attemptKey))
        : doc(collection(db, RANKING_COLLECTION, user.uid, "attempts"));

      await setDoc(attemptsRef, {
        moduleTitle: moduleTitle || "Modul",
        quizType: quizType || "latihan",
        score: Number(score) || 0,
        points: Number(points) || 0,
        attemptKey: attemptKey || null,
        completedAt: serverTimestamp(),
      });
    } catch (error) {
      console.warn(
        "[rankingService] Gagal menyimpan riwayat ranking:",
        error?.message ?? error
      );
    }
  },

  /**
   * Ambil ringkasan riwayat pengerjaan milik satu peserta (dipakai saat
   * peserta lain klik "Lihat riwayat" pada baris leaderboard).
   */
  async getAttempts(uid, limitCount = 20) {
    if (!uid) return [];

    try {
      const attemptsQuery = query(
        collection(db, RANKING_COLLECTION, uid, "attempts"),
        orderBy("completedAt", "desc"),
        limit(limitCount)
      );

      const snapshot = await getDocs(attemptsQuery);

      return snapshot.docs.map((docSnap) => {
        const data = docSnap.data() || {};
        return {
          id: docSnap.id,
          moduleTitle: data.moduleTitle || "Modul",
          quizType: data.quizType || "latihan",
          score: Number(data.score || 0),
          points: Number(data.points || 0),
        };
      });
    } catch (error) {
      console.warn(
        "[rankingService] Gagal memuat riwayat ranking:",
        error?.message ?? error
      );
      return [];
    }
  },
};
