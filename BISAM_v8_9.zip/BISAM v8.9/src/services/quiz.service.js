import { QUESTIONS } from '../data/questions.data.js';



let currentQuiz = null;



export const quizService = {



start(moduleId){



const questions = QUESTIONS.filter(

q => q.moduleId === moduleId

);





currentQuiz = {


moduleId,


questions,


currentIndex:0,


answers:[],


startTime:new Date(),


duration:30*60


};




return currentQuiz;


},







getCurrent(){


return currentQuiz;


},







answer(questionId,answer){



if(!currentQuiz)return;



currentQuiz.answers.push({


questionId,


answer



});



},







next(){



if(!currentQuiz)return null;



currentQuiz.currentIndex++;



return currentQuiz.currentIndex;



},







calculateScore(){



if(!currentQuiz)return null;



let benar=0;



currentQuiz.answers.forEach(item=>{


const soal =

currentQuiz.questions.find(

q=>q.id===item.questionId

);




if(

soal &&

soal.answer===item.answer

){


benar++;

}


});





return {


total:

currentQuiz.questions.length,



benar,



salah:

currentQuiz.questions.length-benar,



nilai:

Math.round(

(benar/currentQuiz.questions.length)*100

)



};



},








finish(){


const result =
this.calculateScore();



currentQuiz=null;



return result;


}



};