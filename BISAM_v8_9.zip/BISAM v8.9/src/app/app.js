import { Router } from './router.js';


export function startApp(){


const rootElement =
document.getElementById("app");



if(!rootElement){

console.error(
"Element #app tidak ditemukan"
);

return;

}



const router =
new Router(rootElement);



router.start();



}