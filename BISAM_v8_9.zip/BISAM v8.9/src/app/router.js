import { ROUTES } from './routes.js';

import { authService } from '../services/auth.service.js';



export class Router {


constructor(rootElement){


this.rootElement = rootElement;

this.currentPage = null;


this.onHashChange =
this.renderCurrentRoute.bind(this);


}






start(){


window.addEventListener(
"hashchange",
this.onHashChange
);


this.renderCurrentRoute();


}






stop(){


window.removeEventListener(
"hashchange",
this.onHashChange
);


this.unmountCurrentPage();


}







getCurrentPath() {

    const hash =
    window.location.hash.replace(/^#/,'') || '/';


    return hash.split('?')[0];

}







navigate(path){


window.location.hash = path;


}







async renderCurrentRoute(){



const path =
this.getCurrentPath();




const route =
ROUTES.find(
(item)=>item.path===path
);





if(!route){


this.navigate(
this.getFallbackPath()
);


return;


}







if(!this.isAllowed(route.role)){



this.navigate(

route.role==="admin"

?

"/admin-login"

:

"/login"

);


return;


}







this.unmountCurrentPage();






const page =
await route.page(this);





this.currentPage =
page;






this.rootElement.innerHTML =

await route.layout(

page.html

);






page.mount?.();




window.scrollTo(
0,
0
);



}







unmountCurrentPage(){


// Pindah halaman: pastikan kunci scroll dari modal/drawer terlepas.
document.body.classList.remove('has-modal');


this.currentPage?.unmount?.();


this.currentPage=null;


}







isAllowed(role){



if(role==="public"){

return true;

}




if(role==="user"){

return authService.isUser();

}




if(role==="admin"){

return authService.isAdmin();

}



return false;



}







getFallbackPath(){



if(authService.isAdmin()){

return "/admin/dashboard";

}



if(authService.isUser()){

return "/dashboard";

}



return "/";

}



}