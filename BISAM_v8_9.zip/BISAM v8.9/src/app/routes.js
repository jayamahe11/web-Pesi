import {
  ADMIN_NAVIGATION,
  USER_NAVIGATION
} from '../config/navigation.config.js';
  
  
  
  import {
  publicLayout
} from '../components/layouts/public-layout.js';
  
  
  
  import {
  authLayout
} from '../components/layouts/auth-layout.js';
  
  
  
  import {
  dashboardLayout
} from '../components/layouts/dashboard-layout.js';
  
  
  
  
  
  import {
  landingPage
} from '../pages/public/landing.page.js';
  
  
  
  import {
  authPage
} from '../pages/public/auth.page.js';
  
  
  
  
  
  import {
  userDashboardPage
} from '../pages/user/dashboard.page.js';
  
  
  
  import {
  userModulesPage
} from '../pages/user/modules.page.js';
  
  
  
  import {
  userExamPage
} from '../pages/user/ujian.page.js';
  
  
  
  import {
  userQuizPage
} from '../pages/user/quiz.page.js';
  
  
  
  import {
  pauliKraepelinPage
} from '../features/pauli-kraepelin/pauli-kraepelin.page.js';
  
  
  
  import {
  userRankingPage
} from '../pages/user/ranking.page.js';
  
  
  
  import {
  userHistoryPage
} from '../pages/user/history.page.js';
  
  
  
  import {
  userSchedulePage
} from '../pages/user/schedule.page.js';
  
  
  
  import {
  userAnnouncementsPage
} from '../pages/user/announcements.page.js';
  
  
  
  import {
  profilePage
} from '../pages/profile.js';



  import {
  userSettingsPage
} from '../pages/user/settings.page.js';
  
  
  
  
  
  import {
  adminDashboardPage
} from '../pages/admin/dashboard.page.js';
  
  
  
  import {
  adminParticipantsPage
} from '../pages/admin/participants.page.js';
  
  
  
  import {
  adminModulesPage
} from '../pages/admin/modules.page.js';
  
  
  
  import {
  adminQuestionsPage
} from '../pages/admin/questions.page.js';
  
  
  
  import {
  adminSchedulePage
} from '../pages/admin/schedule.page.js';
  
  
  
  import {
  adminReportsPage
} from '../pages/admin/reports.page.js';
  
  
  
  import {
  adminAnnouncementsPage
} from '../pages/admin/announcements.page.js';
  
  
  
  import {
  adminSettingsPage
} from '../pages/admin/settings.page.js';


import { adminLocksPage } from '../pages/admin/locks.page.js';

import { binjasPage } from '../pages/public/binjas.page.js';

import { psiPage } from '../pages/public/psi.page.js';
  
  
  
  
  
  
  
  const publicRoute =
  (path,page,layout=publicLayout)=>({
  
  path,
  
  role:"public",
  
  page,
  
  layout
  
  });
  
  
  
  
  
  
  
  const userRoute =
  (path,page)=>({
  
  
  path,
  
  
  role:"user",
  
  
  page,
  
  
  
  layout:(content)=>
  
  dashboardLayout({
  
  content,
  
  navigation:USER_NAVIGATION,
  
  activePath:path,
  
  admin:false
  
  })
  
  });
  
  // NB: dashboardLayout sekarang async (mengambil nama & poin peserta asli
  // dari Firebase), jadi Router.renderCurrentRoute() WAJIB "await route.layout(...)".
  
  
  
  
  
  
  
  const adminRoute =
  (path,page)=>({
  
  
  path,
  
  
  role:"admin",
  
  
  page,
  
  
  
  layout:(content)=>
  
  dashboardLayout({
  
  content,
  
  navigation:ADMIN_NAVIGATION,
  
  activePath:path,
  
  admin:true
  
  })
  
  });
  
  
  
  
  
  
  
  
  
  export const ROUTES=[
  
  
  
  
  publicRoute('/', (router) => landingPage(router)),
  
  
  
  publicRoute(
  "/binjas",
  (router)=>binjasPage(router)
  ),
  
  
  
  publicRoute(
  "/psi",
  (router)=>psiPage(router)
  ),
  
  
  
  publicRoute(
  "/login",
  (router)=>authPage("login",router),
  authLayout
  ),
  
  
  
  publicRoute(
  "/register",
  (router)=>authPage("register",router),
  authLayout
  ),
  
  
  
  publicRoute(
  "/admin-login",
  (router)=>authPage("admin",router),
  authLayout
  ),
  
  
  
  
  
  
  
  userRoute(
  "/dashboard",
  ()=>userDashboardPage()
  ),
  
  
  
  userRoute(
  "/modules",
  (router)=>userModulesPage(router)
  ),
  
  
  
  userRoute(
  "/ujian",
  (router)=>userExamPage(router)
  ),
  
  
  
  userRoute(
  "/quiz",
  (router)=>userQuizPage(router)
  ),
  
  
  
  userRoute(
  "/pauli-kraepelin",
  (router)=>pauliKraepelinPage(router)
  ),
  
  
  
  userRoute(
  "/ranking",
  ()=>userRankingPage()
  ),
  
  
  
  userRoute(
  "/history",
  ()=>userHistoryPage()
  ),
  
  
  
  userRoute(
  "/schedule",
  ()=>userSchedulePage()
  ),
  
  
  
  userRoute(
  "/announcements",
  ()=>userAnnouncementsPage()
  ),
  
  
  
  
  userRoute(
  "/profile",
  ()=>profilePage()
  ),



  userRoute(
  "/settings",
  ()=>userSettingsPage()
  ),
  
  
  
  
  
  
  
  
  adminRoute(
  "/admin/dashboard",
  (router)=>adminDashboardPage(router)
  ),
  
  
  
  adminRoute(
  "/admin/participants",
  (router)=>adminParticipantsPage(router)
  ),
  
  
  
  adminRoute(
  "/admin/modules",
  (router)=>adminModulesPage(router)
  ),
  
  
  
  adminRoute(
  "/admin/questions",
  (router)=>adminQuestionsPage(router)
  ),
  
  
  
  adminRoute(
  "/admin/locks",
  (router)=>adminLocksPage(router)
  ),
  
  
  
  adminRoute(
  "/admin/schedule",
  (router)=>adminSchedulePage(router)
  ),
  
  
  
  adminRoute(
  "/admin/reports",
  (router)=>adminReportsPage(router)
  ),
  
  
  
  adminRoute(
  "/admin/announcements",
  (router)=>adminAnnouncementsPage(router)
  ),
  
  
  
  adminRoute(
  "/admin/settings",
  (router)=>adminSettingsPage(router)
  )
  
  
  
  ];