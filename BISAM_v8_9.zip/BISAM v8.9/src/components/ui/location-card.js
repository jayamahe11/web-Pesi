import { APP_CONFIG } from '../../config/app.config.js';
import { escapeHtml } from '../../utils/html.js';

function hasCoordinates({ latitude, longitude } = {}) {
  return (
    latitude !== null &&
    longitude !== null &&
    latitude !== '' &&
    longitude !== '' &&
    Number.isFinite(Number(latitude)) &&
    Number.isFinite(Number(longitude))
  );
}

/**
 * Bagian "Lokasi" (peta + koordinat). Data dari APP_CONFIG.location
 * (src/config/app.config.js). Peta memakai embed Google Maps, tidak butuh
 * API key.
 */
export function locationSection() {
  const location = APP_CONFIG.location ?? {};
  const name = escapeHtml(location.name || APP_CONFIG.fullName);
  const address = location.address ? escapeHtml(location.address) : '';

  if (!hasCoordinates(location)) {
    console.warn(
      '[BISAM] Koordinat lokasi belum diisi. Isi APP_CONFIG.location.latitude/longitude di src/config/app.config.js.'
    );

    return `
      <section class="location-section" id="lokasi">
        <div class="location-section__info">
          <span class="landing-tag">LOKASI</span>
          <h2>Lokasi ${name}</h2>
          ${address ? `<p>${address}</p>` : ''}
          <p>Informasi lokasi akan segera diumumkan.</p>
        </div>
      </section>
    `;
  }

  const lat = Number(location.latitude);
  const lng = Number(location.longitude);
  const zoom = Number(location.zoom) || 16;

  const coordinates = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  const mapsLink = `https://www.google.com/maps?q=${lat},${lng}`;
  const embedSrc = `https://www.google.com/maps?q=${lat},${lng}&z=${zoom}&output=embed`;

  return `
    <section class="location-section" id="lokasi">
      <div class="location-section__info">
        <span class="landing-tag">LOKASI</span>
        <h2>Lokasi ${name}</h2>
        ${address ? `<p>${address}</p>` : ''}

        <dl class="location-coords">
          <dt>Koordinat</dt>
          <dd><code>${coordinates}</code></dd>
          <dt>Latitude</dt>
          <dd>${lat.toFixed(6)}</dd>
          <dt>Longitude</dt>
          <dd>${lng.toFixed(6)}</dd>
        </dl>

        <a class="landing-button" href="${mapsLink}" target="_blank" rel="noopener noreferrer">
          Buka di Google Maps
        </a>
      </div>

      <div class="location-section__map">
        <iframe
          title="Peta lokasi ${name}"
          src="${embedSrc}"
          loading="lazy"
          referrerpolicy="no-referrer-when-downgrade"
          allowfullscreen
        ></iframe>
      </div>
    </section>
  `;
}

/** Ringkasan satu baris untuk footer. */
export function locationFooterLine() {
  const location = APP_CONFIG.location ?? {};

  if (!hasCoordinates(location)) {
    return location.address ? escapeHtml(location.address) : '';
  }

  const lat = Number(location.latitude);
  const lng = Number(location.longitude);

  return `
    ${location.address ? `${escapeHtml(location.address)} • ` : ''}
    <a href="https://www.google.com/maps?q=${lat},${lng}" target="_blank" rel="noopener noreferrer">${lat.toFixed(6)}, ${lng.toFixed(6)}</a>
  `;
}
