export function pageHeading({ title, description = '', action = '' }) {
  return `
    <header class="page-heading">
      <div>
        <h1>${title}</h1>
        ${description ? `<p>${description}</p>` : ''}
      </div>
      ${action}
    </header>
  `;
}
