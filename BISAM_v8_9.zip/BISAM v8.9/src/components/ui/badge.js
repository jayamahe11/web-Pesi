export function badge(status) {
  const value = String(status ?? '');
  const normalized = value.trim().toLowerCase();

  let variant = 'muted';
  if (['aktif', 'selesai', 'lulus', 'terbit'].includes(normalized)) variant = 'success';
  if (['proses', 'sedang proses', 'terjadwal', 'berjalan', 'menunggu'].includes(normalized)) variant = 'warning';
  if (['nonaktif', 'gagal', 'dibatalkan'].includes(normalized)) variant = 'danger';

  return `<span class="badge badge--${variant}">${value}</span>`;
}
