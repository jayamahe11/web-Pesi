import { qsa } from '../../utils/dom.js';

export function modal({ id, title, description = '', body = '', footer = '', size = 'md' }) {
  return `
    <div class="modal" id="${id}" hidden>
      <div class="modal__backdrop" data-modal-close="${id}"></div>
      <section class="modal__dialog modal__dialog--${size}" role="dialog" aria-modal="true" aria-labelledby="${id}-title">
        <header class="modal__header">
          <div>
            <h2 id="${id}-title">${title}</h2>
            ${description ? `<p>${description}</p>` : ''}
          </div>
          <button class="icon-button" type="button" data-modal-close="${id}" aria-label="Tutup">×</button>
        </header>
        <div class="modal__body">${body}</div>
        ${footer ? `<footer class="modal__footer">${footer}</footer>` : ''}
      </section>
    </div>
  `;
}

export function openModal(id) {
  const element = document.getElementById(id);
  if (!element) return;
  element.hidden = false;
  document.body.classList.add('has-modal');
  const closeButtons =
    element.querySelectorAll('[data-modal-close]');
  closeButtons.forEach(button=>{
    button.onclick = ()=>{
      closeModal(id);
    };
  });
  const firstField =
    element.querySelector(
      'input, select, textarea, button'
    );
  window.setTimeout(
    ()=>firstField?.focus(),
    0
  );
}
export function closeModal(id) {
  const element = document.getElementById(id);
  if (!element) return;

  element.hidden = true;

  // Lepas kunci scroll halaman kalau sudah tidak ada modal yang terbuka.
  // (Sebelumnya class 'has-modal' tidak pernah dilepas sehingga halaman
  // tidak bisa di-scroll lagi setelah modal ditutup.)
  if (!document.querySelector('.modal:not([hidden])')) {
    document.body.classList.remove('has-modal');
  }
}
let modalDismissBound = false;
export function bindModalDismiss() {
  if (modalDismissBound) {
    return () => {};
  }
  modalDismissBound = true;
  const onClick = (event) => {
    const trigger = event.target.closest('[data-modal-close]');
    if (!trigger) return;
    closeModal(trigger.dataset.modalClose);
  };
  document.addEventListener(
    'click',
    onClick
  );
  const onKeyDown = (event) => {
    if (event.key !== 'Escape') return;
    qsa('.modal:not([hidden])')
      .forEach((element) => {
        closeModal(element.id);
      });
  };

  document.addEventListener(
    'keydown',
    onKeyDown
  );

  return () => {
    document.removeEventListener(
      'click',
      onClick
    );
    document.removeEventListener(
      'keydown',
      onKeyDown
    );
    modalDismissBound = false;
  };
}