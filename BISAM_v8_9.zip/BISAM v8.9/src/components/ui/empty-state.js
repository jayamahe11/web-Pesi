export function emptyState({ title, description, action = '' }) {
  return `
    <div class="empty-state">
      <div class="empty-state__icon" aria-hidden="true">○</div>
      <strong>${title}</strong>
      <p>${description}</p>
      ${action}
    </div>
  `;
}
