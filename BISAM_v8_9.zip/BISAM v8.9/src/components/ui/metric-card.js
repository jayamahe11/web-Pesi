export function metricCard({ label, value, icon = '•' }) {
  return `
    <article class="card metric-card">
      <div>
        <div class="metric-card__label">${label}</div>
        <div class="metric-card__value">${value}</div>
      </div>
      <div class="metric-card__icon" aria-hidden="true">${icon}</div>
    </article>
  `;
}
