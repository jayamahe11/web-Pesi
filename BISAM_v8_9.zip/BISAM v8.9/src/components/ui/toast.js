export function showToast(message, type = 'default') {
  let root = document.getElementById('toast-root');

  if (!root) {
    root = document.createElement('div');
    root.id = 'toast-root';
    document.body.append(root);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.textContent = message;
  root.append(toast);

  window.setTimeout(() => toast.remove(), 2400);
}
