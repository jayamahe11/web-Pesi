export function rankingRow({ item, position, currentUserId, currentUserName }) {
  const isCurrentUser = currentUserId
    ? item.uid === currentUserId
    : item.name === currentUserName;

  return `
    <div class="ranking-row ${isCurrentUser ? 'ranking-row--me' : ''}">
      <div class="ranking-row__position">${position <= 3 ? ["🥇","🥈","🥉"][position-1] : position}</div>
      <div class="ranking-row__name">${item.name}</div>
      <div class="ranking-row__points">${item.points} poin</div>
    </div>
  `;
}
