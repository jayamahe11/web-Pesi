export function authLayout(content) {

  return `

    <main class="auth-layout-new">

      ${content}

    </main>

  `;

}