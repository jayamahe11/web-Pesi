import { APP_CONFIG } from '../../config/app.config.js';
import { locationFooterLine } from '../ui/location-card.js';

function currentPath() {
  return (window.location.hash.replace(/^#/, '') || '/').split('?')[0];
}

export function publicLayout(content) {
  const path = currentPath();
  const active = (target) => (path === target ? 'is-active' : '');
  const footerLocation = locationFooterLine();

  return `
    <div class="public-layout">
      <header class="public-header">
        <a class="public-brand" href="#/">
          <img src="${APP_CONFIG.logoUrl}" alt="${APP_CONFIG.fullName}" />
          <span>
            <strong>Bintang Samudra</strong>
            <small>BINJAS & PSI</small>
          </span>
        </a>

        <button class="public-hamburger" type="button" data-public-menu aria-label="Buka menu" aria-expanded="false" aria-controls="public-nav">
          <span></span><span></span><span></span>
        </button>

        <nav class="public-nav" id="public-nav" aria-label="Navigasi utama">
          <a class="${active('/')}" href="#/">Beranda</a>
          <a class="${active('/binjas')}" href="#/binjas">BINJAS</a>
          <a class="${active('/psi')}" href="#/psi">PSI</a>
          <a class="button button--primary" href="#/login">Masuk</a>
        </nav>
      </header>

      <main>${content}</main>

      <footer class="public-footer">
        <div class="public-footer__brand">
          <strong>${APP_CONFIG.fullName}</strong>
          ${footerLocation ? `<small>📍 ${footerLocation}</small>` : ''}
        </div>
        <nav class="public-footer__nav" aria-label="Navigasi footer">
          <a href="#/">Beranda</a>
          <a href="#/binjas">BINJAS</a>
          <a href="#/psi">PSI</a>
          <a href="#/login">Masuk</a>
        </nav>
      </footer>
    </div>
  `;
}


// Satu listener global untuk tombol hamburger & menutup menu saat link diklik.
if (!window.__bisamPublicMenuBound) {
  window.__bisamPublicMenuBound = true;

  document.addEventListener('click', (event) => {
    const header = document.querySelector('.public-header');
    if (!header) return;

    const toggle = event.target.closest('[data-public-menu]');
    const link = event.target.closest('.public-nav a');

    if (toggle) {
      const open = header.classList.toggle('is-menu-open');
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
    } else if (link || !event.target.closest('.public-header')) {
      header.classList.remove('is-menu-open');
      header.querySelector('[data-public-menu]')?.setAttribute('aria-expanded', 'false');
    }
  });
}
