import { APP_CONFIG } from '../../config/app.config.js';
import { dataService } from '../../services/data.service.js';


function sidebar({
  navigation,
  activePath,
  admin,
  currentUser
}) {


  currentUser = currentUser || {
    name: "Peserta BISAM",
    status: "Member",
    initials: "PB",
    points: 0
  };


  const profileName =
    admin
    ? "Administrator"
    : currentUser.name;


  const profileStatus =
    admin
    ? "Super Admin"
    : currentUser.status;


  const initials =
    admin
    ? "AD"
    : currentUser.initials;



return `

<aside id="app-sidebar" class="sidebar ${admin ? 'sidebar--admin' : ''}">


<a 
class="sidebar__logo"
href="${admin ? '#/admin/dashboard' : '#/dashboard'}">

<img 
src="${APP_CONFIG.logoUrl}"
alt="${APP_CONFIG.fullName}" />

</a>



<div class="sidebar__label">

${admin ? "Administrasi" : "Menu Peserta"}

</div>




<nav class="sidebar__nav">

${navigation.map((item)=>`

<a
class="sidebar__link ${activePath === item.path ? 'is-active':''}"
href="#${item.path}">


<span class="sidebar__icon">

${item.icon}

</span>


<span>

${item.label}

</span>


</a>


`).join('')}


</nav>





<div class="sidebar__footer">


<button
class="sidebar__logout"
type="button"
data-action="logout">

↪
<span>
Keluar
</span>

</button>




${
admin
?
''
:
`

<a
href="#/profile"
class="sidebar__profile">


<div class="avatar">

${initials}

</div>


<div>

<strong>

${profileName}

</strong>


<small>

${profileStatus}

</small>


</div>


</a>

`
}


</div>


</aside>


`;

}





export async function dashboardLayout({

content,

navigation,

activePath,

admin=false

}){


const activeItem =
navigation.find(
(item)=>item.path === activePath
);



// Data peserta asli (nama sesuai pemilik akun, poin dari hasil
// latihan/ujian yang sudah dikerjakan). Admin belum punya profil
// terpisah sehingga tetap memakai label statis "Administrator".
const currentUser =
admin
? { name:"Peserta BISAM", initials:"PB", points:0 }
: await dataService.getCurrentUser();




return `


<div class="dashboard-layout ${admin ? 'dashboard-layout--admin':''}">



${sidebar({
navigation,
activePath,
admin,
currentUser
})}





<div class="sidebar-overlay" data-action="close-menu"></div>


<section class="dashboard-main">



<header class="dashboard-topbar">

<button
class="topbar-menu"
type="button"
data-action="toggle-menu"
aria-label="Buka menu"
aria-controls="app-sidebar">

<span></span><span></span><span></span>

</button>

<div class="dashboard-topbar__title">


<strong>

${
admin
?
(activeItem?.label ?? "Admin Panel")
:
"BISAM Learning"
}

</strong>



<small>

${
admin
?
"Bintang Samudra • Panel Administrasi"
:
"Portal peserta"
}

</small>


</div>






<div class="dashboard-topbar__actions">



${
admin

?

`

<span class="environment-chip">

<span></span>

Admin

</span>


<a
class="icon-button"
href="#/admin/settings">

⚙

</a>


`

:

`

<a
href="#/profile"
class="topbar-user">


<span class="topbar-user__avatar">

${currentUser.initials}

</span>



<div>


<span class="topbar-user__name">

${currentUser.name}

</span>



<span class="topbar-user__points">

${currentUser.points} poin

</span>



</div>


</a>


`

}



</div>




</header>





<main class="dashboard-content">

${content}

</main>




</section>








</div>


`;

}