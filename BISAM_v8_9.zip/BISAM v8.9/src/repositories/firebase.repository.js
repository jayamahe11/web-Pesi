/**
 * Adapter Firebase BISAM (Firestore).
 * ------------------------------------------------------------------
 * Adapter ini terhubung LANGSUNG ke Firestore memakai project yang sudah
 * dikonfigurasi di `../firebase/config.js`. Tidak perlu memanggil
 * `firebaseRepository.configure(...)` secara manual lagi — begitu provider
 * di `../config/data-source.config.js` diubah menjadi 'firebase', adapter ini
 * otomatis dipakai oleh `dataService`.
 *
 * Collection yang dibaca (lihat `../firebase/README.md` untuk skema lengkap):
 *   modules            -> katalog modul
 *   questions          -> soal (tanpa field jawaban/pembahasan)
 *   answerKeys         -> jawaban + pembahasan per id soal (idealnya hanya
 *                         boleh dibaca akun admin lewat security rules)
 *   rankings           -> papan peringkat
 *   announcements      -> pengumuman
 *   schedules          -> jadwal
 *
 * CATATAN KEAMANAN:
 * Karena penilaian jawaban saat ini dilakukan di browser (client-side),
 * `answerKeys` ikut diambil dan digabung ke `questions` supaya UI kuis bisa
 * langsung memberi feedback benar/salah. Untuk ujian yang sifatnya resmi/
 * berisiko tinggi, pindahkan validasi jawaban ke Cloud Function/backend agar
 * kunci jawaban tidak pernah sampai ke browser peserta. Atur juga
 * `firestore.rules` (lihat `firestore.rules.example`) supaya collection
 * `answerKeys` hanya bisa dibaca oleh akun admin.
 *
 * Menulis data (CRUD admin, hasil kuis, dsb) BELUM otomatis tersinkron ke
 * Firestore pada versi ini — `adminService`/`memberService` masih memakai
 * penyimpanan lokal (in-memory/localStorage) untuk operasi tulis walaupun
 * provider = 'firebase'. `recordQuizAttempt()` di bawah disediakan sebagai
 * titik awal untuk menyambungkan penulisan hasil kuis ke collection
 * `quizAttempts`; panggil fungsi ini dari `memberService.recordResult()`
 * ketika siap.
 */

import { db } from '../firebase/config.js';

let firestoreApiPromise = null;

function loadFirestoreApi() {
  if (!firestoreApiPromise) {
    firestoreApiPromise = import(
      'https://www.gstatic.com/firebasejs/12.17.1/firebase-firestore.js'
    );
  }
  return firestoreApiPromise;
}

async function fetchCollection(name) {
  const { collection, getDocs } = await loadFirestoreApi();
  const snapshot = await getDocs(collection(db, name));
  return snapshot.docs.map((docSnap) => ({ id: docSnap.id, ...docSnap.data() }));
}

function coerceId(value) {
  const asNumber = Number(value);
  return Number.isFinite(asNumber) && String(asNumber) === String(value) ? asNumber : value;
}

async function loadQuestionsWithAnswers() {
  const [publicQuestions, answerKeys] = await Promise.all([
    fetchCollection('questions'),
    fetchCollection('answerKeys'),
  ]);

  const keyById = new Map(
    answerKeys.map((key) => [String(coerceId(key.id)), key])
  );

  return publicQuestions.map((question) => {
    const id = coerceId(question.id);
    const key = keyById.get(String(id)) ?? {};
    return {
      ...question,
      id,
      answer: key.answer ?? null,
      explanation: key.explanation ?? '',
    };
  });
}

async function loadOptionalCollection(name) {
  try {
    return await fetchCollection(name);
  } catch (error) {
    console.warn(`[firebaseRepository] gagal memuat collection "${name}":`, error?.message ?? error);
    return [];
  }
}

function toIso(value) {
  if (!value) return null;
  if (typeof value.toDate === 'function') return value.toDate().toISOString();
  return value;
}

function mapUserToParticipant(user) {
  const name = user.nama || user.name || user.displayName || user.email || 'Peserta';

  return {
    id: user.id,
    name,
    email: user.email || '',
    whatsapp: user.whatsapp || '',
    type: user.type || '-',
    institution: user.institution || '-',
    status: user.status === 'Nonaktif' ? 'Nonaktif' : 'Aktif',
    registeredAt: toIso(user.createdAt),
    loginMethod: user.foto ? 'Google' : 'Email',
  };
}

let manualAdapter = null;

export const firebaseRepository = {
  /**
   * Opsional: pasang adapter custom (mis. untuk testing atau backend lain).
   * Jika tidak dipanggil, adapter default di atas (Firestore langsung) yang
   * dipakai.
   */
  configure(adapter) {
    if (typeof adapter === 'function') {
      manualAdapter = { loadAppData: adapter };
      return;
    }

    if (!adapter || typeof adapter.loadAppData !== 'function') {
      throw new TypeError('Firebase adapter wajib memiliki function async loadAppData().');
    }

    manualAdapter = adapter;
  },

  async loadAppData() {
    if (manualAdapter) {
      return manualAdapter.loadAppData();
    }

    const [
      modules, questions, ranking, announcements, schedules,
      customModules, customQuestions,
    ] = await Promise.all([
      loadOptionalCollection('modules'),
      loadQuestionsWithAnswers(),
      loadOptionalCollection('rankings'),
      loadOptionalCollection('announcements'),
      loadOptionalCollection('schedules'),
      // Modul & soal buatan admin (lihat Admin > Kelola Modul / Kelola Soal).
      loadOptionalCollection('customModules'),
      loadOptionalCollection('customQuestions'),
    ]);

    return {
      currentUser: null,
      modules: modules.map((m) => ({ ...m, id: m.id })),
      questions,
      ranking,
      history: [],
      participants: [],
      schedules,
      announcements,
      customModules,
      customQuestions,
    };
  },

  async mutate(operation, ...args) {
    if (manualAdapter) {
      const handler = manualAdapter[operation];
      if (typeof handler !== 'function') {
        throw new Error(`Firebase adapter belum mengimplementasikan ${operation}().`);
      }
      return handler(...args);
    }

    throw new Error(
      `Operasi tulis "${operation}" belum diimplementasikan untuk provider Firebase langsung. ` +
      'Gunakan firebaseRepository.configure(adapter) untuk memasang implementasi tulis custom, ' +
      'atau lakukan penulisan lewat Cloud Function/backend terpisah.'
    );
  },

  /**
   * Helper opsional untuk menyimpan hasil kuis/pauli ke Firestore.
   * Belum dipanggil otomatis oleh memberService — sambungkan manual saat
   * siap memindahkan penyimpanan hasil dari localStorage ke Firestore.
   */
  async recordQuizAttempt(attempt) {
    const { doc, setDoc, serverTimestamp } = await loadFirestoreApi();
    // Id dokumen deterministik (uid + attemptKey) supaya pemanggilan ganda
    // untuk pengerjaan yang sama tidak membuat catatan dobel.
    const id = attempt.attemptKey
      ? `${attempt.userId}_${attempt.attemptKey}`
      : null;

    if (!id) {
      const { collection, addDoc } = await loadFirestoreApi();
      return addDoc(collection(db, 'quizAttempts'), {
        ...attempt,
        createdAt: serverTimestamp(),
      });
    }

    return setDoc(doc(db, 'quizAttempts', id), {
      ...attempt,
      createdAt: serverTimestamp(),
    });
  },

  async recordPauliAttempt(attempt) {
    const { doc, setDoc, serverTimestamp } = await loadFirestoreApi();
    const id = attempt.attemptKey
      ? `${attempt.userId}_${attempt.attemptKey}`
      : null;

    if (!id) {
      const { collection, addDoc } = await loadFirestoreApi();
      return addDoc(collection(db, 'pauliAttempts'), {
        ...attempt,
        createdAt: serverTimestamp(),
      });
    }

    return setDoc(doc(db, 'pauliAttempts', id), {
      ...attempt,
      createdAt: serverTimestamp(),
    });
  },

  /**
   * Modul & soal buatan admin disimpan di Firestore (collection
   * `customModules` dan `customQuestions`) supaya tampil di semua peserta,
   * bukan hanya di browser admin. Modul bawaan aplikasi tidak berubah.
   */
  async saveCustomModule(item) {
    const { doc, setDoc, serverTimestamp } = await loadFirestoreApi();
    const { id, custom, ...data } = item;

    await setDoc(
      doc(db, 'customModules', String(id)),
      { ...data, updatedAt: serverTimestamp() },
      { merge: true }
    );
  },

  async deleteCustomModule(id) {
    const {
      collection, doc, getDocs, query, where, writeBatch,
    } = await loadFirestoreApi();

    // Hapus juga semua soal milik modul ini (per 400 dokumen).
    const snap = await getDocs(
      query(collection(db, 'customQuestions'), where('moduleId', '==', String(id)))
    );

    for (let i = 0; i < snap.docs.length; i += 400) {
      const batch = writeBatch(db);
      snap.docs.slice(i, i + 400).forEach((d) => batch.delete(d.ref));
      await batch.commit();
    }

    const { deleteDoc } = await loadFirestoreApi();
    await deleteDoc(doc(db, 'customModules', String(id)));
  },

  async saveCustomQuestion(item) {
    const { doc, setDoc, serverTimestamp } = await loadFirestoreApi();
    const { id, custom, ...data } = item;

    await setDoc(
      doc(db, 'customQuestions', String(id)),
      { ...data, updatedAt: serverTimestamp() },
      { merge: true }
    );
  },

  async deleteCustomQuestion(id) {
    const { doc, deleteDoc } = await loadFirestoreApi();
    await deleteDoc(doc(db, 'customQuestions', String(id)));

    // Bersihkan gambar soal (kalau ada). Gagal di sini tidak masalah.
    try {
      await deleteDoc(doc(db, 'questionImages', String(id)));
    } catch (error) {
      console.warn('[firebaseRepository] gambar soal tidak terhapus:', error?.message ?? error);
    }
  },

  /**
   * Gambar soal disimpan terpisah di collection `questionImages/{id}`
   * (data URL hasil kompres) supaya daftar soal yang dimuat saat aplikasi
   * dibuka tetap ringan. Gambar baru diambil saat soal ditampilkan.
   */
  async saveQuestionImage(id, dataUrl) {
    const { doc, setDoc, serverTimestamp } = await loadFirestoreApi();
    await setDoc(doc(db, 'questionImages', String(id)), {
      data: dataUrl,
      updatedAt: serverTimestamp(),
    });
  },

  async getQuestionImage(id) {
    const { doc, getDoc } = await loadFirestoreApi();
    const snap = await getDoc(doc(db, 'questionImages', String(id)));
    return snap.exists() ? (snap.data().data || null) : null;
  },

  async deleteQuestionImage(id) {
    const { doc, deleteDoc } = await loadFirestoreApi();
    await deleteDoc(doc(db, 'questionImages', String(id)));
  },

  /**
   * Daftar peserta = semua akun di collection `users` (yang mendaftar lewat
   * email/password MAUPUN login Google), kecuali akun admin. Sengaja
   * melempar error kalau gagal supaya halaman admin bisa menampilkan
   * penyebabnya (biasanya rules Firestore belum di-publish).
   */
  async getParticipants() {
    const users = await fetchCollection('users');

    return users
      .filter((user) => user.role !== 'admin')
      .map(mapUserToParticipant)
      .sort((a, b) => String(b.registeredAt || '').localeCompare(String(a.registeredAt || '')));
  },

  async createParticipant(payload) {
    const { collection, addDoc, serverTimestamp } = await loadFirestoreApi();

    return addDoc(collection(db, 'users'), {
      nama: payload.name,
      email: payload.email || '',
      whatsapp: payload.whatsapp || '',
      type: payload.type || 'BINJAS',
      institution: payload.institution || '-',
      status: payload.status || 'Aktif',
      role: 'user',
      addedByAdmin: true,
      createdAt: serverTimestamp(),
    });
  },

  async updateParticipant(id, payload) {
    const { doc, setDoc } = await loadFirestoreApi();

    // Sengaja TIDAK menulis field `name`/`role`: nama memakai field `nama`
    // (sama seperti saat registrasi) dan role tidak boleh berubah dari sini.
    return setDoc(
      doc(db, 'users', String(id)),
      {
        nama: payload.name,
        email: payload.email || '',
        whatsapp: payload.whatsapp || '',
        type: payload.type || '-',
        institution: payload.institution || '-',
        status: payload.status || 'Aktif',
      },
      { merge: true }
    );
  },

  async deleteParticipant(id) {
    const { doc, deleteDoc } = await loadFirestoreApi();
    return deleteDoc(doc(db, 'users', String(id)));
  },

  /**
   * Admin: hapus satu pengerjaan (mis. peserta mengulang-ulang modul yang
   * sama). Poin ranking memakai aturan "poin terbaik per modul", jadi
   * setelah pengerjaan dihapus poin modul itu dihitung ulang dari
   * pengerjaan peserta yang TERSISA (bukan sekadar dikurangi), lalu total
   * poin peserta disesuaikan. Ringkasan di riwayat ranking ikut dihapus.
   *
   * Pengerjaan Pauli & Kraepelin tidak memengaruhi poin ranking.
   *
   * Butuh akun admin (lihat firestore.rules.example).
   */
  async deleteAttempt(attempt) {
    if (!attempt?.id || !attempt.sourceCollection) {
      throw new Error('Data pengerjaan tidak lengkap.');
    }

    const {
      collection, doc, getDocs, query, where, deleteDoc, setDoc, serverTimestamp,
    } = await loadFirestoreApi();

    const uid = attempt.userId || null;
    const isQuiz = attempt.sourceCollection === 'quizAttempts';

    // Cari ringkasan di rankings/{uid}/attempts. Data baru id-nya = attemptKey;
    // data lama dicocokkan lewat modul + tipe + skor + poin.
    let summaryRef = null;

    if (uid && isQuiz) {
      try {
        const snap = await getDocs(collection(db, 'rankings', uid, 'attempts'));
        const docs = snap.docs;

        let found = attempt.attemptKey
          ? docs.find((d) => d.id === attempt.attemptKey || d.data().attemptKey === attempt.attemptKey)
          : null;

        if (!found) {
          found = docs.find((d) => {
            const x = d.data();
            return (
              !x.attemptKey &&
              x.moduleTitle === attempt.moduleTitle &&
              (x.quizType || 'latihan') === (attempt.quizType || 'latihan') &&
              Number(x.score || 0) === Number(attempt.score || 0) &&
              Number(x.points || 0) === Number(attempt.points || 0)
            );
          });
        }

        summaryRef = found?.ref ?? null;
      } catch (error) {
        console.warn('[firebaseRepository] ringkasan ranking tidak terbaca:', error?.message ?? error);
      }
    }

    await deleteDoc(doc(db, attempt.sourceCollection, attempt.id));

    if (summaryRef) {
      await deleteDoc(summaryRef);
    }

    if (!uid || !isQuiz) return;

    // Hitung ulang poin terbaik modul ini dari pengerjaan yang masih ada.
    const remaining = await getDocs(
      query(collection(db, 'quizAttempts'), where('userId', '==', uid))
    );

    const best = {};
    remaining.docs.forEach((d) => {
      const x = d.data();
      if (!x.moduleId) return;
      best[x.moduleId] = Math.max(best[x.moduleId] ?? 0, Number(x.points) || 0);
    });

    const total = Object.values(best).reduce((sum, v) => sum + v, 0);

    await setDoc(
      doc(db, 'rankings', uid),
      {
        uid,
        moduleBest: best,
        points: total,
        updatedAt: serverTimestamp(),
      },
      { mergeFields: ['uid', 'moduleBest', 'points', 'updatedAt'] }
    );
  },

  /**
   * Dipakai halaman Admin > Laporan & Hasil: mengambil SEMUA riwayat
   * pengerjaan (quiz latihan/ujian + Pauli & Kraepelin) dari SEMUA peserta,
   * lengkap dengan nama peserta yang mengerjakan, supaya admin bisa melihat
   * "siapa mengerjakan modul apa, nilai berapa" dan membuka rincian
   * jawaban per soal.
   *
   * Butuh akun yang sedang login berstatus admin sesuai
   * `firestore.rules.example` (role di dokumen users/{uid} == 'admin'),
   * kalau tidak Firestore akan menolak (permission-denied) dan fungsi ini
   * mengembalikan array kosong.
   */
  async getAllAttempts() {
    const [quizAttempts, pauliAttempts] = await Promise.all([
      loadOptionalCollection('quizAttempts'),
      loadOptionalCollection('pauliAttempts'),
    ]);

    const tagged = [
      ...quizAttempts.map((item) => ({ ...item, sourceCollection: 'quizAttempts' })),
      ...pauliAttempts.map((item) => ({ ...item, sourceCollection: 'pauliAttempts' })),
    ];

    return tagged.sort((a, b) => {
      const timeA = a.completedAt || '';
      const timeB = b.completedAt || '';
      return String(timeB).localeCompare(String(timeA));
    });
  },
};
