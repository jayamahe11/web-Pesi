import {
  announcements,
  currentUser,
  history,
  modules,
  participants,
  questions,
  ranking,
  schedules,
} from '../data/mock-data.js';
import { CUSTOM_MODULES, CUSTOM_QUESTIONS } from '../data/questions/custom.js';

/**
 * Repository lokal untuk development/prototype.
 * Bentuk data yang dikembalikan harus sama dengan repository Firebase.
 */
export const mockRepository = {
  async loadAppData() {
    return {
      currentUser,
      modules,
      questions,
      ranking,
      history,
      participants,
      schedules,
      announcements,
      // Soal & modul manual yang tersimpan sebagai kode (src/data/questions/custom.js).
      customModules: CUSTOM_MODULES.map((m) => ({ ...m })),
      customQuestions: CUSTOM_QUESTIONS.map((q) => ({ ...q, hasImage: false })),
    };
  },
};
