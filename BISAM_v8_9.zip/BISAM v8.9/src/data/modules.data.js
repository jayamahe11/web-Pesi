/**
 * MODULES.DATA.JS
 * ------------------------------------------------------------------
 * Sumber tunggal (single source of truth) untuk katalog modul BISAM.
 * File ini dipakai oleh:
 *  - services/admin.service.js  (katalog modul untuk store/admin panel)
 *  - data/mock-data.js          (katalog modul untuk provider "mock")
 *  - firebase/seed/modules.json (harus disinkronkan manual saat modul berubah)
 *
 * Menambah modul baru cukup menambah satu object di array MODULES.
 */

export const MODULES = [
  {
    id: 'logika',
    title: 'Logika Dasar',
    icon: '🧠',
    description: 'Silogisme dan penalaran logis dasar.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'numerik',
    title: 'Numerik Dasar',
    icon: '🔢',
    description: 'Hitungan, persentase, rasio, dan aritmatika dasar.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'verbal',
    title: 'Verbal',
    icon: '📖',
    description: 'Kemampuan memahami dan menggunakan bahasa.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'sinonim',
    title: 'Sinonim & Antonim',
    icon: '🔤',
    description: 'Persamaan dan lawan kata dalam Bahasa Indonesia.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'analogi',
    title: 'Analogi Kata',
    icon: '🔗',
    description: 'Hubungan makna antar pasangan kata.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'deret',
    title: 'Deret Angka',
    icon: '🔢',
    description: 'Pola dan kelanjutan deret angka.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'matematika',
    title: 'Matematika Dasar',
    icon: '➗',
    description: 'Aritmatika dan aljabar dasar.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'analitis',
    title: 'Penalaran Analitis',
    icon: '🧩',
    description: 'Penalaran berbasis informasi dan hubungan antar pernyataan.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'ketelitian',
    title: 'Tes Ketelitian (Pencerminan Gambar)',
    icon: '🪞',
    description: 'Latihan menentukan hasil pencerminan objek dari gambar.',
    engine: 'quiz',
    itemCountLabel: '25 soal',
    typeLabel: 'Pilihan gambar',
    durationMinutes: 20,
    active: true,
  },
  {
    id: 'spasial',
    title: 'Spasial',
    icon: '📐',
    description: 'Kemampuan membayangkan bentuk dan ruang.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'konsentrasi',
    title: 'Kecepatan Konsentrasi',
    icon: '⚡',
    description: 'Ketelitian dan kecepatan fokus dalam waktu singkat.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'kepribadian',
    title: 'Kepribadian Kerja',
    icon: '🎯',
    description: 'Skala kepribadian terkait etos dan sikap kerja.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Skala sikap',
    durationMinutes: 30,
    active: true,
  },
  {
    id: 'ingatan-verbal',
    title: 'Ingatan Verbal',
    icon: '💭',
    description: 'Mengingat kelompok kata (kota, bunga, benda, binatang) dalam waktu singkat.',
    engine: 'quiz',
    itemCountLabel: '4 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 10,
    active: true,
  },
  {
    id: 'pauli-kraepelin',
    title: 'Pauli & Kraepelin',
    icon: '🔢',
    description: 'Penjumlahan angka berdekatan untuk melatih kecepatan, ketelitian, kestabilan, dan daya tahan.',
    engine: 'pauli-kraepelin',
    itemCountLabel: 'Tes waktu',
    typeLabel: 'Interaktif',
    durationMinutes: 5,
    active: true,
  },
  {
    id: 'tiu',
    title: 'TIU - Tes Intelegensia Umum',
    icon: '🧠',
    description: '50 soal kemampuan numerik, verbal, logika, analogi, dan penalaran umum.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 50,
    active: true,
  },
  {
    id: 'twk',
    title: 'TWK - Tes Wawasan Kebangsaan',
    icon: '🇮🇩',
    description: '50 soal wawasan kebangsaan, Pancasila, UUD 1945, sejarah, dan pengetahuan kewarganegaraan.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 50,
    active: true,
  },
  {
    id: 'tkd',
    title: 'TKD - Tes Kompetensi Dasar',
    icon: '📚',
    description: '50 soal kompetensi dasar yang mencakup pengetahuan umum, bahasa, matematika, dan logika.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 50,
    active: true,
  },
  {
    id: 'twk2',
    title: 'TWK#2',
    icon: '🏛️',
    description: 'TWK#2 (level sulit): 50 soal wawasan kebangsaan, Pancasila, pasal-pasal UUD NRI 1945, sejarah, dan ketatanegaraan.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 50,
    active: true,
  },
  {
    id: 'tiu2',
    title: 'TIU#2',
    icon: '🧩',
    description: 'TIU#2 (level sulit): 50 soal deret, soal cerita, logika, penalaran analitis, dan verbal.',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Pilihan ganda',
    durationMinutes: 60,
    active: true,
  },
  {
    id: 'tkp2',
    title: 'TKP#2',
    icon: '🤝',
    description: 'TKP#2 (level sulit): 50 soal karakteristik pribadi berbasis situasi kerja (pelayanan publik, jejaring kerja, sosial budaya, TIK, profesionalisme, anti radikalisme).',
    engine: 'quiz',
    itemCountLabel: '50 soal',
    typeLabel: 'Situasional',
    durationMinutes: 50,
    active: true,
  },
];

export const PRACTICE_MODULE_IDS = [
  'logika', 'numerik', 'verbal', 'sinonim', 'analogi', 'deret',
  'matematika', 'analitis', 'ketelitian', 'spasial', 'konsentrasi',
  'kepribadian', 'ingatan-verbal', 'pauli-kraepelin',
];

export const EXAM_MODULE_IDS = ['tiu', 'twk', 'tkd', 'twk2', 'tiu2', 'tkp2'];


/**
 * Jenis modul: 'latihan' (modul belajar) atau 'ujian'.
 * Modul bawaan ditentukan lewat daftar id di atas; modul buatan admin
 * membawa field `category` sendiri.
 */
export function moduleCategory(module) {
  if (module?.category === 'ujian' || module?.category === 'latihan') {
    return module.category;
  }
  return EXAM_MODULE_IDS.includes(module?.id) ? 'ujian' : 'latihan';
}
