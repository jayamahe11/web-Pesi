/**
 * QUESTIONS.DATA.JS
 * ------------------------------------------------------------------
 * Aggregator tunggal seluruh bank soal quiz BISAM.
 * Menggabungkan semua file per-modul di folder ./questions/*.js
 * menjadi satu array QUESTIONS yang konsisten (schema sama untuk semua modul):
 *
 *   { id, moduleId, category, question, options[], answer (huruf A-E), explanation, image? }
 *
 * Menambah modul baru: buat file baru di ./questions/<nama>.js lalu import
 * + gabungkan di bawah ini.
 */

import { ANALITIS } from './questions/analitis.js';
import { ANALOGI } from './questions/analogi.js';
import { DERET } from './questions/deret.js';
import { INGATAN_VERBAL } from './questions/ingatan-verbal.js';
import { KEPRIBADIAN } from './questions/kepribadian.js';
import { KETELITIAN } from './questions/ketelitian.js';
import { KONSENTRASI } from './questions/konsentrasi.js';
import { LOGIKA } from './questions/logika.js';
import { MATEMATIKA } from './questions/matematika.js';
import { NUMERIK } from './questions/numerik.js';
import { SINONIM } from './questions/sinonim.js';
import { SPASIAL } from './questions/spasial.js';
import { VERBAL } from './questions/verbal.js';
import { TIU } from './questions/tiu.js';
import { TWK } from './questions/twk.js';
import { TKD } from './questions/tkd.js';
import { TWK2 } from './questions/twk2.js';
import { TIU2 } from './questions/tiu2.js';
import { TKP2 } from './questions/tkp2.js';

export const QUESTIONS = [
  ...LOGIKA,
  ...NUMERIK,
  ...VERBAL,
  ...SINONIM,
  ...ANALOGI,
  ...DERET,
  ...MATEMATIKA,
  ...ANALITIS,
  ...KETELITIAN,
  ...SPASIAL,
  ...KONSENTRASI,
  ...KEPRIBADIAN,
  ...INGATAN_VERBAL,
  ...TIU,
  ...TWK,
  ...TKD,
  ...TWK2,
  ...TIU2,
  ...TKP2,
];

/**
 * Revisi bank soal bawaan. Ubah nilainya setiap kali soal di modul-modul
 * REPLACED_MODULE_IDS diganti total, supaya browser/Firestore yang masih
 * menyimpan soal lama otomatis memakai soal terbaru dari kode ini.
 */
export const QUESTION_BANK_REVISION = 'hard-2026-10';
export const REPLACED_MODULE_IDS = [
  'logika', 'numerik', 'verbal', 'sinonim', 'analogi', 'deret',
  'matematika', 'analitis', 'spasial', 'konsentrasi', 'kepribadian',
];
