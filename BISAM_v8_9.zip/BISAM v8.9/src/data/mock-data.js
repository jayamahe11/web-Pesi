/**
 * DATA LOKAL / MOCK
 * --------------------------------------------
 * Selama backend belum terhubung, seluruh data contoh berada di file ini.
 * Katalog modul dan bank soal DIAMBIL dari sumber tunggal:
 *   - ./modules.data.js    (MODULES)
 *   - ./questions.data.js  (QUESTIONS, hasil gabungan ./questions/*.js)
 * supaya provider "mock" dan provider "firebase" (lewat seed/*.json) selalu
 * konsisten dan tidak drift satu sama lain.
 *
 * Data member/aktivitas (ranking, history, participants, schedules,
 * announcements) tetap dibuat kosong untuk fresh install.
 */

import { MODULES } from './modules.data.js';
import { QUESTIONS } from './questions.data.js';

export const currentUser = {
  id: 'local-member',
  name: 'Member Baru',
  initials: 'MB',
  email: '',
  whatsapp: '',
  points: 0,
  rank: null,
  status: 'Member Baru',
};

/**
 * Katalog modul latihan & ujian.
 * Sumber: ./modules.data.js — tambah modul baru di sana, bukan di sini.
 */
export const modules = MODULES;

/**
 * Bank soal seluruh modul.
 * Sumber: ./questions.data.js — tambah soal baru lewat ./questions/<modul>.js.
 */
export const questions = QUESTIONS;

export const ranking = [];

export const history = [];

export const participants = [];

export const schedules = [];

export const announcements = [];
