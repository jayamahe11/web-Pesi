export const LOGIKA = [
  {
    "id": 1001,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Sebagian guru adalah relawan. Tidak ada penjahit yang merupakan relawan. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian guru bukan penjahit",
      "Semua penjahit adalah guru",
      "Semua guru adalah penjahit",
      "Sebagian penjahit adalah guru",
      "Tidak ada penjahit yang merupakan guru"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1002,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Tidak ada penjahit yang merupakan pegawai. Sebagian pegawai adalah dokter. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian penjahit adalah dokter",
      "Semua penjahit adalah dokter",
      "Sebagian dokter bukan penjahit",
      "Semua dokter adalah penjahit",
      "Sebagian penjahit bukan dokter"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1003,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Semua penerjemah adalah dokter. Tidak ada musisi yang merupakan dokter. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Semua penerjemah adalah musisi",
      "Tidak ada penerjemah yang merupakan musisi",
      "Sebagian penerjemah adalah musisi",
      "Sebagian penerjemah bukan musisi",
      "Sebagian musisi bukan penerjemah"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1004,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Tidak ada dokter yang merupakan ilmuwan. Sebagian pemain catur adalah dokter. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Semua pemain catur adalah ilmuwan",
      "Tidak ada pemain catur yang merupakan ilmuwan",
      "Semua ilmuwan adalah pemain catur",
      "Sebagian ilmuwan bukan pemain catur",
      "Sebagian pemain catur bukan ilmuwan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1005,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Tidak ada arsitek yang merupakan dokter. Semua ilmuwan adalah dokter. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Semua arsitek adalah ilmuwan",
      "Sebagian ilmuwan bukan arsitek",
      "Sebagian arsitek bukan ilmuwan",
      "Semua ilmuwan adalah arsitek",
      "Tidak ada ilmuwan yang merupakan arsitek"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1006,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Semua dokter adalah pengusaha. Tidak ada pengusaha yang merupakan pemain gitar. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian pemain gitar bukan dokter",
      "Semua pemain gitar adalah dokter",
      "Sebagian dokter bukan pemain gitar",
      "Semua dokter adalah pemain gitar",
      "Tidak ada dokter yang merupakan pemain gitar"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1007,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Semua pelukis adalah relawan. Semua relawan adalah pengamat. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian pengamat adalah pelukis",
      "Sebagian pengamat bukan pelukis",
      "Semua pelukis adalah pengamat",
      "Sebagian pelukis bukan pengamat",
      "Semua pengamat adalah pelukis"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1008,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Semua penjahit adalah perenang. Tidak ada atlet yang merupakan perenang. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian atlet bukan penjahit",
      "Tidak ada penjahit yang merupakan atlet",
      "Semua atlet adalah penjahit",
      "Sebagian penjahit adalah atlet",
      "Semua penjahit adalah atlet"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1009,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Sebagian penerjemah adalah pengusaha. Tidak ada mahasiswa yang merupakan penerjemah. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian mahasiswa adalah pengusaha",
      "Sebagian mahasiswa bukan pengusaha",
      "Semua pengusaha adalah mahasiswa",
      "Sebagian pengusaha bukan mahasiswa",
      "Semua mahasiswa adalah pengusaha"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1010,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Tidak ada dokter yang merupakan ilmuwan. Sebagian pendaki adalah dokter. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Tidak ada pendaki yang merupakan ilmuwan",
      "Semua pendaki adalah ilmuwan",
      "Sebagian pendaki adalah ilmuwan",
      "Sebagian ilmuwan bukan pendaki",
      "Sebagian pendaki bukan ilmuwan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1011,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Semua relawan adalah pegawai. Tidak ada pegawai yang merupakan penjahit. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Tidak ada relawan yang merupakan penjahit",
      "Sebagian penjahit bukan relawan",
      "Semua penjahit adalah relawan",
      "Semua relawan adalah penjahit",
      "Sebagian relawan bukan penjahit"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1012,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Sebagian penyanyi adalah pegawai. Tidak ada relawan yang merupakan penyanyi. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Semua relawan adalah pegawai",
      "Sebagian pegawai bukan relawan",
      "Sebagian relawan bukan pegawai",
      "Sebagian pegawai adalah relawan",
      "Semua pegawai adalah relawan"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1013,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Tidak ada pembaca yang merupakan mahasiswa. Sebagian mahasiswa adalah musisi. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Tidak ada musisi yang merupakan pembaca",
      "Semua musisi adalah pembaca",
      "Sebagian musisi bukan pembaca",
      "Semua pembaca adalah musisi",
      "Sebagian musisi adalah pembaca"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1014,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Sebagian musisi adalah guru. Tidak ada musisi yang merupakan pengamat. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian guru adalah pengamat",
      "Semua pengamat adalah guru",
      "Sebagian pengamat bukan guru",
      "Sebagian guru bukan pengamat",
      "Semua guru adalah pengamat"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hanya pernyataan ini yang berlaku pada SEMUA kemungkinan diagram Venn yang memenuhi kedua premis."
  },
  {
    "id": 1015,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Sebagian pegawai bukan mahasiswa. Tidak ada mahasiswa yang merupakan arsitek. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian arsitek adalah pegawai",
      "Sebagian pegawai bukan arsitek",
      "Tidak ada kesimpulan yang pasti benar",
      "Semua arsitek adalah pegawai",
      "Sebagian arsitek bukan pegawai"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pada diagram Venn yang memenuhi kedua premis, tidak satu pun pernyataan tentang hubungan kedua kelompok ujung selalu berlaku."
  },
  {
    "id": 1016,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Sebagian perenang adalah penjahit. Semua pemain catur adalah penjahit. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Tidak ada kesimpulan yang pasti benar",
      "Sebagian pemain catur adalah perenang",
      "Sebagian pemain catur bukan perenang",
      "Sebagian perenang bukan pemain catur",
      "Semua pemain catur adalah perenang"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pada diagram Venn yang memenuhi kedua premis, tidak satu pun pernyataan tentang hubungan kedua kelompok ujung selalu berlaku."
  },
  {
    "id": 1017,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Tidak ada pemain gitar yang merupakan atlet. Sebagian arsitek bukan atlet. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Tidak ada kesimpulan yang pasti benar",
      "Semua arsitek adalah pemain gitar",
      "Sebagian pemain gitar bukan arsitek",
      "Sebagian arsitek bukan pemain gitar",
      "Semua pemain gitar adalah arsitek"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pada diagram Venn yang memenuhi kedua premis, tidak satu pun pernyataan tentang hubungan kedua kelompok ujung selalu berlaku."
  },
  {
    "id": 1018,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Sebagian atlet adalah pelukis. Sebagian atlet adalah penerjemah. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Sebagian pelukis bukan penerjemah",
      "Semua penerjemah adalah pelukis",
      "Tidak ada kesimpulan yang pasti benar",
      "Tidak ada pelukis yang merupakan penerjemah",
      "Semua pelukis adalah penerjemah"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pada diagram Venn yang memenuhi kedua premis, tidak satu pun pernyataan tentang hubungan kedua kelompok ujung selalu berlaku."
  },
  {
    "id": 1019,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Tidak mungkin peserta tidak hadir lengkap dan hujan tidak turun deras terjadi sekaligus. Diketahui bahwa hujan turun deras. Acara tidak dipindahkan jika dan hanya jika hujan tidak turun deras. Setidaknya salah satu benar: peserta tidak hadir lengkap, atau hujan turun deras. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Jalan tidak tergenang",
      "Acara tidak dipindahkan",
      "Acara dipindahkan",
      "Peserta hadir lengkap",
      "Peserta tidak hadir lengkap"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1020,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Setidaknya salah satu benar: peserta hadir lengkap, atau jalan tergenang. Setidaknya salah satu benar: hujan tidak turun deras, atau jalan tidak tergenang. Hujan turun deras jika dan hanya jika acara dipindahkan. Diketahui bahwa jalan tidak tergenang. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Peserta tidak hadir lengkap",
      "Acara dipindahkan",
      "Jalan tergenang",
      "Hujan tidak turun deras",
      "Peserta hadir lengkap"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1021,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Jika pegawai tidak dirumahkan, maka harga bahan baku tidak naik. Jika harga bahan baku tidak naik, maka laba perusahaan meningkat. Jika pegawai tidak dirumahkan, maka produksi dikurangi. Diketahui bahwa harga bahan baku naik. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Produksi dikurangi",
      "Laba perusahaan meningkat",
      "Harga bahan baku tidak naik",
      "Pegawai dirumahkan",
      "Pegawai tidak dirumahkan"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1022,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Tidak mungkin server tidak mengalami gangguan dan layanan daring tidak dihentikan terjadi sekaligus. Diketahui bahwa pelanggan tidak mengajukan keluhan. Jika pelanggan tidak mengajukan keluhan, maka server mengalami gangguan. Jika teknisi tidak dipanggil, maka layanan daring tidak dihentikan. Jika server tidak mengalami gangguan, maka layanan daring dihentikan. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Server mengalami gangguan",
      "Teknisi dipanggil",
      "Server tidak mengalami gangguan",
      "Teknisi tidak dipanggil",
      "Layanan daring tidak dihentikan"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1023,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Jika hujan turun deras, maka jalan tidak tergenang. Jika jalan tergenang, maka hujan turun deras. Tidak mungkin jalan tergenang dan acara tidak dipindahkan terjadi sekaligus. Jika jalan tergenang, maka peserta hadir lengkap. Diketahui bahwa peserta hadir lengkap. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Hujan tidak turun deras",
      "Jalan tergenang",
      "Acara tidak dipindahkan",
      "Jalan tidak tergenang",
      "Peserta tidak hadir lengkap"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1024,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Jika tim tidak bekerja lembur, maka anggaran mencukupi. Diketahui bahwa klien menyetujui laporan. Anggaran tidak mencukupi jika dan hanya jika proyek selesai tepat waktu. Jika tim tidak bekerja lembur, maka klien tidak menyetujui laporan. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Proyek tidak selesai tepat waktu",
      "Tim bekerja lembur",
      "Anggaran mencukupi",
      "Klien tidak menyetujui laporan",
      "Tim tidak bekerja lembur"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1025,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Acara dipindahkan jika dan hanya jika jalan tidak tergenang. Jika acara dipindahkan, maka peserta tidak hadir lengkap. Jika hujan turun deras, maka jalan tergenang. Diketahui bahwa acara tidak dipindahkan. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Hujan turun deras",
      "Peserta hadir lengkap",
      "Acara dipindahkan",
      "Jalan tidak tergenang",
      "Jalan tergenang"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1026,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Jika peserta hadir lengkap, maka jalan tergenang. Diketahui bahwa peserta tidak hadir lengkap. Setidaknya salah satu benar: peserta hadir lengkap, atau jalan tidak tergenang. Jika hujan turun deras, maka acara tidak dipindahkan. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Jalan tergenang",
      "Peserta hadir lengkap",
      "Acara dipindahkan",
      "Jalan tidak tergenang",
      "Hujan tidak turun deras"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1027,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Setidaknya salah satu benar: jalan tergenang, atau acara dipindahkan. Diketahui bahwa hujan turun deras. Setidaknya salah satu benar: jalan tidak tergenang, atau peserta tidak hadir lengkap. Hujan turun deras jika dan hanya jika acara dipindahkan. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Jalan tidak tergenang",
      "Acara dipindahkan",
      "Hujan tidak turun deras",
      "Acara tidak dipindahkan",
      "Jalan tergenang"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1028,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Perhatikan premis berikut. Jika pegawai tidak dirumahkan, maka harga bahan baku naik. Produksi tidak dikurangi jika dan hanya jika laba perusahaan meningkat. Diketahui bahwa laba perusahaan meningkat. Pegawai dirumahkan jika dan hanya jika harga bahan baku tidak naik. Kesimpulan yang PASTI benar adalah ...",
    "options": [
      "Pegawai tidak dirumahkan",
      "Produksi tidak dikurangi",
      "Harga bahan baku naik",
      "Produksi dikurangi",
      "Pegawai dirumahkan"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dengan menguji semua kemungkinan nilai kebenaran yang memenuhi seluruh premis, hanya pernyataan ini yang selalu benar."
  },
  {
    "id": 1029,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Eka jujur\"; Eka: \"Fajar dan Dika sama-sama jujur\"; Fajar: \"Tepat satu di antara Dika dan Eka yang jujur\"; Gita: \"Dika dan Eka sama-sama jujur\". Siapa saja yang jujur?",
    "options": [
      "Tidak ada",
      "Eka",
      "Dika dan Eka",
      "Dika dan Fajar",
      "Dika, Fajar dan Gita"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1030,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Fajar dan Gita sejenis (sama-sama jujur atau sama-sama berbohong)\"; Eka: \"Gita berbohong\"; Fajar: \"Dika berbohong\"; Gita: \"Dika jujur\". Siapa saja yang jujur?",
    "options": [
      "Dika dan Fajar",
      "Dika dan Eka",
      "Dika, Eka dan Gita",
      "Tidak ada",
      "Eka dan Fajar"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1031,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Gita dan Fajar sama-sama jujur\"; Eka: \"Gita jujur\"; Fajar: \"Eka berbohong\"; Gita: \"Tepat satu di antara Fajar dan Eka yang jujur\". Siapa saja yang jujur?",
    "options": [
      "Eka",
      "Dika dan Fajar",
      "Semua",
      "Eka dan Gita",
      "Dika"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1032,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Eka jujur\"; Eka: \"Fajar jujur\"; Fajar: \"Gita dan Eka sejenis (sama-sama jujur atau sama-sama berbohong)\"; Gita: \"Fajar berbohong\". Siapa saja yang jujur?",
    "options": [
      "Fajar dan Gita",
      "Dika, Eka dan Fajar",
      "Gita",
      "Dika dan Eka",
      "Dika, Eka dan Gita"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1033,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Gita jujur\"; Eka: \"Dika dan Fajar sama-sama jujur\"; Fajar: \"Eka berbohong\"; Gita: \"Tepat satu di antara Dika dan Eka yang jujur\". Siapa saja yang jujur?",
    "options": [
      "Fajar",
      "Dika dan Eka",
      "Dika dan Gita",
      "Dika, Eka dan Fajar",
      "Tidak ada"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1034,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Gita jujur\"; Eka: \"Tepat satu di antara Dika dan Gita yang jujur\"; Fajar: \"Gita berbohong\"; Gita: \"Fajar dan Dika sejenis (sama-sama jujur atau sama-sama berbohong)\". Siapa saja yang jujur?",
    "options": [
      "Gita",
      "Dika dan Gita",
      "Tidak ada",
      "Semua",
      "Fajar"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1035,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Eka dan Fajar sejenis (sama-sama jujur atau sama-sama berbohong)\"; Eka: \"Gita dan Fajar sama-sama jujur\"; Fajar: \"Tepat satu di antara Dika dan Gita yang jujur\"; Gita: \"Tepat satu di antara Dika dan Fajar yang jujur\". Siapa saja yang jujur?",
    "options": [
      "Dika",
      "Eka, Fajar dan Gita",
      "Tidak ada",
      "Fajar",
      "Dika dan Gita"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1036,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Empat orang masing-masing mengucapkan satu pernyataan. Orang jujur selalu benar dan pembohong selalu salah. Dika: \"Eka dan Fajar sama-sama jujur\"; Eka: \"Gita berbohong\"; Fajar: \"Gita dan Dika sama-sama jujur\"; Gita: \"Dika dan Eka sama-sama jujur\". Siapa saja yang jujur?",
    "options": [
      "Eka",
      "Eka dan Fajar",
      "Tidak ada",
      "Dika, Eka dan Fajar",
      "Dika dan Eka"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hanya satu pembagian jujur/pembohong yang konsisten dengan seluruh pernyataan."
  },
  {
    "id": 1037,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Bima, Dimas, Eka, Farhan, Gilang) berdiri dalam satu barisan lurus dari depan ke belakang. Bima berdiri di depan Ayu (tidak harus bersebelahan). Ayu berdiri di depan Farhan (tidak harus bersebelahan). Di antara Ayu dan Gilang terdapat tepat 3 orang. Ayu dan Farhan tidak berdiri bersebelahan. Siapa yang berdiri pada urutan ke-2?",
    "options": [
      "Ayu",
      "Farhan",
      "Eka",
      "Bima",
      "Gilang"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1038,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Citra, Dimas, Eka, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Hana berdiri di depan Citra (tidak harus bersebelahan). Eka berdiri di depan Citra (tidak harus bersebelahan). Citra dan Dimas tidak berdiri bersebelahan. Ayu berdiri di depan Eka (tidak harus bersebelahan). Di antara Gilang dan Citra terdapat tepat 1 orang. Siapa yang berdiri pada urutan ke-6?",
    "options": [
      "Gilang",
      "Hana",
      "Ayu",
      "Citra",
      "Eka"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1039,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Bima, Citra, Dimas, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Dimas berdiri di depan Ayu (tidak harus bersebelahan). Di antara Ayu dan Hana terdapat tepat 1 orang. Di antara Citra dan Hana terdapat tepat 3 orang. Dimas dan Ayu tidak berdiri bersebelahan. Hana berdiri tepat di belakang Bima. Siapa yang berdiri pada urutan ke-5?",
    "options": [
      "Dimas",
      "Gilang",
      "Citra",
      "Ayu",
      "Bima"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1040,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Citra, Dimas, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Citra berdiri di depan Farhan (tidak harus bersebelahan). Ayu tidak berdiri pada urutan ke-4. Di antara Gilang dan Citra terdapat tepat 3 orang. Citra berdiri tepat di belakang Ayu. Siapa yang berdiri pada urutan ke-6?",
    "options": [
      "Gilang",
      "Farhan",
      "Citra",
      "Dimas",
      "Ayu"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1041,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Bima, Citra, Eka, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Eka berdiri di depan Gilang (tidak harus bersebelahan). Eka berdiri tepat di belakang Farhan. Di antara Gilang dan Eka terdapat tepat 2 orang. Farhan tidak berdiri pada urutan ke-2. Siapa yang berdiri pada urutan ke-2?",
    "options": [
      "Farhan",
      "Citra",
      "Eka",
      "Gilang",
      "Hana"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1042,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Bima, Citra, Dimas, Eka, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Ayu berdiri di depan Bima (tidak harus bersebelahan). Di antara Dimas dan Hana terdapat tepat 2 orang. Di antara Dimas dan Citra terdapat tepat 4 orang. Hana berdiri di depan Eka (tidak harus bersebelahan). Siapa yang berdiri pada urutan ke-2?",
    "options": [
      "Bima",
      "Dimas",
      "Hana",
      "Ayu",
      "Citra"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1043,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Bima, Citra, Eka, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Eka dan Bima tidak berdiri bersebelahan. Citra berdiri di depan Eka (tidak harus bersebelahan). Citra berdiri di depan Farhan (tidak harus bersebelahan). Di antara Eka dan Farhan terdapat tepat 2 orang. Gilang dan Farhan tidak berdiri bersebelahan. Gilang berdiri tepat di belakang Hana. Siapa yang berdiri pada urutan ke-6?",
    "options": [
      "Bima",
      "Farhan",
      "Eka",
      "Gilang",
      "Citra"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1044,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Citra, Eka, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Farhan berdiri di depan Eka (tidak harus bersebelahan). Hana berdiri di depan Citra (tidak harus bersebelahan). Di antara Farhan dan Citra terdapat tepat 1 orang. Di antara Gilang dan Hana terdapat tepat 3 orang. Ayu berdiri tepat di belakang Farhan. Siapa yang berdiri pada urutan ke-5?",
    "options": [
      "Gilang",
      "Ayu",
      "Citra",
      "Farhan",
      "Hana"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1045,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Citra, Dimas, Eka, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Eka berdiri di depan Citra (tidak harus bersebelahan). Di antara Eka dan Hana terdapat tepat 1 orang. Ayu berdiri di depan Dimas (tidak harus bersebelahan). Di antara Dimas dan Gilang terdapat tepat 2 orang. Gilang tidak berdiri di ujung barisan manapun. Ayu tidak berdiri pada urutan ke-4. Siapa yang berdiri pada urutan ke-5?",
    "options": [
      "Dimas",
      "Ayu",
      "Citra",
      "Gilang",
      "Eka"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1046,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Citra, Dimas, Eka, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Di antara Eka dan Farhan terdapat tepat 3 orang. Gilang berdiri di depan Dimas (tidak harus bersebelahan). Eka berdiri di depan Citra (tidak harus bersebelahan). Farhan berdiri tepat di belakang Gilang. Siapa yang berdiri pada urutan ke-4?",
    "options": [
      "Farhan",
      "Gilang",
      "Citra",
      "Hana",
      "Dimas"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1047,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Dimas, Eka, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Di antara Hana dan Gilang terdapat tepat 3 orang. Di antara Ayu dan Dimas terdapat tepat 1 orang. Dimas berdiri di depan Farhan (tidak harus bersebelahan). Di antara Farhan dan Gilang terdapat tepat 2 orang. Siapa yang berdiri pada urutan ke-2?",
    "options": [
      "Eka",
      "Dimas",
      "Farhan",
      "Gilang",
      "Ayu"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1048,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Bima, Dimas, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Dimas berdiri tepat di belakang Bima. Dimas berdiri di depan Ayu (tidak harus bersebelahan). Ayu tidak berdiri di ujung barisan manapun. Farhan berdiri tepat di belakang Gilang. Hana berdiri tepat di belakang Farhan. Siapa yang berdiri pada urutan ke-2?",
    "options": [
      "Farhan",
      "Hana",
      "Bima",
      "Gilang",
      "Dimas"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1049,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Citra, Dimas, Farhan, Gilang, Hana) berdiri dalam satu barisan lurus dari depan ke belakang. Hana berdiri di depan Citra (tidak harus bersebelahan). Citra berdiri tepat di belakang Farhan. Citra berdiri di depan Dimas (tidak harus bersebelahan). Di antara Ayu dan Gilang terdapat tepat 3 orang. Siapa yang berdiri pada urutan ke-3?",
    "options": [
      "Hana",
      "Farhan",
      "Dimas",
      "Gilang",
      "Citra"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  },
  {
    "id": 1050,
    "moduleId": "logika",
    "category": "Logika Dasar",
    "question": "Enam orang (Ayu, Bima, Citra, Dimas, Eka, Farhan) berdiri dalam satu barisan lurus dari depan ke belakang. Farhan tidak berdiri di ujung barisan manapun. Dimas berdiri di depan Bima (tidak harus bersebelahan). Bima dan Citra tidak berdiri bersebelahan. Ayu berdiri di depan Dimas (tidak harus bersebelahan). Di antara Bima dan Eka terdapat tepat 3 orang. Siapa yang berdiri pada urutan ke-2?",
    "options": [
      "Bima",
      "Eka",
      "Farhan",
      "Citra",
      "Ayu"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Gabungkan semua syarat sampai hanya satu penempatan yang mungkin pada urutan tersebut."
  }
];
