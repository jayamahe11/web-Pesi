export const ANALOGI = [
  {
    "id": 1401,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "stetoskop : mendengarkan detak jantung = palu : ...",
    "options": [
      "kerusakan",
      "melukis",
      "memukul",
      "mendengarkan detak jantung",
      "memperbesar objek"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan alat-fungsi: stetoskop berhubungan dengan mendengarkan detak jantung seperti palu dengan memukul."
  },
  {
    "id": 1402,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "palu : memukul = timbangan : ...",
    "options": [
      "denah",
      "melukis",
      "mengukur massa",
      "menjahit",
      "memukul"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan alat-fungsi: palu berhubungan dengan memukul seperti timbangan dengan mengukur massa."
  },
  {
    "id": 1403,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "palu : memukul = stetoskop : ...",
    "options": [
      "mengiris",
      "beku",
      "mengukur massa",
      "memukul",
      "mendengarkan detak jantung"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan alat-fungsi: palu berhubungan dengan memukul seperti stetoskop dengan mendengarkan detak jantung."
  },
  {
    "id": 1404,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "kompas : menunjukkan arah = jarum : ...",
    "options": [
      "menunjukkan arah",
      "burung",
      "mengukur massa",
      "memperbesar objek",
      "menjahit"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan alat-fungsi: kompas berhubungan dengan menunjukkan arah seperti jarum dengan menjahit."
  },
  {
    "id": 1405,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "jarum : menjahit = mikroskop : ...",
    "options": [
      "mendengarkan detak jantung",
      "menunjukkan arah",
      "patung",
      "menjahit",
      "memperbesar objek"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan alat-fungsi: jarum berhubungan dengan menjahit seperti mikroskop dengan memperbesar objek."
  },
  {
    "id": 1406,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "jarum : menjahit = kuas : ...",
    "options": [
      "melukis",
      "abu",
      "menjahit",
      "memukul",
      "mengukur massa"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan alat-fungsi: jarum berhubungan dengan menjahit seperti kuas dengan melukis."
  },
  {
    "id": 1407,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "penjahit : pakaian = petani : ...",
    "options": [
      "hidangan",
      "panen",
      "naskah",
      "berdagang",
      "pakaian"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan profesi-hasil: penjahit berhubungan dengan pakaian seperti petani dengan panen."
  },
  {
    "id": 1408,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "penulis : naskah = koki : ...",
    "options": [
      "vonis",
      "suara",
      "denah",
      "hidangan",
      "naskah"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan profesi-hasil: penulis berhubungan dengan naskah seperti koki dengan hidangan."
  },
  {
    "id": 1409,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "pemahat : patung = penjahit : ...",
    "options": [
      "batuan beku",
      "pakaian",
      "patung",
      "panen",
      "vonis"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan profesi-hasil: pemahat berhubungan dengan patung seperti penjahit dengan pakaian."
  },
  {
    "id": 1410,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sutradara : film = arsitek : ...",
    "options": [
      "patung",
      "film",
      "putus asa",
      "naskah",
      "denah"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan profesi-hasil: sutradara berhubungan dengan film seperti arsitek dengan denah."
  },
  {
    "id": 1411,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "koki : hidangan = pemahat : ...",
    "options": [
      "hidangan",
      "patung",
      "film",
      "naskah",
      "suara"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan profesi-hasil: koki berhubungan dengan hidangan seperti pemahat dengan patung."
  },
  {
    "id": 1412,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "koki : hidangan = komposer : ...",
    "options": [
      "film",
      "oksigen",
      "lagu",
      "panen",
      "hidangan"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan profesi-hasil: koki berhubungan dengan hidangan seperti komposer dengan lagu."
  },
  {
    "id": 1413,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "penjahit : pakaian = arsitek : ...",
    "options": [
      "lagu",
      "panen",
      "pakaian",
      "burung",
      "denah"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan profesi-hasil: penjahit berhubungan dengan pakaian seperti arsitek dengan denah."
  },
  {
    "id": 1414,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "api : abu = erosi : ...",
    "options": [
      "kenaikan harga",
      "longsor",
      "abu",
      "kerusakan",
      "membaca"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan sebab-akibat: api berhubungan dengan abu seperti erosi dengan longsor."
  },
  {
    "id": 1415,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "kemarau : kekeringan = api : ...",
    "options": [
      "panas",
      "kerusakan",
      "abu",
      "membuat kapal",
      "kekeringan"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan sebab-akibat: kemarau berhubungan dengan kekeringan seperti api dengan abu."
  },
  {
    "id": 1416,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "inflasi : kenaikan harga = banjir : ...",
    "options": [
      "kenaikan harga",
      "pakaian",
      "kekeringan",
      "kerusakan",
      "infeksi"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan sebab-akibat: inflasi berhubungan dengan kenaikan harga seperti banjir dengan kerusakan."
  },
  {
    "id": 1417,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "gesekan : panas = inflasi : ...",
    "options": [
      "kenaikan harga",
      "abu",
      "panas",
      "kekeringan",
      "melukis"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan sebab-akibat: gesekan berhubungan dengan panas seperti inflasi dengan kenaikan harga."
  },
  {
    "id": 1418,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "kemarau : kekeringan = erosi : ...",
    "options": [
      "kekeringan",
      "longsor",
      "pura-pura",
      "kerusakan",
      "infeksi"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan sebab-akibat: kemarau berhubungan dengan kekeringan seperti erosi dengan longsor."
  },
  {
    "id": 1419,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "fotosintesis : oksigen = banjir : ...",
    "options": [
      "kerusakan",
      "oksigen",
      "putus asa",
      "infeksi",
      "kekeringan"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan sebab-akibat: fotosintesis berhubungan dengan oksigen seperti banjir dengan kerusakan."
  },
  {
    "id": 1420,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "bab : buku = layar : ...",
    "options": [
      "buku",
      "prosa",
      "televisi",
      "gitar",
      "undang-undang"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan bagian-keseluruhan: bab berhubungan dengan buku seperti layar dengan televisi."
  },
  {
    "id": 1421,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "lensa : kamera = roda : ...",
    "options": [
      "vonis",
      "kamera",
      "mobil",
      "gitar",
      "jaringan"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan bagian-keseluruhan: lensa berhubungan dengan kamera seperti roda dengan mobil."
  },
  {
    "id": 1422,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "layar : televisi = roda : ...",
    "options": [
      "undang-undang",
      "mobil",
      "televisi",
      "prosa",
      "kamera"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan bagian-keseluruhan: layar berhubungan dengan televisi seperti roda dengan mobil."
  },
  {
    "id": 1423,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sayap : pesawat = sel : ...",
    "options": [
      "undang-undang",
      "prosa",
      "televisi",
      "jaringan",
      "pesawat"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan bagian-keseluruhan: sayap berhubungan dengan pesawat seperti sel dengan jaringan."
  },
  {
    "id": 1424,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "lensa : kamera = senar : ...",
    "options": [
      "suara",
      "Pancasila",
      "undang-undang",
      "kamera",
      "gitar"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan bagian-keseluruhan: lensa berhubungan dengan kamera seperti senar dengan gitar."
  },
  {
    "id": 1425,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sayap : pesawat = layar : ...",
    "options": [
      "panen",
      "undang-undang",
      "pesawat",
      "Pancasila",
      "televisi"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan bagian-keseluruhan: sayap berhubungan dengan pesawat seperti layar dengan televisi."
  },
  {
    "id": 1426,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sel : jaringan = layar : ...",
    "options": [
      "Pancasila",
      "bunga",
      "jaringan",
      "televisi",
      "buku"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan bagian-keseluruhan: sel berhubungan dengan jaringan seperti layar dengan televisi."
  },
  {
    "id": 1427,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sedan : mobil = paus : ...",
    "options": [
      "mamalia",
      "bunga",
      "suara",
      "mobil",
      "melukis"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan jenis-golongan: sedan berhubungan dengan mobil seperti paus dengan mamalia."
  },
  {
    "id": 1428,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "tenor : suara = elang : ...",
    "options": [
      "puisi",
      "vonis",
      "bunga",
      "suara",
      "burung"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan jenis-golongan: tenor berhubungan dengan suara seperti elang dengan burung."
  },
  {
    "id": 1429,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "granit : batuan beku = sedan : ...",
    "options": [
      "mamalia",
      "suara",
      "panas",
      "mobil",
      "batuan beku"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan jenis-golongan: granit berhubungan dengan batuan beku seperti sedan dengan mobil."
  },
  {
    "id": 1430,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "granit : batuan beku = paus : ...",
    "options": [
      "mamalia",
      "batuan beku",
      "burung",
      "suara",
      "gitar"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan jenis-golongan: granit berhubungan dengan batuan beku seperti paus dengan mamalia."
  },
  {
    "id": 1431,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "tenor : suara = sedan : ...",
    "options": [
      "mobil",
      "bunga",
      "suara",
      "denah",
      "mamalia"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan jenis-golongan: tenor berhubungan dengan suara seperti sedan dengan mobil."
  },
  {
    "id": 1432,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "granit : batuan beku = tenor : ...",
    "options": [
      "suara",
      "batuan beku",
      "burung",
      "boros",
      "prosa"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan jenis-golongan: granit berhubungan dengan batuan beku seperti tenor dengan suara."
  },
  {
    "id": 1433,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "kecewa : putus asa = gerimis : ...",
    "options": [
      "putus asa",
      "buku",
      "panik",
      "kehabisan tenaga",
      "hujan lebat"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan tingkatan: kecewa berhubungan dengan putus asa seperti gerimis dengan hujan lebat."
  },
  {
    "id": 1434,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "dingin : beku = basah : ...",
    "options": [
      "bertanding",
      "putus asa",
      "hujan lebat",
      "beku",
      "kuyup"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan tingkatan: dingin berhubungan dengan beku seperti basah dengan kuyup."
  },
  {
    "id": 1435,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "dingin : beku = cemas : ...",
    "options": [
      "putus asa",
      "kuyup",
      "beku",
      "Pancasila",
      "panik"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan tingkatan: dingin berhubungan dengan beku seperti cemas dengan panik."
  },
  {
    "id": 1436,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "hangat : panas = kecewa : ...",
    "options": [
      "cinta",
      "putus asa",
      "kuyup",
      "kekeringan",
      "panas"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan tingkatan: hangat berhubungan dengan panas seperti kecewa dengan putus asa."
  },
  {
    "id": 1437,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "cemas : panik = dingin : ...",
    "options": [
      "pakaian",
      "hujan lebat",
      "beku",
      "panik",
      "kehabisan tenaga"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan tingkatan: cemas berhubungan dengan panik seperti dingin dengan beku."
  },
  {
    "id": 1438,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "hangat : panas = gerimis : ...",
    "options": [
      "Pancasila",
      "kehabisan tenaga",
      "panas",
      "hujan lebat",
      "putus asa"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan tingkatan: hangat berhubungan dengan panas seperti gerimis dengan hujan lebat."
  },
  {
    "id": 1439,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sempurna : cacat = kuno : ...",
    "options": [
      "modern",
      "meneliti",
      "cacat",
      "pura-pura",
      "hening"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan antonim: sempurna berhubungan dengan cacat seperti kuno dengan modern."
  },
  {
    "id": 1440,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "tabah : rapuh = abadi : ...",
    "options": [
      "fana",
      "beku",
      "modern",
      "pura-pura",
      "rapuh"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan antonim: tabah berhubungan dengan rapuh seperti abadi dengan fana."
  },
  {
    "id": 1441,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sempurna : cacat = hemat : ...",
    "options": [
      "boros",
      "modern",
      "panas",
      "pura-pura",
      "cacat"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hubungan antonim: sempurna berhubungan dengan cacat seperti hemat dengan boros."
  },
  {
    "id": 1442,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "tabah : rapuh = kuno : ...",
    "options": [
      "boros",
      "rapuh",
      "modern",
      "mengukur massa",
      "fana"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Hubungan antonim: tabah berhubungan dengan rapuh seperti kuno dengan modern."
  },
  {
    "id": 1443,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "sempurna : cacat = gemuruh : ...",
    "options": [
      "kerusakan",
      "cacat",
      "fana",
      "hening",
      "boros"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan antonim: sempurna berhubungan dengan cacat seperti gemuruh dengan hening."
  },
  {
    "id": 1444,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "ramah : ketus = tulus : ...",
    "options": [
      "modern",
      "hening",
      "ketus",
      "pura-pura",
      "kenaikan harga"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan antonim: ramah berhubungan dengan ketus seperti tulus dengan pura-pura."
  },
  {
    "id": 1445,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "perpustakaan : membaca = pasar : ...",
    "options": [
      "menonton",
      "berdagang",
      "membaca",
      "bertanding",
      "vonis"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan tempat-kegiatan: perpustakaan berhubungan dengan membaca seperti pasar dengan berdagang."
  },
  {
    "id": 1446,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "laboratorium : meneliti = bioskop : ...",
    "options": [
      "membuat kapal",
      "menonton",
      "modern",
      "meneliti",
      "mengadili"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan tempat-kegiatan: laboratorium berhubungan dengan meneliti seperti bioskop dengan menonton."
  },
  {
    "id": 1447,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "perpustakaan : membaca = galangan : ...",
    "options": [
      "menjahit",
      "memperbaiki",
      "membaca",
      "meneliti",
      "membuat kapal"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hubungan tempat-kegiatan: perpustakaan berhubungan dengan membaca seperti galangan dengan membuat kapal."
  },
  {
    "id": 1448,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "pengadilan : mengadili = bengkel : ...",
    "options": [
      "mengadili",
      "membuat kapal",
      "panas",
      "memperbaiki",
      "bertanding"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan tempat-kegiatan: pengadilan berhubungan dengan mengadili seperti bengkel dengan memperbaiki."
  },
  {
    "id": 1449,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "galangan : membuat kapal = bioskop : ...",
    "options": [
      "membaca",
      "membuat kapal",
      "pakaian",
      "menonton",
      "mengadili"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Hubungan tempat-kegiatan: galangan berhubungan dengan membuat kapal seperti bioskop dengan menonton."
  },
  {
    "id": 1450,
    "moduleId": "analogi",
    "category": "Analogi Kata",
    "question": "pasar : berdagang = pengadilan : ...",
    "options": [
      "bertanding",
      "mengadili",
      "berdagang",
      "televisi",
      "meneliti"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Hubungan tempat-kegiatan: pasar berhubungan dengan berdagang seperti pengadilan dengan mengadili."
  }
];
