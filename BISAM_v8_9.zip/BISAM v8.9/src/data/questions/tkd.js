export const TKD = [
  {
    "id": 2401,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "125 + 275 - 90 = ...",
    "options": [
      "290",
      "300",
      "310",
      "320",
      "330"
    ],
    "answer": "C",
    "explanation": "400 - 90 = 310."
  },
  {
    "id": 2402,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "3/5 dari 200 adalah ...",
    "options": [
      "100",
      "110",
      "120",
      "130",
      "140"
    ],
    "answer": "C",
    "explanation": "3/5 × 200 = 120."
  },
  {
    "id": 2403,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Deret 5, 10, 20, 40, ...",
    "options": [
      "60",
      "70",
      "75",
      "80",
      "90"
    ],
    "answer": "D",
    "explanation": "Setiap suku dikali 2."
  },
  {
    "id": 2404,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Barang Rp150.000 didiskon 10%. Harga akhir ...",
    "options": [
      "Rp125.000",
      "Rp130.000",
      "Rp135.000",
      "Rp140.000",
      "Rp145.000"
    ],
    "answer": "C",
    "explanation": "Diskon 15.000, jadi 135.000."
  },
  {
    "id": 2405,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Rata-rata 6, 8, 10, 12, 14 adalah ...",
    "options": [
      "8",
      "9",
      "10",
      "11",
      "12"
    ],
    "answer": "C",
    "explanation": "Jumlah 50, dibagi 5 = 10."
  },
  {
    "id": 2406,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Kata baku yang benar adalah ...",
    "options": [
      "Resiko",
      "Aktifitas",
      "Praktek",
      "Risiko",
      "Ijin"
    ],
    "answer": "D",
    "explanation": "Bentuk baku: risiko."
  },
  {
    "id": 2407,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Kata baku yang benar adalah ...",
    "options": [
      "Analisa",
      "Apotik",
      "Sistem",
      "Nasehat",
      "Sekedar"
    ],
    "answer": "C",
    "explanation": "Bentuk baku: sistem."
  },
  {
    "id": 2408,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Kalimat efektif adalah ...",
    "options": [
      "Para siswa-siswa sedang belajar.",
      "Saya melihat dia tadi pagi sekali.",
      "Mereka membahas rencana kegiatan besok.",
      "Agar supaya cepat selesai, kita harus bekerja.",
      "Dia naik ke atas lantai dua."
    ],
    "answer": "C",
    "explanation": "Kalimat C tidak boros kata."
  },
  {
    "id": 2409,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Sinonim 'akurat' adalah ...",
    "options": [
      "Tepat",
      "Samar",
      "Lambat",
      "Luas",
      "Sulit"
    ],
    "answer": "A",
    "explanation": "Akurat berarti tepat."
  },
  {
    "id": 2410,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Antonim 'konvensional' adalah ...",
    "options": [
      "Tradisional",
      "Biasa",
      "Modern",
      "Umum",
      "Lazim"
    ],
    "answer": "C",
    "explanation": "Dalam konteks umum, lawannya modern."
  },
  {
    "id": 2411,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "3 kg apel seharga Rp18.000/kg. Total ...",
    "options": [
      "Rp48.000",
      "Rp50.000",
      "Rp52.000",
      "Rp54.000",
      "Rp56.000"
    ],
    "answer": "D",
    "explanation": "3×18.000=54.000."
  },
  {
    "id": 2412,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Persegi sisi 9 cm. Keliling ...",
    "options": [
      "18 cm",
      "27 cm",
      "32 cm",
      "36 cm",
      "81 cm"
    ],
    "answer": "D",
    "explanation": "4×9=36."
  },
  {
    "id": 2413,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Ibu kota Jawa Tengah adalah ...",
    "options": [
      "Surakarta",
      "Semarang",
      "Yogyakarta",
      "Magelang",
      "Purwokerto"
    ],
    "answer": "B",
    "explanation": "Ibu kota Jawa Tengah adalah Semarang."
  },
  {
    "id": 2414,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Planet terbesar dalam Tata Surya adalah ...",
    "options": [
      "Bumi",
      "Mars",
      "Jupiter",
      "Saturnus",
      "Venus"
    ],
    "answer": "C",
    "explanation": "Jupiter adalah planet terbesar."
  },
  {
    "id": 2415,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Proses tumbuhan membuat makanan dengan cahaya disebut ...",
    "options": [
      "Respirasi",
      "Fotosintesis",
      "Fermentasi",
      "Evaporasi",
      "Transpirasi"
    ],
    "answer": "B",
    "explanation": "Disebut fotosintesis."
  },
  {
    "id": 2416,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Air mendidih pada tekanan atmosfer normal sekitar ...",
    "options": [
      "0°C",
      "50°C",
      "75°C",
      "100°C",
      "120°C"
    ],
    "answer": "D",
    "explanation": "Sekitar 100°C pada 1 atm."
  },
  {
    "id": 2417,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Organ yang memompa darah adalah ...",
    "options": [
      "Paru-paru",
      "Ginjal",
      "Jantung",
      "Hati",
      "Lambung"
    ],
    "answer": "C",
    "explanation": "Jantung memompa darah."
  },
  {
    "id": 2418,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Semua kucing mamalia. Miko kucing. Maka ...",
    "options": [
      "Miko bukan mamalia",
      "Miko mamalia",
      "Semua mamalia kucing",
      "Miko burung",
      "Tidak dapat disimpulkan"
    ],
    "answer": "B",
    "explanation": "Miko termasuk kucing, maka mamalia."
  },
  {
    "id": 2419,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Jika lampu menyala maka ruangan terang. Lampu menyala. Maka ...",
    "options": [
      "Ruangan gelap",
      "Ruangan terang",
      "Lampu mati",
      "Tidak ada ruangan",
      "Tidak dapat disimpulkan"
    ],
    "answer": "B",
    "explanation": "Modus ponens."
  },
  {
    "id": 2420,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Deret 2, 6, 12, 20, 30, ...",
    "options": [
      "36",
      "40",
      "42",
      "44",
      "48"
    ],
    "answer": "C",
    "explanation": "Pola n(n+1), berikutnya 6×7=42."
  },
  {
    "id": 2421,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "0,75 × 200 = ...",
    "options": [
      "125",
      "140",
      "150",
      "160",
      "175"
    ],
    "answer": "C",
    "explanation": "Hasilnya 150."
  },
  {
    "id": 2422,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Jika 4x = 52, x = ...",
    "options": [
      "11",
      "12",
      "13",
      "14",
      "15"
    ],
    "answer": "C",
    "explanation": "52/4=13."
  },
  {
    "id": 2423,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Keputusan itu diambil melalui ... bersama.",
    "options": [
      "musyawarah",
      "perdebatan",
      "perselisihan",
      "paksaan",
      "ancaman"
    ],
    "answer": "A",
    "explanation": "Frasa yang tepat: musyawarah bersama."
  },
  {
    "id": 2424,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Penulisan yang tepat adalah ...",
    "options": [
      "Saya pergi ke bandung.",
      "Saya pergi ke Bandung.",
      "saya pergi ke Bandung.",
      "Saya Pergi Ke Bandung.",
      "Saya pergi Ke bandung."
    ],
    "answer": "B",
    "explanation": "Nama kota dan awal kalimat memakai huruf kapital."
  },
  {
    "id": 2425,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Bilangan prima adalah ...",
    "options": [
      "21",
      "27",
      "29",
      "33",
      "39"
    ],
    "answer": "C",
    "explanation": "29 hanya punya faktor 1 dan 29."
  },
  {
    "id": 2426,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "FPB dari 24 dan 36 adalah ...",
    "options": [
      "6",
      "8",
      "10",
      "12",
      "18"
    ],
    "answer": "D",
    "explanation": "FPB = 12."
  },
  {
    "id": 2427,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "KPK dari 6 dan 8 adalah ...",
    "options": [
      "12",
      "18",
      "24",
      "30",
      "48"
    ],
    "answer": "C",
    "explanation": "KPK = 24."
  },
  {
    "id": 2428,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Indonesia terletak di antara benua ...",
    "options": [
      "Asia dan Afrika",
      "Asia dan Australia",
      "Australia dan Eropa",
      "Afrika dan Eropa",
      "Asia dan Amerika"
    ],
    "answer": "B",
    "explanation": "Indonesia berada di antara Asia dan Australia."
  },
  {
    "id": 2429,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Indonesia berada di antara samudra ...",
    "options": [
      "Atlantik dan Arktik",
      "Pasifik dan Hindia",
      "Arktik dan Hindia",
      "Atlantik dan Pasifik",
      "Mediterania dan Pasifik"
    ],
    "answer": "B",
    "explanation": "Indonesia berada di antara Samudra Hindia dan Pasifik."
  },
  {
    "id": 2430,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Sumber energi utama bagi kehidupan di Bumi adalah ...",
    "options": [
      "Bulan",
      "Angin",
      "Matahari",
      "Batu bara",
      "Air"
    ],
    "answer": "C",
    "explanation": "Matahari adalah sumber energi utama."
  },
  {
    "id": 2431,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "09.20 ditambah 2 jam 45 menit menjadi ...",
    "options": [
      "11.45",
      "12.00",
      "12.05",
      "12.15",
      "12.25"
    ],
    "answer": "C",
    "explanation": "Hasilnya 12.05."
  },
  {
    "id": 2432,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Jumlah sudut dalam segitiga adalah ...",
    "options": [
      "90°",
      "120°",
      "180°",
      "270°",
      "360°"
    ],
    "answer": "C",
    "explanation": "Jumlah sudut segitiga 180°."
  },
  {
    "id": 2433,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Segitiga siku-siku memiliki sisi 3 cm dan 4 cm. Sisi miring ...",
    "options": [
      "5 cm",
      "6 cm",
      "7 cm",
      "8 cm",
      "9 cm"
    ],
    "answer": "A",
    "explanation": "Pythagoras: 3-4-5."
  },
  {
    "id": 2434,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "'Efisien' berarti ...",
    "options": [
      "Mahal",
      "Boros",
      "Berdaya guna dengan sumber daya minimal",
      "Lambat",
      "Tidak teratur"
    ],
    "answer": "C",
    "explanation": "Efisien berarti hemat sumber daya untuk hasil yang baik."
  },
  {
    "id": 2435,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Tanda baca yang tepat terdapat pada kalimat ...",
    "options": [
      "Ibu membeli apel jeruk, dan mangga.",
      "Ibu membeli apel, jeruk, dan mangga.",
      "Ibu, membeli apel jeruk dan mangga.",
      "Ibu membeli, apel, jeruk dan mangga.",
      "Ibu membeli apel jeruk dan, mangga."
    ],
    "answer": "B",
    "explanation": "Perincian dipisahkan dengan koma."
  },
  {
    "id": 2436,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Benda yang menghantarkan listrik dengan baik disebut ...",
    "options": [
      "Isolator",
      "Konduktor",
      "Katalisator",
      "Generator",
      "Radiator"
    ],
    "answer": "B",
    "explanation": "Disebut konduktor."
  },
  {
    "id": 2437,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Contoh isolator listrik adalah ...",
    "options": [
      "Tembaga",
      "Aluminium",
      "Besi",
      "Karet",
      "Perak"
    ],
    "answer": "D",
    "explanation": "Karet adalah isolator."
  },
  {
    "id": 2438,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Perubahan cair menjadi gas disebut ...",
    "options": [
      "Membeku",
      "Mencair",
      "Menguap",
      "Mengembun",
      "Menyublim"
    ],
    "answer": "C",
    "explanation": "Cair ke gas = menguap."
  },
  {
    "id": 2439,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Perubahan gas menjadi cair disebut ...",
    "options": [
      "Menguap",
      "Mengembun",
      "Membeku",
      "Mencair",
      "Menyublim"
    ],
    "answer": "B",
    "explanation": "Gas ke cair = mengembun."
  },
  {
    "id": 2440,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Jika semua A adalah B dan semua B adalah C, maka ...",
    "options": [
      "Semua C adalah A",
      "Semua A adalah C",
      "Tidak ada A yang C",
      "Sebagian C bukan B pasti",
      "Semua B adalah A"
    ],
    "answer": "B",
    "explanation": "A bagian dari B, B bagian dari C, maka A bagian dari C."
  },
  {
    "id": 2441,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "'Produktif' berarti ...",
    "options": [
      "Tidak menghasilkan",
      "Mampu menghasilkan",
      "Tidak aktif",
      "Merusak",
      "Menghambat"
    ],
    "answer": "B",
    "explanation": "Produktif berarti mampu menghasilkan."
  },
  {
    "id": 2442,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Satu lusin = ... buah.",
    "options": [
      "10",
      "11",
      "12",
      "20",
      "24"
    ],
    "answer": "C",
    "explanation": "Satu lusin = 12."
  },
  {
    "id": 2443,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Satu gross = ... buah.",
    "options": [
      "12",
      "24",
      "100",
      "120",
      "144"
    ],
    "answer": "E",
    "explanation": "Satu gross = 12 lusin = 144."
  },
  {
    "id": 2444,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "2 liter = ... mililiter.",
    "options": [
      "200",
      "500",
      "1.000",
      "2.000",
      "20.000"
    ],
    "answer": "D",
    "explanation": "2 liter = 2.000 ml."
  },
  {
    "id": 2445,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Benua terluas di dunia adalah ...",
    "options": [
      "Afrika",
      "Asia",
      "Eropa",
      "Amerika Selatan",
      "Australia"
    ],
    "answer": "B",
    "explanation": "Asia adalah benua terluas."
  },
  {
    "id": 2446,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Gunung tertinggi di dunia di atas permukaan laut adalah ...",
    "options": [
      "Kilimanjaro",
      "Everest",
      "Elbrus",
      "Fuji",
      "Jaya Wijaya"
    ],
    "answer": "B",
    "explanation": "Gunung Everest."
  },
  {
    "id": 2447,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Rumus luas lingkaran adalah ...",
    "options": [
      "2πr",
      "πr²",
      "πd",
      "r²",
      "2r²"
    ],
    "answer": "B",
    "explanation": "Luas lingkaran = πr²."
  },
  {
    "id": 2448,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Diameter lingkaran 14 cm. Jari-jari ...",
    "options": [
      "5 cm",
      "6 cm",
      "7 cm",
      "8 cm",
      "14 cm"
    ],
    "answer": "C",
    "explanation": "Jari-jari = setengah diameter."
  },
  {
    "id": 2449,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Kalimat 'Karena hujan deras, pertandingan ditunda.' menunjukkan hubungan ...",
    "options": [
      "Perbandingan",
      "Sebab-akibat",
      "Pertentangan",
      "Penambahan",
      "Pilihan"
    ],
    "answer": "B",
    "explanation": "Hujan adalah sebab, penundaan akibat."
  },
  {
    "id": 2450,
    "moduleId": "tkd",
    "category": "TKD",
    "question": "Data 4, 6, 6, 8, 10 memiliki modus ...",
    "options": [
      "4",
      "5",
      "6",
      "8",
      "10"
    ],
    "answer": "C",
    "explanation": "6 muncul paling sering."
  }
];
