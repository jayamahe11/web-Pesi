export const KEPRIBADIAN = [
  {
    "id": 2101,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Tenggat laporan Anda dimajukan mendadak menjadi besok pagi, padahal pekerjaan lain juga menumpuk. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menambah jam kerja sendiri sampai selesai tanpa memberi tahu siapa pun",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "menenangkan diri sejenak, menyusun urutan prioritas, dan melaporkan kendala kepada atasan",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2102,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda ditegur atasan di depan rekan karena kesalahan kecil yang sebenarnya dilakukan orang lain. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "berusaha tetap tenang dan menyelesaikan semuanya sendiri meskipun terasa sangat berat tanpa meminta bantuan",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "tetap tenang, memilah pekerjaan paling mendesak, lalu meminta bantuan bila perlu",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2103,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Sistem kerja Anda mati satu jam sebelum presentasi penting kepada pimpinan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menambah jam kerja sendiri sampai selesai tanpa memberi tahu siapa pun",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "menenangkan diri sejenak, menyusun urutan prioritas, dan melaporkan kendala kepada atasan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2104,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda menerima tiga permintaan mendesak dari tiga atasan berbeda pada waktu yang bersamaan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "berusaha tetap tenang dan menyelesaikan semuanya sendiri meskipun terasa sangat berat tanpa meminta bantuan",
      "tetap tenang, memilah pekerjaan paling mendesak, lalu meminta bantuan bila perlu",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2105,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Hasil kerja Anda ditolak untuk ketiga kalinya dengan alasan yang terus berubah. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "menambah jam kerja sendiri sampai selesai tanpa memberi tahu siapa pun",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "menenangkan diri sejenak, menyusun urutan prioritas, dan melaporkan kendala kepada atasan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2106,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda harus menggantikan rekan yang mendadak sakit untuk memimpin rapat besar tanpa persiapan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "berusaha tetap tenang dan menyelesaikan semuanya sendiri meskipun terasa sangat berat tanpa meminta bantuan",
      "tetap tenang, memilah pekerjaan paling mendesak, lalu meminta bantuan bila perlu",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2107,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Pekerjaan yang Anda kerjakan seminggu hilang akibat berkas rusak dan belum ada cadangan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menenangkan diri sejenak, menyusun urutan prioritas, dan melaporkan kendala kepada atasan",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "menambah jam kerja sendiri sampai selesai tanpa memberi tahu siapa pun",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2108,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Pelanggan marah-marah di depan banyak orang karena keterlambatan yang bukan salah Anda. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "berusaha tetap tenang dan menyelesaikan semuanya sendiri meskipun terasa sangat berat tanpa meminta bantuan",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "tetap tenang, memilah pekerjaan paling mendesak, lalu meminta bantuan bila perlu",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2109,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda mendapat target baru yang menurut Anda hampir mustahil dicapai dalam sebulan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "menenangkan diri sejenak, menyusun urutan prioritas, dan melaporkan kendala kepada atasan",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "menambah jam kerja sendiri sampai selesai tanpa memberi tahu siapa pun"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2110,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Pekerjaan Anda dikritik keras di forum terbuka oleh pimpinan dari unit lain. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "berusaha tetap tenang dan menyelesaikan semuanya sendiri meskipun terasa sangat berat tanpa meminta bantuan",
      "mengeluhkan keadaan itu kepada rekan sambil mengerjakan seadanya",
      "membiarkannya dan berharap orang lain yang akan menyelesaikan masalah itu",
      "menunda sebentar sampai perasaan menjadi lebih tenang baru mulai mengerjakannya",
      "tetap tenang, memilah pekerjaan paling mendesak, lalu meminta bantuan bila perlu"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Ketahanan terhadap tekanan. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2111,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Rekan mengajak Anda memalsukan tanda tangan kehadiran agar bisa pulang lebih awal. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menolak secara halus dan mengingatkan pihak lain agar tidak mengulanginya",
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui",
      "menolak tegas, menjelaskan konsekuensinya, dan mencatat kejadian untuk dilaporkan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2112,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Atasan menyarankan Anda diam saja soal selisih anggaran yang menguntungkan unit Anda. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "menolak ajakan itu dan menjaga jarak dari pihak yang menyarankannya tanpa melaporkan kejadian itu kepada siapa pun",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui",
      "menolak dengan sopan, menjelaskan aturan, lalu melaporkannya lewat jalur resmi",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2113,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Seorang kenalan menawarkan imbalan jika Anda membocorkan informasi seleksi internal. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menolak tegas, menjelaskan konsekuensinya, dan mencatat kejadian untuk dilaporkan",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "menolak secara halus dan mengingatkan pihak lain agar tidak mengulanginya",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui",
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2114,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Atasan meminta Anda memperbaiki angka laporan agar target terlihat tercapai. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menolak dengan sopan, menjelaskan aturan, lalu melaporkannya lewat jalur resmi",
      "menolak ajakan itu dan menjaga jarak dari pihak yang menyarankannya tanpa melaporkan kejadian itu kepada siapa pun",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui",
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2115,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Rekan menyarankan Anda memakai uang di dompet temuan daripada melaporkannya. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menolak tegas, menjelaskan konsekuensinya, dan mencatat kejadian untuk dilaporkan",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui",
      "menolak secara halus dan mengingatkan pihak lain agar tidak mengulanginya"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2116,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda mengetahui rekan dekat memakai fasilitas kantor untuk usaha pribadinya. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "menolak ajakan itu dan menjaga jarak dari pihak yang menyarankannya tanpa melaporkan kejadian itu kepada siapa pun",
      "menolak dengan sopan, menjelaskan aturan, lalu melaporkannya lewat jalur resmi",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2117,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda keliru memasukkan data sehingga unit Anda mendapat poin lebih, dan belum ada yang tahu. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menolak tegas, menjelaskan konsekuensinya, dan mencatat kejadian untuk dilaporkan",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "menolak secara halus dan mengingatkan pihak lain agar tidak mengulanginya",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2118,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Teman menyodorkan hasil kerja orang lain agar Anda akui sebagai hasil kerja bersama. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "menolak ajakan itu dan menjaga jarak dari pihak yang menyarankannya tanpa melaporkan kejadian itu kepada siapa pun",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui",
      "menolak dengan sopan, menjelaskan aturan, lalu melaporkannya lewat jalur resmi",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2119,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda diminta menandatangani laporan kegiatan yang tidak pernah Anda ikuti. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "menolak tegas, menjelaskan konsekuensinya, dan mencatat kejadian untuk dilaporkan",
      "menolak secara halus dan mengingatkan pihak lain agar tidak mengulanginya",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2120,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Vendor menawarkan makan siang mewah menjelang penilaian penawaran mereka. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menolak dengan sopan, menjelaskan aturan, lalu melaporkannya lewat jalur resmi",
      "tidak ikut melakukannya, tetapi memilih tidak ikut campur dan tidak melapor",
      "ikut melakukannya sekali ini saja karena dianggap tidak merugikan siapa pun",
      "menolak ajakan itu dan menjaga jarak dari pihak yang menyarankannya tanpa melaporkan kejadian itu kepada siapa pun",
      "ikut melakukannya dan berusaha menghapus jejak agar tidak pernah diketahui"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Integritas. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2121,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Dalam proyek kelompok, dua rekan Anda berselisih tentang pembagian tugas sehingga pekerjaan terhenti. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mengajak semua pihak berdiskusi, membagi peran dengan jelas, dan menyepakati cara kerja",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "memberi masukan kepada yang bersangkutan, lalu menunggu mereka menyelesaikannya",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2122,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Seorang anggota tim selalu terlambat menyerahkan bagiannya sehingga seluruh tim ikut terlambat. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "menyampaikan keberatan secara pribadi, lalu tetap menjalankan bagian masing-masing dengan baik tanpa membahasnya dalam tim",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun",
      "mendengarkan kedua pihak, lalu merumuskan kesepakatan kerja yang disetujui bersama",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2123,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Rekan dari unit lain tidak membalas permintaan data yang dibutuhkan tim Anda. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "memberi masukan kepada yang bersangkutan, lalu menunggu mereka menyelesaikannya",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mengajak semua pihak berdiskusi, membagi peran dengan jelas, dan menyepakati cara kerja",
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2124,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda memiliki ide yang berbeda dari keputusan mayoritas tim. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mendengarkan kedua pihak, lalu merumuskan kesepakatan kerja yang disetujui bersama",
      "menyampaikan keberatan secara pribadi, lalu tetap menjalankan bagian masing-masing dengan baik tanpa membahasnya dalam tim",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2125,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anggota baru sulit mengikuti ritme kerja tim dan sering bertanya hal dasar. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "memberi masukan kepada yang bersangkutan, lalu menunggu mereka menyelesaikannya",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mengajak semua pihak berdiskusi, membagi peran dengan jelas, dan menyepakati cara kerja"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2126,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Tim diminta menyelesaikan laporan bersama, tetapi kontribusi tiap orang tidak seimbang. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "menyampaikan keberatan secara pribadi, lalu tetap menjalankan bagian masing-masing dengan baik tanpa membahasnya dalam tim",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun",
      "mendengarkan kedua pihak, lalu merumuskan kesepakatan kerja yang disetujui bersama"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2127,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Dua unit berbeda saling menyalahkan atas kegagalan program bersama. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "memberi masukan kepada yang bersangkutan, lalu menunggu mereka menyelesaikannya",
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mengajak semua pihak berdiskusi, membagi peran dengan jelas, dan menyepakati cara kerja",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2128,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Dalam rapat, dua anggota tim terus berdebat sehingga rapat tidak menghasilkan keputusan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mendengarkan kedua pihak, lalu merumuskan kesepakatan kerja yang disetujui bersama",
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "menyampaikan keberatan secara pribadi, lalu tetap menjalankan bagian masing-masing dengan baik tanpa membahasnya dalam tim"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2129,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Seorang rekan senior meremehkan usulan Anda di depan tim. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "memberi masukan kepada yang bersangkutan, lalu menunggu mereka menyelesaikannya",
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan",
      "mengajak semua pihak berdiskusi, membagi peran dengan jelas, dan menyepakati cara kerja",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2130,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Tim harus menyelesaikan tugas dalam waktu singkat tetapi anggotanya saling menunggu perintah. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menyampaikan keberatan secara pribadi, lalu tetap menjalankan bagian masing-masing dengan baik tanpa membahasnya dalam tim",
      "mendengarkan kedua pihak, lalu merumuskan kesepakatan kerja yang disetujui bersama",
      "mengerjakan bagian sendiri saja dan tidak mencampuri bagian orang lain",
      "mengambil alih seluruh pekerjaan tim agar tidak lagi bergantung pada siapa pun",
      "melaporkan masalah itu kepada atasan tanpa berbicara lebih dulu dengan yang bersangkutan"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Kerja sama. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2131,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda melihat prosedur pengarsipan di unit Anda lambat dan sering menyebabkan dokumen hilang. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa",
      "mengusulkan solusi konkret beserta rencananya, lalu menjalankannya setelah disetujui",
      "mencari tahu penyebab masalahnya lalu mencatatnya untuk dibicarakan nanti",
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2132,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Target unit Anda sudah tercapai bulan ini, tetapi masih ada waktu luang dua minggu. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "memperbaiki bagian yang menjadi tanggung jawab sendiri dengan baik tanpa melibatkan atau memberi tahu pihak lain",
      "mengambil langkah perbaikan, menyusun rencana singkat, lalu melapor kepada atasan",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2133,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda mendapati sebagian pelanggan sering menanyakan hal yang sama berulang kali. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "mengusulkan solusi konkret beserta rencananya, lalu menjalankannya setelah disetujui",
      "mencari tahu penyebab masalahnya lalu mencatatnya untuk dibicarakan nanti",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2134,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Atasan sedang dinas luar dan muncul masalah kecil yang menghambat pekerjaan tim. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "mengambil langkah perbaikan, menyusun rencana singkat, lalu melapor kepada atasan",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "memperbaiki bagian yang menjadi tanggung jawab sendiri dengan baik tanpa melibatkan atau memberi tahu pihak lain"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2135,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda mendapat kesempatan mengikuti pelatihan yang tidak diwajibkan tetapi relevan dengan pekerjaan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "mencari tahu penyebab masalahnya lalu mencatatnya untuk dibicarakan nanti",
      "mengusulkan solusi konkret beserta rencananya, lalu menjalankannya setelah disetujui",
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2136,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda menemukan cara yang lebih cepat untuk mengerjakan laporan bulanan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "memperbaiki bagian yang menjadi tanggung jawab sendiri dengan baik tanpa melibatkan atau memberi tahu pihak lain",
      "mengambil langkah perbaikan, menyusun rencana singkat, lalu melapor kepada atasan",
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2137,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Ruang kerja bersama sering berantakan sehingga mengganggu pekerjaan orang lain. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mengusulkan solusi konkret beserta rencananya, lalu menjalankannya setelah disetujui",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "mencari tahu penyebab masalahnya lalu mencatatnya untuk dibicarakan nanti",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2138,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda memperhatikan formulir layanan sering diisi salah oleh warga. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "memperbaiki bagian yang menjadi tanggung jawab sendiri dengan baik tanpa melibatkan atau memberi tahu pihak lain",
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "mengambil langkah perbaikan, menyusun rencana singkat, lalu melapor kepada atasan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2139,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Proyek yang Anda pegang selesai lebih cepat dari jadwal dengan hasil yang sudah memadai. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "mencari tahu penyebab masalahnya lalu mencatatnya untuk dibicarakan nanti",
      "mengusulkan solusi konkret beserta rencananya, lalu menjalankannya setelah disetujui"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2140,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda ditawari memimpin kegiatan kecil di luar tugas utama tanpa insentif tambahan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "memperbaiki bagian yang menjadi tanggung jawab sendiri dengan baik tanpa melibatkan atau memberi tahu pihak lain",
      "mengambil langkah perbaikan, menyusun rencana singkat, lalu melapor kepada atasan",
      "menceritakannya kepada rekan tetapi tidak berbuat apa pun",
      "menunggu arahan atasan terlebih dahulu sebelum melakukan apa pun",
      "menganggap itu bukan urusannya dan melanjutkan pekerjaan seperti biasa"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Inisiatif dan orientasi prestasi. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2141,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Instansi mengganti sistem kerja manual dengan aplikasi baru mulai minggu depan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri",
      "menerima perubahan itu, mempelajari hal baru, dan menyesuaikan cara kerja secepatnya",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menjalankan aturan baru secukupnya sambil menunggu arahan pimpinan",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2142,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda dipindahkan ke unit yang tugasnya sangat berbeda dari keahlian Anda. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mengikuti perubahan itu dengan patuh walaupun masih lebih nyaman dengan cara lama dan jarang mencoba cara baru",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri",
      "memahami alasan perubahan, berlatih kemampuan baru, lalu membantu rekan beradaptasi"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2143,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Atasan baru menerapkan cara kerja yang berbeda dari kebiasaan unit selama ini. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menerima perubahan itu, mempelajari hal baru, dan menyesuaikan cara kerja secepatnya",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "menjalankan aturan baru secukupnya sambil menunggu arahan pimpinan",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2144,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Jadwal kerja Anda berubah menjadi sistem bergilir mulai bulan depan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "mengikuti perubahan itu dengan patuh walaupun masih lebih nyaman dengan cara lama dan jarang mencoba cara baru",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri",
      "memahami alasan perubahan, berlatih kemampuan baru, lalu membantu rekan beradaptasi"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2145,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Prosedur pelayanan direvisi sehingga sebagian langkah yang Anda kuasai tidak berlaku lagi. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menjalankan aturan baru secukupnya sambil menunggu arahan pimpinan",
      "menerima perubahan itu, mempelajari hal baru, dan menyesuaikan cara kerja secepatnya",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2146,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Seluruh anggota tim Anda diganti dengan orang-orang baru. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri",
      "memahami alasan perubahan, berlatih kemampuan baru, lalu membantu rekan beradaptasi",
      "mengikuti perubahan itu dengan patuh walaupun masih lebih nyaman dengan cara lama dan jarang mencoba cara baru",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2147,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Anda harus bekerja dari lokasi yang berbeda setiap pekan sesuai kebutuhan layanan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menjalankan aturan baru secukupnya sambil menunggu arahan pimpinan",
      "menerima perubahan itu, mempelajari hal baru, dan menyesuaikan cara kerja secepatnya",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2148,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Standar penilaian kinerja diubah di tengah tahun berjalan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "memahami alasan perubahan, berlatih kemampuan baru, lalu membantu rekan beradaptasi",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "mengikuti perubahan itu dengan patuh walaupun masih lebih nyaman dengan cara lama dan jarang mencoba cara baru"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2149,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Peraturan baru mengharuskan Anda membuat laporan dalam format yang belum pernah Anda gunakan. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "menjalankan aturan baru secukupnya sambil menunggu arahan pimpinan",
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menerima perubahan itu, mempelajari hal baru, dan menyesuaikan cara kerja secepatnya",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  },
  {
    "id": 2150,
    "moduleId": "kepribadian",
    "category": "Kepribadian Kerja",
    "question": "Situasi: Unit Anda digabung dengan unit lain dan tugas Anda dibagi ulang. Sikap yang paling menggambarkan diri Anda yang seharusnya adalah ...",
    "options": [
      "mempertanyakan perubahan itu berulang kali sambil tetap memakai cara lama",
      "menolak perubahan itu dan tetap bekerja dengan caranya sendiri",
      "menunggu sampai rekan lain beradaptasi lebih dahulu baru ikut menyesuaikan diri",
      "mengikuti perubahan itu dengan patuh walaupun masih lebih nyaman dengan cara lama dan jarang mencoba cara baru",
      "memahami alasan perubahan, berlatih kemampuan baru, lalu membantu rekan beradaptasi"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Aspek: Adaptabilitas dan pengendalian diri. Pilihan terbaik (skor 5) adalah yang proaktif, bertanggung jawab, dan sesuai prosedur; skor pilihan lain berurutan menurun 4, 3, 2, 1."
  }
];
