export const KETELITIAN = [
  {
    "id": 1801,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah pilihan D.",
    "image": "/public/assets/questions/pencerminan/q01.png"
  },
  {
    "id": 1802,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah pilihan B.",
    "image": "/public/assets/questions/pencerminan/q02.png"
  },
  {
    "id": 1803,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah pilihan C.",
    "image": "/public/assets/questions/pencerminan/q03.png"
  },
  {
    "id": 1804,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah pilihan C.",
    "image": "/public/assets/questions/pencerminan/q04.png"
  },
  {
    "id": 1805,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah pilihan B.",
    "image": "/public/assets/questions/pencerminan/q05.png"
  },
  {
    "id": 1806,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah pilihan A.",
    "image": "/public/assets/questions/pencerminan/q06.png"
  },
  {
    "id": 1807,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah pilihan D.",
    "image": "/public/assets/questions/pencerminan/q07.png"
  },
  {
    "id": 1808,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah pilihan D.",
    "image": "/public/assets/questions/pencerminan/q08.png"
  },
  {
    "id": 1809,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah pilihan C.",
    "image": "/public/assets/questions/pencerminan/q09.png"
  },
  {
    "id": 1810,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah pilihan D.",
    "image": "/public/assets/questions/pencerminan/q10.png"
  },
  {
    "id": 1811,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah pilihan A.",
    "image": "/public/assets/questions/pencerminan/q11.png"
  },
  {
    "id": 1812,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah pilihan A.",
    "image": "/public/assets/questions/pencerminan/q12.png"
  },
  {
    "id": 1813,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah pilihan C.",
    "image": "/public/assets/questions/pencerminan/q13.png"
  },
  {
    "id": 1814,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah pilihan B.",
    "image": "/public/assets/questions/pencerminan/q14.png"
  },
  {
    "id": 1815,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah pilihan B.",
    "image": "/public/assets/questions/pencerminan/q15.png"
  },
  {
    "id": 1816,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah pilihan C.",
    "image": "/public/assets/questions/pencerminan/q16.png"
  },
  {
    "id": 1817,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah pilihan A.",
    "image": "/public/assets/questions/pencerminan/q17.png"
  },
  {
    "id": 1818,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah pilihan C.",
    "image": "/public/assets/questions/pencerminan/q18.png"
  },
  {
    "id": 1819,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah pilihan C.",
    "image": "/public/assets/questions/pencerminan/q19.png"
  },
  {
    "id": 1820,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah pilihan D.",
    "image": "/public/assets/questions/pencerminan/q20.png"
  },
  {
    "id": 1821,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah pilihan E.",
    "image": "/public/assets/questions/pencerminan/q21.png"
  },
  {
    "id": 1822,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah pilihan B.",
    "image": "/public/assets/questions/pencerminan/q22.png"
  },
  {
    "id": 1823,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah pilihan B.",
    "image": "/public/assets/questions/pencerminan/q23.png"
  },
  {
    "id": 1824,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah pilihan D.",
    "image": "/public/assets/questions/pencerminan/q24.png"
  },
  {
    "id": 1825,
    "moduleId": "ketelitian",
    "category": "Tes Ketelitian (Pencerminan Gambar)",
    "question": "Perhatikan gambar soal, lalu pilih hasil pencerminan yang benar.",
    "options": [
      "Pilihan A",
      "Pilihan B",
      "Pilihan C",
      "Pilihan D",
      "Pilihan E"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah pilihan D.",
    "image": "/public/assets/questions/pencerminan/q25.png"
  }
];
