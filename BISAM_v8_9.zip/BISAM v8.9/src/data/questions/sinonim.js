export const SINONIM = [
  {
    "id": 1301,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"adagium\" adalah ...",
    "options": [
      "usang",
      "rumit",
      "pepatah",
      "bersifat membujuk",
      "dogma"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. adagium → pepatah (hati-hati: \"dogma\" bukan sinonimnya)."
  },
  {
    "id": 1302,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"anomali\" adalah ...",
    "options": [
      "bersifat menggulingkan",
      "timbal balik",
      "penyimpangan",
      "pengurangan dampak",
      "kelaziman"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. anomali → penyimpangan (hati-hati: \"kelaziman\" bukan sinonimnya)."
  },
  {
    "id": 1303,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"apatis\" adalah ...",
    "options": [
      "pepatah",
      "acuh tak acuh",
      "antusias",
      "bersifat menggulingkan",
      "taat asas"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. apatis → acuh tak acuh (hati-hati: \"antusias\" bukan sinonimnya)."
  },
  {
    "id": 1304,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"arbitrer\" adalah ...",
    "options": [
      "pertentangan yang tampak",
      "bersifat membujuk",
      "berdasarkan aturan",
      "acuh tak acuh",
      "sewenang-wenang"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. arbitrer → sewenang-wenang (hati-hati: \"berdasarkan aturan\" bukan sinonimnya)."
  },
  {
    "id": 1305,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"destruktif\" adalah ...",
    "options": [
      "bersifat membujuk",
      "merusak",
      "membangun",
      "acuh tak acuh",
      "dugaan sementara"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. destruktif → merusak (hati-hati: \"membangun\" bukan sinonimnya)."
  },
  {
    "id": 1306,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"disparitas\" adalah ...",
    "options": [
      "kesetaraan",
      "bersifat menggulingkan",
      "pertentangan yang tampak",
      "hak istimewa",
      "kesenjangan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. disparitas → kesenjangan (hati-hati: \"kesetaraan\" bukan sinonimnya)."
  },
  {
    "id": 1307,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"eksplisit\" adalah ...",
    "options": [
      "gamblang",
      "tersirat",
      "bermakna",
      "penyimpangan",
      "bersifat menggulingkan"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. eksplisit → gamblang (hati-hati: \"tersirat\" bukan sinonimnya)."
  },
  {
    "id": 1308,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"ekuivalen\" adalah ...",
    "options": [
      "bertentangan",
      "penyimpangan",
      "sepadan",
      "mudah berubah",
      "bermakna"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. ekuivalen → sepadan (hati-hati: \"bertentangan\" bukan sinonimnya)."
  },
  {
    "id": 1309,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"hegemoni\" adalah ...",
    "options": [
      "mudah berubah",
      "timbal balik",
      "dominasi",
      "kemitraan",
      "beragam"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. hegemoni → dominasi (hati-hati: \"kemitraan\" bukan sinonimnya)."
  },
  {
    "id": 1310,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"heterogen\" adalah ...",
    "options": [
      "beragam",
      "peneraan",
      "merusak",
      "hubungan timbal balik",
      "seragam"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. heterogen → beragam (hati-hati: \"seragam\" bukan sinonimnya)."
  },
  {
    "id": 1311,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"hipotesis\" adalah ...",
    "options": [
      "sepadan",
      "bersifat menggulingkan",
      "kesimpulan akhir",
      "bersifat membujuk",
      "dugaan sementara"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. hipotesis → dugaan sementara (hati-hati: \"kesimpulan akhir\" bukan sinonimnya)."
  },
  {
    "id": 1312,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"kalibrasi\" adalah ...",
    "options": [
      "peneraan",
      "penyimpangan",
      "dominasi",
      "taat asas",
      "pembongkaran"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. kalibrasi → peneraan (hati-hati: \"pembongkaran\" bukan sinonimnya)."
  },
  {
    "id": 1313,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"kompleks\" adalah ...",
    "options": [
      "sederhana",
      "pengurangan dampak",
      "dominasi",
      "hubungan timbal balik",
      "rumit"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. kompleks → rumit (hati-hati: \"sederhana\" bukan sinonimnya)."
  },
  {
    "id": 1314,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"konsisten\" adalah ...",
    "options": [
      "berubah-ubah",
      "taat asas",
      "gamblang",
      "beragam",
      "pertentangan yang tampak"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. konsisten → taat asas (hati-hati: \"berubah-ubah\" bukan sinonimnya)."
  },
  {
    "id": 1315,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"korelasi\" adalah ...",
    "options": [
      "hubungan timbal balik",
      "merusak",
      "mandek",
      "pertentangan",
      "mudah berubah"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. korelasi → hubungan timbal balik (hati-hati: \"pertentangan\" bukan sinonimnya)."
  },
  {
    "id": 1316,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"mitigasi\" adalah ...",
    "options": [
      "taat asas",
      "peningkatan risiko",
      "gamblang",
      "pepatah",
      "pengurangan dampak"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. mitigasi → pengurangan dampak (hati-hati: \"peningkatan risiko\" bukan sinonimnya)."
  },
  {
    "id": 1317,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"obsolet\" adalah ...",
    "options": [
      "rumit",
      "usang",
      "mutakhir",
      "pengurangan dampak",
      "peneraan"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. obsolet → usang (hati-hati: \"mutakhir\" bukan sinonimnya)."
  },
  {
    "id": 1318,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"paradoks\" adalah ...",
    "options": [
      "pertentangan yang tampak",
      "hubungan timbal balik",
      "timbal balik",
      "hak istimewa",
      "kesesuaian"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. paradoks → pertentangan yang tampak (hati-hati: \"kesesuaian\" bukan sinonimnya)."
  },
  {
    "id": 1319,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"persuasif\" adalah ...",
    "options": [
      "gamblang",
      "penyimpangan",
      "sewenang-wenang",
      "memaksa",
      "bersifat membujuk"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. persuasif → bersifat membujuk (hati-hati: \"memaksa\" bukan sinonimnya)."
  },
  {
    "id": 1320,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"prerogatif\" adalah ...",
    "options": [
      "bersifat membujuk",
      "pengurangan dampak",
      "kewajiban",
      "hak istimewa",
      "gamblang"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. prerogatif → hak istimewa (hati-hati: \"kewajiban\" bukan sinonimnya)."
  },
  {
    "id": 1321,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"resiprokal\" adalah ...",
    "options": [
      "timbal balik",
      "hak istimewa",
      "dominasi",
      "searah",
      "acuh tak acuh"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. resiprokal → timbal balik (hati-hati: \"searah\" bukan sinonimnya)."
  },
  {
    "id": 1322,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"signifikan\" adalah ...",
    "options": [
      "remeh",
      "bermakna",
      "timbal balik",
      "bersifat menggulingkan",
      "taat asas"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. signifikan → bermakna (hati-hati: \"remeh\" bukan sinonimnya)."
  },
  {
    "id": 1323,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"stagnan\" adalah ...",
    "options": [
      "bermakna",
      "kesenjangan",
      "mandek",
      "taat asas",
      "berkembang"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. stagnan → mandek (hati-hati: \"berkembang\" bukan sinonimnya)."
  },
  {
    "id": 1324,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"subversif\" adalah ...",
    "options": [
      "bersifat membujuk",
      "membela negara",
      "pepatah",
      "usang",
      "bersifat menggulingkan"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. subversif → bersifat menggulingkan (hati-hati: \"membela negara\" bukan sinonimnya)."
  },
  {
    "id": 1325,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Sinonim kata \"volatil\" adalah ...",
    "options": [
      "dominasi",
      "stabil",
      "peneraan",
      "mudah berubah",
      "gamblang"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. volatil → mudah berubah (hati-hati: \"stabil\" bukan sinonimnya)."
  },
  {
    "id": 1326,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"abstrak\" adalah ...",
    "options": [
      "labil",
      "minimal",
      "samar",
      "konkret",
      "ekstrinsik"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. abstrak → konkret (hati-hati: \"samar\" bukan antonimnya)."
  },
  {
    "id": 1327,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"agresif\" adalah ...",
    "options": [
      "ofensif",
      "labil",
      "pasif",
      "sementara",
      "mendalam"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. agresif → pasif (hati-hati: \"ofensif\" bukan antonimnya)."
  },
  {
    "id": 1328,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"altruis\" adalah ...",
    "options": [
      "mendalam",
      "dermawan",
      "egois",
      "sekunder",
      "mutlak"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. altruis → egois (hati-hati: \"dermawan\" bukan antonimnya)."
  },
  {
    "id": 1329,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"amatir\" adalah ...",
    "options": [
      "kontinu",
      "individual",
      "eksklusif",
      "profesional",
      "pemula"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. amatir → profesional (hati-hati: \"pemula\" bukan antonimnya)."
  },
  {
    "id": 1330,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"apatis\" adalah ...",
    "options": [
      "acuh tak acuh",
      "antusias",
      "homogen",
      "mendalam",
      "profesional"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. apatis → antusias (hati-hati: \"acuh tak acuh\" bukan antonimnya)."
  },
  {
    "id": 1331,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"arif\" adalah ...",
    "options": [
      "bijaksana",
      "sementara",
      "homogen",
      "dungu",
      "pasif"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. arif → dungu (hati-hati: \"bijaksana\" bukan antonimnya)."
  },
  {
    "id": 1332,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"bergeming\" adalah ...",
    "options": [
      "diam",
      "konkret",
      "pasif",
      "mutlak",
      "bergerak"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. bergeming → bergerak (hati-hati: \"diam\" bukan antonimnya)."
  },
  {
    "id": 1333,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"eksplisit\" adalah ...",
    "options": [
      "gamblang",
      "ekstrinsik",
      "implisit",
      "dungu",
      "minimal"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. eksplisit → implisit (hati-hati: \"gamblang\" bukan antonimnya)."
  },
  {
    "id": 1334,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"esensial\" adalah ...",
    "options": [
      "sekunder",
      "minimal",
      "boros",
      "egois",
      "pokok"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. esensial → sekunder (hati-hati: \"pokok\" bukan antonimnya)."
  },
  {
    "id": 1335,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"fana\" adalah ...",
    "options": [
      "homogen",
      "abadi",
      "sementara",
      "sekunder",
      "minimal"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. fana → abadi (hati-hati: \"sementara\" bukan antonimnya)."
  },
  {
    "id": 1336,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"hemat\" adalah ...",
    "options": [
      "kontinu",
      "boros",
      "egois",
      "irit",
      "pasif"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. hemat → boros (hati-hati: \"irit\" bukan antonimnya)."
  },
  {
    "id": 1337,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"heterogen\" adalah ...",
    "options": [
      "mendalam",
      "abadi",
      "homogen",
      "boros",
      "beragam"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. heterogen → homogen (hati-hati: \"beragam\" bukan antonimnya)."
  },
  {
    "id": 1338,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"inklusif\" adalah ...",
    "options": [
      "eksklusif",
      "terbuka",
      "ekstrinsik",
      "terencana",
      "bergerak"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. inklusif → eksklusif (hati-hati: \"terbuka\" bukan antonimnya)."
  },
  {
    "id": 1339,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"intrinsik\" adalah ...",
    "options": [
      "egois",
      "dungu",
      "bawaan",
      "minimal",
      "ekstrinsik"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. intrinsik → ekstrinsik (hati-hati: \"bawaan\" bukan antonimnya)."
  },
  {
    "id": 1340,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"kolektif\" adalah ...",
    "options": [
      "pasif",
      "bersama",
      "eksklusif",
      "individual",
      "profesional"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. kolektif → individual (hati-hati: \"bersama\" bukan antonimnya)."
  },
  {
    "id": 1341,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"mutakhir\" adalah ...",
    "options": [
      "usang",
      "homogen",
      "implisit",
      "terbaru",
      "sekunder"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. mutakhir → usang (hati-hati: \"terbaru\" bukan antonimnya)."
  },
  {
    "id": 1342,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"nisbi\" adalah ...",
    "options": [
      "pasif",
      "mutlak",
      "relatif",
      "usang",
      "implisit"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. nisbi → mutlak (hati-hati: \"relatif\" bukan antonimnya)."
  },
  {
    "id": 1343,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"optimal\" adalah ...",
    "options": [
      "boros",
      "maksimal",
      "labil",
      "implisit",
      "minimal"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. optimal → minimal (hati-hati: \"maksimal\" bukan antonimnya)."
  },
  {
    "id": 1344,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"permanen\" adalah ...",
    "options": [
      "dungu",
      "boros",
      "tetap",
      "labil",
      "sementara"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. permanen → sementara (hati-hati: \"tetap\" bukan antonimnya)."
  },
  {
    "id": 1345,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"progresif\" adalah ...",
    "options": [
      "regresif",
      "eksklusif",
      "egois",
      "maju",
      "sekunder"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. progresif → regresif (hati-hati: \"maju\" bukan antonimnya)."
  },
  {
    "id": 1346,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"superfisial\" adalah ...",
    "options": [
      "dangkal",
      "usang",
      "konkret",
      "mendalam",
      "bergerak"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. superfisial → mendalam (hati-hati: \"dangkal\" bukan antonimnya)."
  },
  {
    "id": 1347,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"transparan\" adalah ...",
    "options": [
      "egois",
      "tertutup",
      "terang",
      "individual",
      "boros"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. transparan → tertutup (hati-hati: \"terang\" bukan antonimnya)."
  },
  {
    "id": 1348,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"sporadis\" adalah ...",
    "options": [
      "eksklusif",
      "antusias",
      "jarang",
      "kontinu",
      "egois"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. sporadis → kontinu (hati-hati: \"jarang\" bukan antonimnya)."
  },
  {
    "id": 1349,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"stabil\" adalah ...",
    "options": [
      "labil",
      "mantap",
      "implisit",
      "bergerak",
      "minimal"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. stabil → labil (hati-hati: \"mantap\" bukan antonimnya)."
  },
  {
    "id": 1350,
    "moduleId": "sinonim",
    "category": "Sinonim & Antonim",
    "question": "Antonim kata \"spontan\" adalah ...",
    "options": [
      "ekstrinsik",
      "boros",
      "serta-merta",
      "eksklusif",
      "terencana"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. spontan → terencana (hati-hati: \"serta-merta\" bukan antonimnya)."
  }
];
