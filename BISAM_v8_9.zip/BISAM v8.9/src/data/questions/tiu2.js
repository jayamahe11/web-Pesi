export const TIU2 = [
  {
    "id": 2701,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 2, 3, 5, 9, 17, 33, ...",
    "options": [
      "63",
      "67",
      "66",
      "65",
      "64"
    ],
    "answer": "D",
    "explanation": "Selisih berurutan 1, 2, 4, 8, 16, lalu 32: 33 + 32 = 65."
  },
  {
    "id": 2702,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 1, 2, 6, 24, 120, ...",
    "options": [
      "700",
      "840",
      "1000",
      "720",
      "600"
    ],
    "answer": "D",
    "explanation": "Faktorial: 1!, 2!, 3!, 4!, 5!, maka berikutnya 6! = 720."
  },
  {
    "id": 2703,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 3, 8, 15, 24, 35, ...",
    "options": [
      "48",
      "50",
      "45",
      "46",
      "49"
    ],
    "answer": "A",
    "explanation": "Pola n^2 - 1 untuk n = 2, 3, ...; berikutnya 7^2 - 1 = 48."
  },
  {
    "id": 2704,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 2, 6, 12, 20, 30, 42, ...",
    "options": [
      "60",
      "56",
      "54",
      "55",
      "58"
    ],
    "answer": "B",
    "explanation": "Pola n(n+1); berikutnya 7 x 8 = 56."
  },
  {
    "id": 2705,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 1, 3, 4, 7, 11, 18, 29, ...",
    "options": [
      "46",
      "47",
      "52",
      "48",
      "45"
    ],
    "answer": "B",
    "explanation": "Setiap suku adalah jumlah dua suku sebelumnya (deret Lucas): 18 + 29 = 47."
  },
  {
    "id": 2706,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 5, 7, 11, 19, 35, ...",
    "options": [
      "67",
      "66",
      "65",
      "69",
      "71"
    ],
    "answer": "A",
    "explanation": "Selisih 2, 4, 8, 16; berikutnya 35 + 32 = 67."
  },
  {
    "id": 2707,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 4, 9, 20, 43, 90, ...",
    "options": [
      "185",
      "187",
      "180",
      "190",
      "183"
    ],
    "answer": "A",
    "explanation": "Pola x2 + 1, x2 + 2, x2 + 3, x2 + 4, lalu x2 + 5: 90 x 2 + 5 = 185."
  },
  {
    "id": 2708,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 2, 5, 4, 10, 8, 20, 16, ...",
    "options": [
      "36",
      "38",
      "32",
      "44",
      "40"
    ],
    "answer": "E",
    "explanation": "Dua deret berselang-seling: 2, 4, 8, 16 (x2) dan 5, 10, 20, 40 (x2)."
  },
  {
    "id": 2709,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 0, 7, 26, 63, 124, ...",
    "options": [
      "215",
      "217",
      "210",
      "216",
      "224"
    ],
    "answer": "A",
    "explanation": "Pola n^3 - 1; berikutnya 6^3 - 1 = 215."
  },
  {
    "id": 2710,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 120, 60, 20, 5, 1, ...",
    "options": [
      "1/4",
      "1/7",
      "0",
      "1/6",
      "1/5"
    ],
    "answer": "D",
    "explanation": "Dibagi 2, 3, 4, 5, lalu 6: 1 : 6 = 1/6."
  },
  {
    "id": 2711,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 2, 12, 36, 80, 150, ...",
    "options": [
      "245",
      "260",
      "252",
      "256",
      "240"
    ],
    "answer": "C",
    "explanation": "Pola n^2(n+1); berikutnya 6^2 x 7 = 252."
  },
  {
    "id": 2712,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Tentukan angka berikutnya dari deret: 1, 4, 10, 22, 46, ...",
    "options": [
      "92",
      "96",
      "98",
      "94",
      "90"
    ],
    "answer": "D",
    "explanation": "Pola x2 + 2: 46 x 2 + 2 = 94."
  },
  {
    "id": 2713,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Pak Ali dapat menyelesaikan suatu pekerjaan dalam 12 hari dan Pak Budi dalam 18 hari. Mereka bekerja bersama selama 4 hari, kemudian Pak Ali berhenti. Sisa pekerjaan diselesaikan Pak Budi sendirian dalam ... hari.",
    "options": [
      "6",
      "9",
      "7",
      "8",
      "10"
    ],
    "answer": "D",
    "explanation": "Dalam 4 hari selesai 4 x (1/12 + 1/18) = 5/9. Sisa 4/9 : 1/18 = 8 hari."
  },
  {
    "id": 2714,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Jarak kota P dan Q adalah 360 km. Mobil A berangkat dari P menuju Q dengan kecepatan 60 km/jam. Satu jam kemudian mobil B berangkat dari Q menuju P dengan kecepatan 90 km/jam. Mereka berpapasan pada jarak ... km dari kota P.",
    "options": [
      "200",
      "180",
      "160",
      "150",
      "210"
    ],
    "answer": "B",
    "explanation": "Saat B berangkat, A sudah menempuh 60 km. Sisa 300 km ditempuh bersama 150 km/jam selama 2 jam. A total 3 jam x 60 = 180 km."
  },
  {
    "id": 2715,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Sebanyak 40 liter larutan alkohol berkadar 30% akan diencerkan dengan air hingga berkadar 20%. Air yang harus ditambahkan adalah ... liter.",
    "options": [
      "16",
      "18",
      "25",
      "24",
      "20"
    ],
    "answer": "E",
    "explanation": "Alkohol 12 liter tetap. Volume akhir 12 : 0,2 = 60 liter, sehingga air tambahan 60 - 40 = 20 liter."
  },
  {
    "id": 2716,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Harga sebuah barang naik 20%, kemudian turun 25%. Dibandingkan harga semula, harga akhir barang tersebut ...",
    "options": [
      "turun 10%",
      "turun 5%",
      "naik 5%",
      "tetap sama",
      "turun 15%"
    ],
    "answer": "A",
    "explanation": "1,2 x 0,75 = 0,9 sehingga turun 10% dari harga semula."
  },
  {
    "id": 2717,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Lima tahun yang lalu umur seorang ayah tujuh kali umur anaknya. Lima tahun yang akan datang umur ayah tiga kali umur anaknya. Umur ayah sekarang adalah ... tahun.",
    "options": [
      "42",
      "35",
      "38",
      "40",
      "45"
    ],
    "answer": "D",
    "explanation": "A - 5 = 7(B - 5) dan A + 5 = 3(B + 5). Diperoleh B = 10 dan A = 40."
  },
  {
    "id": 2718,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Dari 60 siswa, 35 siswa menyukai Matematika, 30 siswa menyukai Fisika, dan 10 siswa tidak menyukai keduanya. Banyak siswa yang menyukai kedua pelajaran tersebut adalah ...",
    "options": [
      "15",
      "20",
      "10",
      "18",
      "12"
    ],
    "answer": "A",
    "explanation": "n(M u F) = 60 - 10 = 50. Irisan = 35 + 30 - 50 = 15."
  },
  {
    "id": 2719,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Banyak susunan huruf yang berbeda dari semua huruf pada kata MATEMATIKA adalah ...",
    "options": [
      "302400",
      "75600",
      "151200",
      "453600",
      "1814400"
    ],
    "answer": "C",
    "explanation": "10! dibagi (2! untuk M, 3! untuk A, 2! untuk T) = 3.628.800 : 24 = 151.200."
  },
  {
    "id": 2720,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Dua dadu dilempar bersamaan. Peluang munculnya jumlah mata dadu 8 atau hasil kali mata dadu 12 adalah ...",
    "options": [
      "1/3",
      "1/4",
      "5/36",
      "1/6",
      "7/36"
    ],
    "answer": "E",
    "explanation": "Jumlah 8: 5 kejadian; hasil kali 12: 4 kejadian; irisan (2,6) dan (6,2): 2 kejadian. 5 + 4 - 2 = 7 dari 36."
  },
  {
    "id": 2721,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Rata-rata nilai ujian 30 siswa kelas A adalah 70 dan rata-rata nilai 20 siswa kelas B adalah 80. Rata-rata nilai gabungan kedua kelas adalah ...",
    "options": [
      "75",
      "74",
      "72",
      "73",
      "76"
    ],
    "answer": "B",
    "explanation": "(30 x 70 + 20 x 80) : 50 = 3.700 : 50 = 74."
  },
  {
    "id": 2722,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Rina menabung Rp5.000.000,00 dengan bunga majemuk 10% per tahun. Setelah 2 tahun, jumlah tabungan Rina adalah ...",
    "options": [
      "Rp5.500.000,00",
      "Rp6.250.000,00",
      "Rp6.050.000,00",
      "Rp6.100.000,00",
      "Rp6.000.000,00"
    ],
    "answer": "C",
    "explanation": "5.000.000 x (1,1)^2 = 6.050.000."
  },
  {
    "id": 2723,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Delapan pekerja dapat menyelesaikan suatu proyek dalam 18 hari. Setelah bekerja 6 hari, dua orang pekerja berhenti. Sisa proyek akan selesai dalam ... hari lagi.",
    "options": [
      "14",
      "16",
      "18",
      "20",
      "12"
    ],
    "answer": "B",
    "explanation": "Total 144 hari-pekerja. Terpakai 48, sisa 96. Dengan 6 pekerja: 96 : 6 = 16 hari."
  },
  {
    "id": 2724,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Sebuah mobil menempuh perjalanan pergi dengan kecepatan 60 km/jam dan pulang melalui jalur yang sama dengan kecepatan 40 km/jam. Kecepatan rata-rata seluruh perjalanan adalah ... km/jam.",
    "options": [
      "52",
      "45",
      "50",
      "48",
      "55"
    ],
    "answer": "D",
    "explanation": "Kecepatan rata-rata = 2 x 60 x 40 : (60 + 40) = 48 km/jam (bukan rata-rata hitung)."
  },
  {
    "id": 2725,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Semua dokter adalah lulusan S1. Sebagian lulusan S1 adalah dosen. Kesimpulan yang pasti benar adalah ...",
    "options": [
      "Sebagian dokter adalah dosen",
      "Semua lulusan S1 adalah dokter",
      "Tidak ada dokter yang menjadi dosen",
      "Sebagian dosen adalah lulusan S1",
      "Semua dosen adalah dokter"
    ],
    "answer": "D",
    "explanation": "Dari 'sebagian lulusan S1 adalah dosen' dapat dikonversi menjadi 'sebagian dosen adalah lulusan S1'. Hubungan dokter-dosen tidak dapat ditentukan."
  },
  {
    "id": 2726,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Semua pegawai kontrak adalah peserta pelatihan. Tidak ada peserta pelatihan yang mendapat cuti. Kesimpulan yang pasti benar adalah ...",
    "options": [
      "Sebagian peserta pelatihan mendapat cuti",
      "Semua peserta pelatihan adalah pegawai kontrak",
      "Semua yang mendapat cuti adalah pegawai kontrak",
      "Sebagian pegawai kontrak mendapat cuti",
      "Tidak ada pegawai kontrak yang mendapat cuti"
    ],
    "answer": "E",
    "explanation": "Pegawai kontrak termasuk peserta pelatihan, sedangkan peserta pelatihan tidak ada yang bercuti."
  },
  {
    "id": 2727,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Jika harga BBM naik, maka inflasi naik. Jika inflasi naik, maka daya beli menurun. Ternyata daya beli tidak menurun. Kesimpulan yang tepat adalah ...",
    "options": [
      "Harga BBM naik",
      "Harga BBM tidak naik",
      "Harga BBM naik tetapi inflasi tetap",
      "Inflasi naik",
      "Daya beli menurun karena BBM"
    ],
    "answer": "B",
    "explanation": "Modus tollens berantai: daya beli tidak menurun, maka inflasi tidak naik, maka harga BBM tidak naik."
  },
  {
    "id": 2728,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Lima orang (Ayu, Bayu, Candra, Dina, Eko) duduk berjajar pada lima kursi bernomor 1-5 dari kiri ke kanan. Ayu duduk di salah satu ujung. Bayu duduk tepat di sebelah kanan Candra. Dina tidak duduk bersebelahan dengan Ayu. Eko duduk tepat di sebelah kiri Candra. Orang yang duduk di kursi nomor 3 adalah ...",
    "options": [
      "Bayu",
      "Ayu",
      "Eko",
      "Candra",
      "Dina"
    ],
    "answer": "D",
    "explanation": "Eko-Candra-Bayu berurutan. Ayu di ujung dan Dina tidak di sebelah Ayu, sehingga Dina di ujung lainnya dan blok tiga orang menempati kursi 2-4 (Candra di kursi 3)."
  },
  {
    "id": 2729,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Lima kota (P, Q, R, S, T) dikunjungi satu per satu dalam lima hari berurutan. Kota R dikunjungi sebelum kota P, dan kota P dikunjungi sebelum kota Q. Kota S dikunjungi tepat sehari setelah kota T. Kota T tidak dikunjungi sebelum kota R. Kota Q tidak dikunjungi pada hari keempat. Pernyataan yang PASTI benar adalah ...",
    "options": [
      "kota T dikunjungi pada hari keempat",
      "kota Q dikunjungi pada hari kelima",
      "kota R dikunjungi pada hari pertama",
      "kota P dikunjungi pada hari kedua",
      "kota S dikunjungi pada hari kelima"
    ],
    "answer": "C",
    "explanation": "Susunan yang mungkin: R-P-Q-T-S, R-P-T-S-Q, dan R-T-S-P-Q. Hanya 'R pada hari pertama' yang berlaku di semua susunan."
  },
  {
    "id": 2730,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Hadiah disimpan di salah satu dari tiga kotak. Label kotak 1: 'Hadiah ada di kotak ini'. Label kotak 2: 'Hadiah tidak ada di kotak ini'. Label kotak 3: 'Hadiah tidak ada di kotak 1'. Diketahui hanya satu label yang benar. Hadiah berada di ...",
    "options": [
      "kotak 3",
      "kotak 1",
      "kotak 2",
      "kotak 1 atau kotak 3",
      "tidak dapat ditentukan"
    ],
    "answer": "C",
    "explanation": "Hanya jika hadiah di kotak 2 tepat satu label (label kotak 3) yang benar."
  },
  {
    "id": 2731,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Empat tersangka memberi keterangan. A: 'B pencurinya.' B: 'C pencurinya.' C: 'B berbohong.' D: 'Bukan saya pencurinya.' Pencuri hanya satu orang dan hanya satu keterangan yang benar. Pencurinya adalah ...",
    "options": [
      "tidak dapat ditentukan",
      "A",
      "C",
      "D",
      "B"
    ],
    "answer": "D",
    "explanation": "Hanya jika D pencurinya, tepat satu keterangan (milik C) yang benar."
  },
  {
    "id": 2732,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Negasi dari pernyataan 'Jika hujan turun, maka terjadi banjir' adalah ...",
    "options": [
      "Jika tidak hujan, maka tidak terjadi banjir",
      "Hujan turun dan tidak terjadi banjir",
      "Jika terjadi banjir, maka hujan turun",
      "Hujan tidak turun atau terjadi banjir",
      "Tidak hujan dan terjadi banjir"
    ],
    "answer": "B",
    "explanation": "Negasi p -> q adalah p dan bukan q."
  },
  {
    "id": 2733,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Rina lebih berat daripada Sari. Tika lebih ringan daripada Sari. Umi lebih berat daripada Rina. Vina lebih ringan daripada Rina tetapi lebih berat daripada Sari. Orang dengan berat badan terbesar ketiga adalah ...",
    "options": [
      "Vina",
      "Rina",
      "Tika",
      "Sari",
      "Umi"
    ],
    "answer": "A",
    "explanation": "Urutan: Umi > Rina > Vina > Sari > Tika."
  },
  {
    "id": 2734,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Jika kemarin lusa adalah hari Jumat, maka 100 hari lagi dari besok adalah hari ...",
    "options": [
      "Senin",
      "Kamis",
      "Jumat",
      "Rabu",
      "Selasa"
    ],
    "answer": "D",
    "explanation": "Hari ini Minggu, besok Senin. 100 mod 7 = 2 sehingga Senin + 2 hari = Rabu."
  },
  {
    "id": 2735,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Dalam suatu sandi, BUKU dikodekan menjadi CTLT. Dengan aturan yang sama, MEJA dikodekan menjadi ...",
    "options": [
      "MDKZ",
      "NFKB",
      "LDIZ",
      "NDKA",
      "NDKZ"
    ],
    "answer": "E",
    "explanation": "Huruf ganjil digeser +1 dan huruf genap digeser -1: M->N, E->D, J->K, A->Z."
  },
  {
    "id": 2736,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Diketahui operasi a * b = a^2 - 2b. Nilai (3 * 2) * 4 adalah ...",
    "options": [
      "13",
      "9",
      "21",
      "25",
      "17"
    ],
    "answer": "E",
    "explanation": "3 * 2 = 9 - 4 = 5; 5 * 4 = 25 - 8 = 17."
  },
  {
    "id": 2737,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Pernyataan 'Tidak semua pejabat jujur' ekuivalen dengan ...",
    "options": [
      "Semua pejabat tidak jujur",
      "Ada pejabat yang tidak jujur",
      "Ada pejabat yang jujur",
      "Tidak ada pejabat yang jujur",
      "Semua pejabat jujur"
    ],
    "answer": "B",
    "explanation": "Negasi dari 'semua jujur' adalah 'ada yang tidak jujur'."
  },
  {
    "id": 2738,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "HAKIM : VONIS = ARSITEK : ...",
    "options": [
      "rancangan",
      "semen",
      "gedung",
      "pasir",
      "mandor"
    ],
    "answer": "A",
    "explanation": "Hakim menghasilkan vonis; arsitek menghasilkan rancangan."
  },
  {
    "id": 2739,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "TERMOMETER : SUHU = BAROMETER : ...",
    "options": [
      "kecepatan angin",
      "kelembapan",
      "tekanan udara",
      "ketinggian",
      "curah hujan"
    ],
    "answer": "C",
    "explanation": "Alat ukur dan besaran yang diukur: barometer mengukur tekanan udara."
  },
  {
    "id": 2740,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "ANTIBIOTIK : BAKTERI = ANTIVIRUS : ...",
    "options": [
      "aplikasi",
      "malware",
      "peretas",
      "jaringan",
      "server"
    ],
    "answer": "B",
    "explanation": "Antibiotik melawan bakteri; antivirus melawan perangkat lunak berbahaya."
  },
  {
    "id": 2741,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "OPTIMIS : PESIMIS = PROGRESIF : ...",
    "options": [
      "modern",
      "reformis",
      "konservatif",
      "liberal",
      "dinamis"
    ],
    "answer": "C",
    "explanation": "Pasangan antonim."
  },
  {
    "id": 2742,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "PRAKTIK : TEORI = EKSPERIMEN : ...",
    "options": [
      "laboratorium",
      "hipotesis",
      "kesimpulan",
      "variabel",
      "ilmuwan"
    ],
    "answer": "B",
    "explanation": "Praktik menguji teori; eksperimen menguji hipotesis."
  },
  {
    "id": 2743,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Sinonim kata EFEMERAL adalah ...",
    "options": [
      "sesaat",
      "mendasar",
      "luas",
      "abadi",
      "rumit"
    ],
    "answer": "A",
    "explanation": "Efemeral berarti berlangsung singkat/tidak kekal."
  },
  {
    "id": 2744,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Sinonim kata IMPLISIT adalah ...",
    "options": [
      "tegas",
      "tersirat",
      "gamblang",
      "terang-terangan",
      "nyata"
    ],
    "answer": "B",
    "explanation": "Implisit = tersirat; lawannya eksplisit."
  },
  {
    "id": 2745,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Sinonim kata KOMPREHENSIF adalah ...",
    "options": [
      "sepintas",
      "parsial",
      "terpisah",
      "menyeluruh",
      "mendasar"
    ],
    "answer": "D",
    "explanation": "Komprehensif berarti mencakup secara luas dan menyeluruh."
  },
  {
    "id": 2746,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Antonim kata ALTRUIS adalah ...",
    "options": [
      "murah hati",
      "dermawan",
      "egois",
      "penolong",
      "simpatik"
    ],
    "answer": "C",
    "explanation": "Altruis mementingkan orang lain; lawannya egois."
  },
  {
    "id": 2747,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Antonim kata ABSTRAK adalah ...",
    "options": [
      "umum",
      "konkret",
      "samar",
      "teoretis",
      "ilmiah"
    ],
    "answer": "B",
    "explanation": "Abstrak tidak berwujud; konkret dapat diamati."
  },
  {
    "id": 2748,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Antonim kata DEGRADASI adalah ...",
    "options": [
      "kerusakan",
      "pemerosotan",
      "penurunan",
      "kemunduran",
      "peningkatan"
    ],
    "answer": "E",
    "explanation": "Degradasi berarti penurunan mutu; lawannya peningkatan."
  },
  {
    "id": 2749,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Inflasi yang terkendali mendorong investasi karena pelaku usaha dapat memperkirakan biaya produksi. Sebaliknya, deflasi berkepanjangan menahan konsumsi karena masyarakat menunda belanja sambil menunggu harga turun. Kesimpulan yang paling tepat adalah ...",
    "options": [
      "kestabilan harga yang dapat diperkirakan menopang aktivitas ekonomi, sedangkan deflasi berkepanjangan menekan konsumsi",
      "inflasi yang tinggi pasti mendorong investasi",
      "investasi tidak dipengaruhi pergerakan harga",
      "deflasi selalu lebih baik daripada inflasi",
      "konsumsi meningkat ketika harga terus turun"
    ],
    "answer": "A",
    "explanation": "Paragraf menekankan prediktabilitas harga bagi investasi dan efek negatif deflasi berkepanjangan terhadap konsumsi."
  },
  {
    "id": 2750,
    "moduleId": "tiu2",
    "category": "TIU#2",
    "question": "Setiap hasil survei yang dipublikasikan berasal dari sampel. Sampel yang tidak diambil secara acak berpotensi menimbulkan bias. Survei X memakai sampel relawan yang mendaftarkan diri sendiri. Kesimpulan yang paling tepat adalah ...",
    "options": [
      "survei X berpotensi bias",
      "survei X tidak berasal dari sampel",
      "semua survei bias",
      "sampel acak selalu menghasilkan nilai yang sempurna",
      "survei X pasti salah"
    ],
    "answer": "A",
    "explanation": "Relawan yang mendaftar sendiri bukan sampel acak, sehingga hasilnya berpotensi bias (bukan pasti salah)."
  }
];
