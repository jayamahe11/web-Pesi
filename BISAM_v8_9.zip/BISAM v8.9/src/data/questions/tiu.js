export const TIU = [
  {
    "id": 2201,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Jika 3x + 5 = 26, nilai x adalah ...",
    "options": [
      "5",
      "6",
      "7",
      "8",
      "9"
    ],
    "answer": "C",
    "explanation": "3x = 21, jadi x = 7."
  },
  {
    "id": 2202,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "25% dari 360 adalah ...",
    "options": [
      "80",
      "90",
      "100",
      "110",
      "120"
    ],
    "answer": "B",
    "explanation": "25% × 360 = 90."
  },
  {
    "id": 2203,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Deret 2, 5, 10, 17, 26, ... angka berikutnya adalah ...",
    "options": [
      "33",
      "35",
      "36",
      "37",
      "39"
    ],
    "answer": "D",
    "explanation": "Selisihnya 3,5,7,9, lalu 11. Jadi 26 + 11 = 37."
  },
  {
    "id": 2204,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Perbandingan uang Andi:Budi = 3:5. Jika total Rp320.000, uang Andi adalah ...",
    "options": [
      "Rp100.000",
      "Rp110.000",
      "Rp120.000",
      "Rp140.000",
      "Rp200.000"
    ],
    "answer": "C",
    "explanation": "3/8 × 320.000 = 120.000."
  },
  {
    "id": 2205,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "8 orang menyelesaikan pekerjaan dalam 15 hari. Jika dikerjakan 12 orang dengan kecepatan sama, diperlukan ...",
    "options": [
      "8 hari",
      "9 hari",
      "10 hari",
      "11 hari",
      "12 hari"
    ],
    "answer": "C",
    "explanation": "8×15 = 120 orang-hari, lalu 120/12 = 10 hari."
  },
  {
    "id": 2206,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Rata-rata 72, 68, 80, 75, dan 85 adalah ...",
    "options": [
      "74",
      "75",
      "76",
      "77",
      "78"
    ],
    "answer": "C",
    "explanation": "Jumlah 380, dibagi 5 = 76."
  },
  {
    "id": 2207,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Barang Rp250.000 didiskon 20%. Harga akhirnya ...",
    "options": [
      "Rp180.000",
      "Rp190.000",
      "Rp200.000",
      "Rp210.000",
      "Rp220.000"
    ],
    "answer": "C",
    "explanation": "Diskon 50.000, jadi 200.000."
  },
  {
    "id": 2208,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "4 buku seharga Rp60.000. Harga 7 buku dengan harga satuan sama ...",
    "options": [
      "Rp95.000",
      "Rp100.000",
      "Rp105.000",
      "Rp110.000",
      "Rp115.000"
    ],
    "answer": "C",
    "explanation": "Harga satu buku 15.000, jadi 7 buku = 105.000."
  },
  {
    "id": 2209,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Deret 81, 27, 9, 3, ...",
    "options": [
      "0",
      "1",
      "2",
      "3",
      "6"
    ],
    "answer": "B",
    "explanation": "Setiap suku dibagi 3."
  },
  {
    "id": 2210,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Jika 2a = 3b dan b = 8, maka a = ...",
    "options": [
      "10",
      "11",
      "12",
      "13",
      "14"
    ],
    "answer": "C",
    "explanation": "2a = 24, jadi a = 12."
  },
  {
    "id": 2211,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Sinonim kata 'cermat' adalah ...",
    "options": [
      "Ceroboh",
      "Teliti",
      "Cepat",
      "Keras",
      "Ragu"
    ],
    "answer": "B",
    "explanation": "Cermat berarti teliti."
  },
  {
    "id": 2212,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Antonim kata 'optimistis' adalah ...",
    "options": [
      "Realistis",
      "Praktis",
      "Pesimistis",
      "Idealis",
      "Aktif"
    ],
    "answer": "C",
    "explanation": "Lawan kata optimistis adalah pesimistis."
  },
  {
    "id": 2213,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Dokter : rumah sakit = Guru : ...",
    "options": [
      "Kantor",
      "Sekolah",
      "Pasar",
      "Terminal",
      "Bengkel"
    ],
    "answer": "B",
    "explanation": "Hubungan profesi dan tempat kerja."
  },
  {
    "id": 2214,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Pensil : menulis = Gunting : ...",
    "options": [
      "Menghapus",
      "Menggambar",
      "Memotong",
      "Mengukur",
      "Menempel"
    ],
    "answer": "C",
    "explanation": "Hubungan alat dan fungsi."
  },
  {
    "id": 2215,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Semua pegawai disiplin. Sebagian pegawai adalah atlet. Kesimpulan pasti benar ...",
    "options": [
      "Semua atlet disiplin",
      "Sebagian atlet disiplin",
      "Tidak ada atlet disiplin",
      "Semua pegawai atlet",
      "Sebagian pegawai tidak disiplin"
    ],
    "answer": "B",
    "explanation": "Pegawai yang juga atlet termasuk kelompok pegawai yang semuanya disiplin."
  },
  {
    "id": 2216,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Semua mawar adalah bunga. Tidak ada bunga yang dapat berbicara. Maka ...",
    "options": [
      "Semua yang berbicara adalah mawar",
      "Sebagian mawar dapat berbicara",
      "Tidak ada mawar yang dapat berbicara",
      "Semua bunga adalah mawar",
      "Sebagian bunga bukan mawar"
    ],
    "answer": "C",
    "explanation": "Mawar termasuk bunga dan tidak ada bunga yang dapat berbicara."
  },
  {
    "id": 2217,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Jika hari ini Senin, 45 hari lagi adalah ...",
    "options": [
      "Senin",
      "Selasa",
      "Rabu",
      "Kamis",
      "Jumat"
    ],
    "answer": "D",
    "explanation": "45 mod 7 = 3, tiga hari setelah Senin adalah Kamis."
  },
  {
    "id": 2218,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Mobil menempuh 180 km dalam 3 jam. Kecepatannya ...",
    "options": [
      "50 km/jam",
      "55 km/jam",
      "60 km/jam",
      "65 km/jam",
      "70 km/jam"
    ],
    "answer": "C",
    "explanation": "180/3 = 60 km/jam."
  },
  {
    "id": 2219,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "5 mesin menghasilkan 500 unit dalam 4 jam. 10 mesin menghasilkan 1.000 unit dalam ...",
    "options": [
      "1 jam",
      "2 jam",
      "3 jam",
      "4 jam",
      "5 jam"
    ],
    "answer": "D",
    "explanation": "Mesin dan target sama-sama dua kali, jadi waktu tetap."
  },
  {
    "id": 2220,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "3/4 + 2/3 = ...",
    "options": [
      "13/12",
      "15/12",
      "17/12",
      "19/12",
      "21/12"
    ],
    "answer": "C",
    "explanation": "9/12 + 8/12 = 17/12."
  },
  {
    "id": 2221,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "√1296 = ...",
    "options": [
      "32",
      "34",
      "36",
      "38",
      "40"
    ],
    "answer": "C",
    "explanation": "36×36 = 1296."
  },
  {
    "id": 2222,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Persegi panjang 12 cm × 7 cm memiliki luas ...",
    "options": [
      "72 cm²",
      "78 cm²",
      "84 cm²",
      "90 cm²",
      "96 cm²"
    ],
    "answer": "C",
    "explanation": "12×7 = 84."
  },
  {
    "id": 2223,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Keliling persegi 48 cm. Luasnya ...",
    "options": [
      "121 cm²",
      "132 cm²",
      "144 cm²",
      "156 cm²",
      "169 cm²"
    ],
    "answer": "C",
    "explanation": "Sisi 12 cm, luas 144 cm²."
  },
  {
    "id": 2224,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Deret 4, 7, 13, 22, 34, ...",
    "options": [
      "46",
      "47",
      "48",
      "49",
      "50"
    ],
    "answer": "D",
    "explanation": "Selisih 3,6,9,12, lalu 15."
  },
  {
    "id": 2225,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Deret huruf A, C, F, J, O, ...",
    "options": [
      "S",
      "T",
      "U",
      "V",
      "W"
    ],
    "answer": "C",
    "explanation": "Lompatan +2,+3,+4,+5,+6."
  },
  {
    "id": 2226,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "40% dari suatu bilangan adalah 72. Bilangan tersebut ...",
    "options": [
      "160",
      "170",
      "180",
      "190",
      "200"
    ],
    "answer": "C",
    "explanation": "72/0,4 = 180."
  },
  {
    "id": 2227,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Tabungan Rp2.000.000 berbunga sederhana 6% per tahun. Bunga selama 2 tahun ...",
    "options": [
      "Rp120.000",
      "Rp180.000",
      "Rp200.000",
      "Rp240.000",
      "Rp260.000"
    ],
    "answer": "D",
    "explanation": "2.000.000 × 6% × 2 = 240.000."
  },
  {
    "id": 2228,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Umur Ayah 42 dan anak 14. Berapa tahun lagi umur Ayah dua kali umur anak?",
    "options": [
      "10",
      "12",
      "14",
      "16",
      "18"
    ],
    "answer": "C",
    "explanation": "42+x = 2(14+x), sehingga x = 14."
  },
  {
    "id": 2229,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Kelas berisi 18 laki-laki dan 12 perempuan. Persentase perempuan ...",
    "options": [
      "30%",
      "35%",
      "40%",
      "45%",
      "50%"
    ],
    "answer": "C",
    "explanation": "12/30 × 100% = 40%."
  },
  {
    "id": 2230,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Jika x:y = 4:7 dan y:z = 14:15, maka x:y:z = ...",
    "options": [
      "4:7:15",
      "8:14:15",
      "8:7:15",
      "4:14:15",
      "8:14:30"
    ],
    "answer": "B",
    "explanation": "Samakan y menjadi 14: 8:14 dan 14:15."
  },
  {
    "id": 2231,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Semua auditor teliti. Rina auditor. Maka ...",
    "options": [
      "Rina belum tentu teliti",
      "Rina teliti",
      "Rina bukan auditor",
      "Semua yang teliti auditor",
      "Tidak dapat disimpulkan"
    ],
    "answer": "B",
    "explanation": "Rina termasuk auditor, dan semua auditor teliti."
  },
  {
    "id": 2232,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Tidak satu pun ikan adalah mamalia. Paus adalah mamalia. Maka ...",
    "options": [
      "Paus adalah ikan",
      "Paus bukan ikan",
      "Semua mamalia paus",
      "Sebagian ikan paus",
      "Paus bukan mamalia"
    ],
    "answer": "B",
    "explanation": "Paus mamalia, jadi bukan ikan menurut premis."
  },
  {
    "id": 2233,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "KOMPOR : PANAS = KULKAS : ...",
    "options": [
      "Air",
      "Dingin",
      "Es",
      "Makanan",
      "Listrik"
    ],
    "answer": "B",
    "explanation": "Hubungan alat dan kondisi yang dihasilkan."
  },
  {
    "id": 2234,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Antonim 'abstrak' adalah ...",
    "options": [
      "Samar",
      "Konseptual",
      "Konkret",
      "Rumit",
      "Umum"
    ],
    "answer": "C",
    "explanation": "Abstrak berlawanan dengan konkret."
  },
  {
    "id": 2235,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Sebuah angka dinaikkan 20% menjadi 96. Nilai awal ...",
    "options": [
      "72",
      "76",
      "80",
      "84",
      "88"
    ],
    "answer": "C",
    "explanation": "1,2x = 96, jadi x = 80."
  },
  {
    "id": 2236,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "15² - 12² = ...",
    "options": [
      "69",
      "75",
      "81",
      "87",
      "91"
    ],
    "answer": "C",
    "explanation": "225 - 144 = 81."
  },
  {
    "id": 2237,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "6 pekerja membuat 90 kursi dalam 5 hari. Produksi rata-rata per pekerja per hari ...",
    "options": [
      "2",
      "3",
      "4",
      "5",
      "6"
    ],
    "answer": "B",
    "explanation": "90/(6×5)=3."
  },
  {
    "id": 2238,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Median dari 3, 8, 5, 11, 9 adalah ...",
    "options": [
      "5",
      "7",
      "8",
      "9",
      "11"
    ],
    "answer": "C",
    "explanation": "Urutkan 3,5,8,9,11."
  },
  {
    "id": 2239,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Peluang muncul sisi angka pada koin seimbang adalah ...",
    "options": [
      "1/4",
      "1/3",
      "1/2",
      "2/3",
      "3/4"
    ],
    "answer": "C",
    "explanation": "Dua sisi memiliki peluang sama."
  },
  {
    "id": 2240,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Dalam kantong ada 3 bola merah dan 2 biru. Peluang mengambil bola biru ...",
    "options": [
      "1/5",
      "2/5",
      "1/2",
      "3/5",
      "4/5"
    ],
    "answer": "B",
    "explanation": "2 dari total 5 bola."
  },
  {
    "id": 2241,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Deret 1, 4, 9, 16, 25, ...",
    "options": [
      "30",
      "32",
      "34",
      "36",
      "49"
    ],
    "answer": "D",
    "explanation": "Deret kuadrat, berikutnya 6² = 36."
  },
  {
    "id": 2242,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Deret 3, 6, 12, 24, ...",
    "options": [
      "36",
      "42",
      "48",
      "54",
      "60"
    ],
    "answer": "C",
    "explanation": "Dikali 2."
  },
  {
    "id": 2243,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Tangki terisi 3/5 dari 250 liter. Isinya ...",
    "options": [
      "100 L",
      "125 L",
      "150 L",
      "175 L",
      "200 L"
    ],
    "answer": "C",
    "explanation": "3/5 × 250 = 150."
  },
  {
    "id": 2244,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Harga naik dari Rp80.000 menjadi Rp92.000. Persentase kenaikan ...",
    "options": [
      "10%",
      "12%",
      "15%",
      "18%",
      "20%"
    ],
    "answer": "C",
    "explanation": "Naik 12.000 dari 80.000 = 15%."
  },
  {
    "id": 2245,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Jika 7x - 9 = 40, maka x = ...",
    "options": [
      "5",
      "6",
      "7",
      "8",
      "9"
    ],
    "answer": "C",
    "explanation": "7x=49, jadi x=7."
  },
  {
    "id": 2246,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Bus berangkat 08.15 dan tiba 11.45. Lama perjalanan ...",
    "options": [
      "3 jam",
      "3 jam 15 menit",
      "3 jam 30 menit",
      "3 jam 45 menit",
      "4 jam"
    ],
    "answer": "C",
    "explanation": "Selisih waktunya 3 jam 30 menit."
  },
  {
    "id": 2247,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Semua peserta yang lulus mendapat sertifikat. Dedi tidak mendapat sertifikat. Maka ...",
    "options": [
      "Dedi pasti lulus",
      "Dedi tidak lulus",
      "Dedi mungkin lulus",
      "Semua bersertifikat lulus",
      "Tidak ada kesimpulan"
    ],
    "answer": "B",
    "explanation": "Kontraposisi: tidak mendapat sertifikat → tidak lulus."
  },
  {
    "id": 2248,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Buku : perpustakaan = Kendaraan : ...",
    "options": [
      "Jalan",
      "Garasi",
      "Mesin",
      "Bensin",
      "Pengemudi"
    ],
    "answer": "B",
    "explanation": "Hubungan benda dan tempat penyimpanan."
  },
  {
    "id": 2249,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "2,5 kg gula seharga Rp40.000. Harga 4 kg ...",
    "options": [
      "Rp56.000",
      "Rp60.000",
      "Rp64.000",
      "Rp68.000",
      "Rp72.000"
    ],
    "answer": "C",
    "explanation": "Harga/kg 16.000; 4 kg = 64.000."
  },
  {
    "id": 2250,
    "moduleId": "tiu",
    "category": "TIU",
    "question": "Bilangan terbesar di antara 0,45; 45%; 4/9; dan 0,46 adalah ...",
    "options": [
      "0,45",
      "45%",
      "4/9",
      "0,46",
      "Sama"
    ],
    "answer": "D",
    "explanation": "0,46 lebih besar daripada 0,45 dan 4/9≈0,444."
  }
];
