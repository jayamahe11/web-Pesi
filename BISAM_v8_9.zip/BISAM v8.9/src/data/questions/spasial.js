export const SPASIAL = [
  {
    "id": 1901,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Rani menghadap ke Barat Laut. Ia berputar di tempat: 90° ke kanan, lalu 135° ke kiri, lalu berbalik arah (180°), lalu 90° ke kanan, lalu 90° ke kanan. Sekarang Rani menghadap ke ...",
    "options": [
      "Tenggara",
      "Timur",
      "Timur Laut",
      "Barat",
      "Utara"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Setiap putaran ke kanan = searah jarum jam. Hitung total putaran bersih (45° = 1 langkah) dari arah awal."
  },
  {
    "id": 1902,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Salsa menghadap ke Timur Laut. Ia berputar di tempat: 135° ke kiri, lalu 90° ke kanan, lalu 135° ke kanan, lalu berbalik arah (180°), lalu berbalik arah (180°). Sekarang Salsa menghadap ke ...",
    "options": [
      "Timur Laut",
      "Timur",
      "Tenggara",
      "Selatan",
      "Utara"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Setiap putaran ke kanan = searah jarum jam. Hitung total putaran bersih (45° = 1 langkah) dari arah awal."
  },
  {
    "id": 1903,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Rani menghadap ke Selatan. Ia berputar di tempat: 45° ke kiri, lalu 90° ke kiri, lalu 135° ke kanan, lalu 90° ke kanan. Sekarang Rani menghadap ke ...",
    "options": [
      "Tenggara",
      "Timur Laut",
      "Barat",
      "Utara",
      "Timur"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Setiap putaran ke kanan = searah jarum jam. Hitung total putaran bersih (45° = 1 langkah) dari arah awal."
  },
  {
    "id": 1904,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Dino menghadap ke Timur. Ia berputar di tempat: 90° ke kiri, lalu 45° ke kiri, lalu 45° ke kanan, lalu 90° ke kanan. Sekarang Dino menghadap ke ...",
    "options": [
      "Timur",
      "Timur Laut",
      "Tenggara",
      "Selatan",
      "Utara"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Setiap putaran ke kanan = searah jarum jam. Hitung total putaran bersih (45° = 1 langkah) dari arah awal."
  },
  {
    "id": 1905,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Dino menghadap ke Timur. Ia berputar di tempat: 45° ke kanan, lalu 90° ke kiri, lalu 90° ke kiri, lalu berbalik arah (180°). Sekarang Dino menghadap ke ...",
    "options": [
      "Selatan",
      "Timur",
      "Tenggara",
      "Timur Laut",
      "Utara"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Setiap putaran ke kanan = searah jarum jam. Hitung total putaran bersih (45° = 1 langkah) dari arah awal."
  },
  {
    "id": 1906,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Salsa menghadap ke Barat Laut. Ia berputar di tempat: 45° ke kanan, lalu 45° ke kanan, lalu berbalik arah (180°), lalu 90° ke kiri, lalu 45° ke kiri. Sekarang Salsa menghadap ke ...",
    "options": [
      "Timur",
      "Tenggara",
      "Selatan",
      "Timur Laut",
      "Utara"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Setiap putaran ke kanan = searah jarum jam. Hitung total putaran bersih (45° = 1 langkah) dari arah awal."
  },
  {
    "id": 1907,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Seorang kurir berjalan 9 m ke arah utara, kemudian berjalan 10 m ke arah timur, kemudian berjalan 3 m ke arah selatan, kemudian berjalan 10 m ke arah barat. Jarak garis lurus dari titik awal ke posisi akhirnya adalah ... m.",
    "options": [
      "3",
      "10",
      "7",
      "6",
      "5"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Posisi akhir (x, y) = (0, 6); jarak = √(0²+6²) = 6 m."
  },
  {
    "id": 1908,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Seorang kurir berjalan 11 m ke arah utara, kemudian berjalan 5 m ke arah timur, kemudian berjalan 9 m ke arah selatan, kemudian berjalan 5 m ke arah barat. Jarak garis lurus dari titik awal ke posisi akhirnya adalah ... m.",
    "options": [
      "5",
      "8",
      "2",
      "7",
      "1"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Posisi akhir (x, y) = (0, 2); jarak = √(0²+2²) = 2 m."
  },
  {
    "id": 1909,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Seorang kurir berjalan 4 m ke arah utara, kemudian berjalan 8 m ke arah timur, kemudian berjalan 4 m ke arah selatan, kemudian berjalan 5 m ke arah timur. Jarak garis lurus dari titik awal ke posisi akhirnya adalah ... m.",
    "options": [
      "16",
      "10",
      "14",
      "15",
      "13"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Posisi akhir (x, y) = (13, 0); jarak = √(13²+0²) = 13 m."
  },
  {
    "id": 1910,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Seorang kurir berjalan 8 m ke arah utara, kemudian berjalan 4 m ke arah timur, kemudian berjalan 4 m ke arah utara, kemudian berjalan 4 m ke arah barat. Jarak garis lurus dari titik awal ke posisi akhirnya adalah ... m.",
    "options": [
      "14",
      "12",
      "8",
      "16",
      "11"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Posisi akhir (x, y) = (0, 12); jarak = √(0²+12²) = 12 m."
  },
  {
    "id": 1911,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Seorang kurir berjalan 2 m ke arah utara, kemudian berjalan 2 m ke arah barat, kemudian berjalan 2 m ke arah selatan, kemudian berjalan 9 m ke arah timur. Jarak garis lurus dari titik awal ke posisi akhirnya adalah ... m.",
    "options": [
      "7",
      "8",
      "6",
      "11",
      "10"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Posisi akhir (x, y) = (7, 0); jarak = √(7²+0²) = 7 m."
  },
  {
    "id": 1912,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Seorang kurir berjalan 11 m ke arah utara, kemudian berjalan 5 m ke arah barat, kemudian berjalan 11 m ke arah selatan. Jarak garis lurus dari titik awal ke posisi akhirnya adalah ... m.",
    "options": [
      "9",
      "8",
      "5",
      "6",
      "2"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Posisi akhir (x, y) = (-5, 0); jarak = √(-5²+0²) = 5 m."
  },
  {
    "id": 1913,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah balok berukuran 3×4×7 tersusun dari kubus satuan, seluruh permukaan luarnya dicat, lalu dibongkar menjadi kubus satuan. Banyak kubus satuan yang terkena cat tepat pada 1 sisi adalah ...",
    "options": [
      "46",
      "34",
      "37",
      "40",
      "31"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Rumus balok: 1 sisi = 2[(p−2)(q−2)+(q−2)(r−2)+(p−2)(r−2)]; 2 sisi = 4[(p−2)+(q−2)+(r−2)]; 0 sisi = (p−2)(q−2)(r−2)."
  },
  {
    "id": 1914,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah balok berukuran 3×4×6 tersusun dari kubus satuan, seluruh permukaan luarnya dicat, lalu dibongkar menjadi kubus satuan. Banyak kubus satuan yang terkena cat tepat pada 2 sisi adalah ...",
    "options": [
      "20",
      "28",
      "30",
      "34",
      "24"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Rumus balok: 1 sisi = 2[(p−2)(q−2)+(q−2)(r−2)+(p−2)(r−2)]; 2 sisi = 4[(p−2)+(q−2)+(r−2)]; 0 sisi = (p−2)(q−2)(r−2)."
  },
  {
    "id": 1915,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah balok berukuran 3×6×8 tersusun dari kubus satuan, seluruh permukaan luarnya dicat, lalu dibongkar menjadi kubus satuan. Banyak kubus satuan yang tidak terkena cat sama sekali adalah ...",
    "options": [
      "24",
      "20",
      "28",
      "22",
      "32"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Rumus balok: 1 sisi = 2[(p−2)(q−2)+(q−2)(r−2)+(p−2)(r−2)]; 2 sisi = 4[(p−2)+(q−2)+(r−2)]; 0 sisi = (p−2)(q−2)(r−2)."
  },
  {
    "id": 1916,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah balok berukuran 6×7×8 tersusun dari kubus satuan, seluruh permukaan luarnya dicat, lalu dibongkar menjadi kubus satuan. Banyak kubus satuan yang terkena cat tepat pada 1 sisi adalah ...",
    "options": [
      "204",
      "190",
      "134",
      "148",
      "92"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Rumus balok: 1 sisi = 2[(p−2)(q−2)+(q−2)(r−2)+(p−2)(r−2)]; 2 sisi = 4[(p−2)+(q−2)+(r−2)]; 0 sisi = (p−2)(q−2)(r−2)."
  },
  {
    "id": 1917,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah kubus 5×5×5 tersusun dari kubus satuan. Hanya sisi atas dan sisi bawah kubus besar yang dicat, lalu kubus dibongkar. Banyak kubus satuan yang terkena cat adalah ...",
    "options": [
      "60",
      "40",
      "70",
      "65",
      "50"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Hanya lapisan atas dan bawah yang terkena cat: 2 × 5² = 50."
  },
  {
    "id": 1918,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah kubus 6×6×6 tersusun dari kubus satuan. Hanya sisi atas dan sisi bawah kubus besar yang dicat, lalu kubus dibongkar. Banyak kubus satuan yang terkena cat adalah ...",
    "options": [
      "72",
      "60",
      "48",
      "96",
      "66"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Hanya lapisan atas dan bawah yang terkena cat: 2 × 6² = 72."
  },
  {
    "id": 1919,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah kubus 6×6×6 tersusun dari kubus satuan dan seluruh permukaannya dicat. Jika semua kubus satuan yang terkena cat dilepas, banyak kubus satuan yang tersisa adalah ...",
    "options": [
      "70",
      "58",
      "40",
      "64",
      "76"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Yang tersisa adalah inti (6−2)³ = 64."
  },
  {
    "id": 1920,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah kubus 5×5×5 tersusun dari kubus satuan dan seluruh permukaannya dicat. Jika semua kubus satuan yang terkena cat dilepas, banyak kubus satuan yang tersisa adalah ...",
    "options": [
      "47",
      "32",
      "42",
      "12",
      "27"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Yang tersisa adalah inti (5−2)³ = 27."
  },
  {
    "id": 1921,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Bayangan sebuah jam dinding pada cermin menunjukkan pukul 3:30. Pukul berapakah waktu sebenarnya?",
    "options": [
      "8:30",
      "3:24",
      "8:37",
      "8:27",
      "3:20"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Waktu sebenarnya = 11:60 − waktu bayangan (pada jam 12-an)."
  },
  {
    "id": 1922,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Berapa derajat sudut terkecil antara jarum jam dan jarum menit pada pukul 3:43?",
    "options": [
      "151,5°",
      "131,5°",
      "144°",
      "161,5°",
      "146,5°"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. |30×3 − 5,5×43| = 146,5°."
  },
  {
    "id": 1923,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Bayangan sebuah jam dinding pada cermin menunjukkan pukul 4:05. Pukul berapakah waktu sebenarnya?",
    "options": [
      "4:50",
      "4:45",
      "7:56",
      "4:51",
      "7:55"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Waktu sebenarnya = 11:60 − waktu bayangan (pada jam 12-an)."
  },
  {
    "id": 1924,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Berapa derajat sudut terkecil antara jarum jam dan jarum menit pada pukul 9:35?",
    "options": [
      "80°",
      "77,5°",
      "82,5°",
      "67,5°",
      "87,5°"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. |30×9 − 5,5×35| = 77,5°."
  },
  {
    "id": 1925,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Bayangan sebuah jam dinding pada cermin menunjukkan pukul 8:35. Pukul berapakah waktu sebenarnya?",
    "options": [
      "5:25",
      "3:25",
      "3:34",
      "8:21",
      "9:25"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Waktu sebenarnya = 11:60 − waktu bayangan (pada jam 12-an)."
  },
  {
    "id": 1926,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Berapa derajat sudut terkecil antara jarum jam dan jarum menit pada pukul 7:29?",
    "options": [
      "40,5°",
      "60,5°",
      "50,5°",
      "35,5°",
      "53°"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. |30×7 − 5,5×29| = 50,5°."
  },
  {
    "id": 1927,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Bayangan sebuah jam dinding pada cermin menunjukkan pukul 9:36. Pukul berapakah waktu sebenarnya?",
    "options": [
      "9:17",
      "9:34",
      "2:24",
      "11:24",
      "2:14"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Waktu sebenarnya = 11:60 − waktu bayangan (pada jam 12-an)."
  },
  {
    "id": 1928,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Berapa derajat sudut terkecil antara jarum jam dan jarum menit pada pukul 8:24?",
    "options": [
      "98°",
      "123°",
      "108°",
      "113°",
      "93°"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. |30×8 − 5,5×24| = 108°."
  },
  {
    "id": 1929,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Selembar kertas persegi dilipat dua kali: pertama menurut garis tengah vertikal, kedua menurut garis tengah horizontal (menjadi 4 lapis). Kemudian kertas dilubangi di 3 titik pada bagian dalam (tidak menyentuh lipatan), 0 titik tepat pada salah satu sisi lipatan (bukan di pusat), dan 0 titik tepat pada pojok yang merupakan pertemuan kedua lipatan. Setelah dibuka kembali, banyak lubang pada kertas adalah ...",
    "options": [
      "12",
      "10",
      "9",
      "16",
      "14"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Titik di dalam menjadi 4 lubang, di garis lipatan menjadi 2 lubang, di pusat menjadi 1: 4×3 + 2×0 + 0 = 12."
  },
  {
    "id": 1930,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Selembar kertas persegi dilipat dua kali: pertama menurut garis tengah vertikal, kedua menurut garis tengah horizontal (menjadi 4 lapis). Kemudian kertas dilubangi di 2 titik pada bagian dalam (tidak menyentuh lipatan), 1 titik tepat pada salah satu sisi lipatan (bukan di pusat), dan 0 titik tepat pada pojok yang merupakan pertemuan kedua lipatan. Setelah dibuka kembali, banyak lubang pada kertas adalah ...",
    "options": [
      "9",
      "12",
      "8",
      "10",
      "7"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Titik di dalam menjadi 4 lubang, di garis lipatan menjadi 2 lubang, di pusat menjadi 1: 4×2 + 2×1 + 0 = 10."
  },
  {
    "id": 1931,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Selembar kertas persegi dilipat dua kali: pertama menurut garis tengah vertikal, kedua menurut garis tengah horizontal (menjadi 4 lapis). Kemudian kertas dilubangi di 0 titik pada bagian dalam (tidak menyentuh lipatan), 2 titik tepat pada salah satu sisi lipatan (bukan di pusat), dan 1 titik tepat pada pojok yang merupakan pertemuan kedua lipatan. Setelah dibuka kembali, banyak lubang pada kertas adalah ...",
    "options": [
      "7",
      "2",
      "5",
      "4",
      "6"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Titik di dalam menjadi 4 lubang, di garis lipatan menjadi 2 lubang, di pusat menjadi 1: 4×0 + 2×2 + 1 = 5."
  },
  {
    "id": 1932,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Selembar kertas persegi dilipat dua kali: pertama menurut garis tengah vertikal, kedua menurut garis tengah horizontal (menjadi 4 lapis). Kemudian kertas dilubangi di 3 titik pada bagian dalam (tidak menyentuh lipatan), 1 titik tepat pada salah satu sisi lipatan (bukan di pusat), dan 0 titik tepat pada pojok yang merupakan pertemuan kedua lipatan. Setelah dibuka kembali, banyak lubang pada kertas adalah ...",
    "options": [
      "13",
      "14",
      "17",
      "10",
      "12"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Titik di dalam menjadi 4 lubang, di garis lipatan menjadi 2 lubang, di pusat menjadi 1: 4×3 + 2×1 + 0 = 14."
  },
  {
    "id": 1933,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Selembar kertas persegi dilipat dua kali: pertama menurut garis tengah vertikal, kedua menurut garis tengah horizontal (menjadi 4 lapis). Kemudian kertas dilubangi di 1 titik pada bagian dalam (tidak menyentuh lipatan), 1 titik tepat pada salah satu sisi lipatan (bukan di pusat), dan 1 titik tepat pada pojok yang merupakan pertemuan kedua lipatan. Setelah dibuka kembali, banyak lubang pada kertas adalah ...",
    "options": [
      "7",
      "11",
      "5",
      "6",
      "10"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Titik di dalam menjadi 4 lubang, di garis lipatan menjadi 2 lubang, di pusat menjadi 1: 4×1 + 2×1 + 1 = 7."
  },
  {
    "id": 1934,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Selembar kertas persegi dilipat dua kali: pertama menurut garis tengah vertikal, kedua menurut garis tengah horizontal (menjadi 4 lapis). Kemudian kertas dilubangi di 3 titik pada bagian dalam (tidak menyentuh lipatan), 2 titik tepat pada salah satu sisi lipatan (bukan di pusat), dan 0 titik tepat pada pojok yang merupakan pertemuan kedua lipatan. Setelah dibuka kembali, banyak lubang pada kertas adalah ...",
    "options": [
      "19",
      "16",
      "12",
      "20",
      "15"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Titik di dalam menjadi 4 lubang, di garis lipatan menjadi 2 lubang, di pusat menjadi 1: 4×3 + 2×2 + 0 = 16."
  },
  {
    "id": 1935,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (-6, 7) berturut-turut dicerminkan terhadap sumbu X, kemudian dicerminkan terhadap garis y = x, kemudian dicerminkan terhadap sumbu Y. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(-7, -6)",
      "(7, -7)",
      "(8, -6)",
      "(-7, 6)",
      "(7, -6)"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1936,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (4, 2) berturut-turut dicerminkan terhadap sumbu X, kemudian digeser 3 satuan ke kanan dan 2 satuan ke bawah, kemudian dicerminkan terhadap sumbu Y. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(-7, 0)",
      "(-6, -4)",
      "(-7, -4)",
      "(7, -4)",
      "(-7, -5)"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1937,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (1, -3) berturut-turut diputar 90° berlawanan arah jarum jam terhadap titik asal, kemudian dicerminkan terhadap sumbu Y, kemudian dicerminkan terhadap garis y = x. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(-1, 3)",
      "(-1, -3)",
      "(1, -4)",
      "(2, -3)",
      "(1, -3)"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1938,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (1, 4) berturut-turut dicerminkan terhadap sumbu Y, kemudian dicerminkan terhadap garis y = x, kemudian dicerminkan terhadap sumbu X. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(4, 0)",
      "(4, 1)",
      "(5, 1)",
      "(-4, 1)",
      "(-4, -1)"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1939,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (7, 4) berturut-turut diputar 90° berlawanan arah jarum jam terhadap titik asal, kemudian dicerminkan terhadap sumbu Y, kemudian dicerminkan terhadap garis y = x. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(-7, 4)",
      "(7, 3)",
      "(8, 4)",
      "(-7, -4)",
      "(7, 4)"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1940,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (5, 4) berturut-turut dicerminkan terhadap sumbu Y, kemudian dicerminkan terhadap garis y = x, kemudian diputar 90° berlawanan arah jarum jam terhadap titik asal. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(-5, -4)",
      "(6, 4)",
      "(5, 3)",
      "(5, 4)",
      "(-5, 4)"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1941,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (-4, -1) berturut-turut dicerminkan terhadap sumbu X, kemudian digeser 3 satuan ke kanan dan 2 satuan ke bawah, kemudian diputar 90° berlawanan arah jarum jam terhadap titik asal. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(-1, -1)",
      "(2, -1)",
      "(2, -6)",
      "(1, -2)",
      "(1, -1)"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1942,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Titik (-4, 8) berturut-turut diputar 180° terhadap titik asal, kemudian dicerminkan terhadap sumbu Y, kemudian dicerminkan terhadap garis y = x. Koordinat bayangan akhirnya adalah ...",
    "options": [
      "(-8, -5)",
      "(-7, -4)",
      "(-8, -4)",
      "(8, -4)",
      "(8, 4)"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Lakukan transformasi satu per satu sesuai urutan; urutan yang berbeda memberi hasil berbeda."
  },
  {
    "id": 1943,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah balok memiliki panjang 12 cm, lebar 18 cm, dan tinggi 36 cm. Panjang diagonal ruangnya adalah ... cm.",
    "options": [
      "45",
      "38",
      "43",
      "42",
      "41"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. √(12²+18²+36²) = 42."
  },
  {
    "id": 1944,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Diagonal ruang sebuah balok adalah 30 cm. Jika panjang dan lebarnya masing-masing 4 cm dan 20 cm, tinggi balok adalah ... cm.",
    "options": [
      "23",
      "26",
      "21",
      "22",
      "19"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. c = √(30²−4²−20²) = 22."
  },
  {
    "id": 1945,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Luas permukaan balok berukuran 8 cm × 8 cm × 14 cm adalah ... cm².",
    "options": [
      "492",
      "632",
      "464",
      "576",
      "688"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 2(pl+pt+lt) = 576."
  },
  {
    "id": 1946,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Jumlah panjang seluruh rusuk balok berukuran 12 cm × 12 cm × 14 cm adalah ... cm.",
    "options": [
      "152",
      "156",
      "148",
      "164",
      "168"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. 4(p+l+t) = 152."
  },
  {
    "id": 1947,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Sebuah balok memiliki panjang 4 cm, lebar 12 cm, dan tinggi 18 cm. Panjang diagonal ruangnya adalah ... cm.",
    "options": [
      "19",
      "23",
      "25",
      "22",
      "26"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. √(4²+12²+18²) = 22."
  },
  {
    "id": 1948,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Diagonal ruang sebuah balok adalah 42 cm. Jika panjang dan lebarnya masing-masing 12 cm dan 18 cm, tinggi balok adalah ... cm.",
    "options": [
      "39",
      "36",
      "35",
      "40",
      "38"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. c = √(42²−12²−18²) = 36."
  },
  {
    "id": 1949,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Luas permukaan balok berukuran 6 cm × 9 cm × 18 cm adalah ... cm².",
    "options": [
      "712",
      "520",
      "648",
      "744",
      "552"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 2(pl+pt+lt) = 648."
  },
  {
    "id": 1950,
    "moduleId": "spasial",
    "category": "Spasial",
    "question": "Jumlah panjang seluruh rusuk balok berukuran 6 cm × 8 cm × 24 cm adalah ... cm.",
    "options": [
      "148",
      "152",
      "168",
      "144",
      "136"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 4(p+l+t) = 152."
  }
];
