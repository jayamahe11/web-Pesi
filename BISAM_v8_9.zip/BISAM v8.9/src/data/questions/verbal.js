export const VERBAL = [
  {
    "id": 1201,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "terampil, konkrit, persentase, jadwal",
      "terampil, konkret, persentase, jadual",
      "trampil, konkret, persentase, jadwal",
      "terampil, konkret, prosentase, jadwal",
      "terampil, konkret, persentase, jadwal"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bentuk baku: terampil (bukan trampil), konkret (bukan konkrit), persentase (bukan prosentase), jadwal (bukan jadual)."
  },
  {
    "id": 1202,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "detail, frekuensi, atlit, cabai",
      "detil, frekuensi, atlet, cabai",
      "detail, frekuensi, atlet, cabai",
      "detail, frekwensi, atlet, cabai",
      "detail, frekuensi, atlet, cabe"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Bentuk baku: detail (bukan detil), frekuensi (bukan frekwensi), atlet (bukan atlit), cabai (bukan cabe)."
  },
  {
    "id": 1203,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "mazhab, apotek, persentase, andal",
      "mazhab, apotik, persentase, andal",
      "mazhab, apotek, prosentase, andal",
      "madzhab, apotek, persentase, andal",
      "mazhab, apotek, persentase, handal"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Bentuk baku: mazhab (bukan madzhab), apotek (bukan apotik), persentase (bukan prosentase), andal (bukan handal)."
  },
  {
    "id": 1204,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "lembap, sekedar, antre, karisma",
      "lembab, sekadar, antre, karisma",
      "lembap, sekadar, antri, karisma",
      "lembap, sekadar, antre, kharisma",
      "lembap, sekadar, antre, karisma"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bentuk baku: lembap (bukan lembab), sekadar (bukan sekedar), antre (bukan antri), karisma (bukan kharisma)."
  },
  {
    "id": 1205,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "atlet, kualitas, aktivitas, salat",
      "atlit, kualitas, aktivitas, salat",
      "atlet, kualitas, aktifitas, salat",
      "atlet, kualitas, aktivitas, shalat",
      "atlet, kwalitas, aktivitas, salat"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Bentuk baku: atlet (bukan atlit), kualitas (bukan kwalitas), aktivitas (bukan aktifitas), salat (bukan shalat)."
  },
  {
    "id": 1206,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "karisma, bis, praktik, manajemen",
      "karisma, bus, praktik, manejemen",
      "kharisma, bus, praktik, manajemen",
      "karisma, bus, praktek, manajemen",
      "karisma, bus, praktik, manajemen"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bentuk baku: karisma (bukan kharisma), bus (bukan bis), praktik (bukan praktek), manajemen (bukan manejemen)."
  },
  {
    "id": 1207,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "cabai, terampil, shalat, Februari",
      "cabai, trampil, salat, Februari",
      "cabai, terampil, salat, Pebruari",
      "cabe, terampil, salat, Februari",
      "cabai, terampil, salat, Februari"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bentuk baku: cabai (bukan cabe), terampil (bukan trampil), salat (bukan shalat), Februari (bukan Pebruari)."
  },
  {
    "id": 1208,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "bus, silakan, adzan, subjek",
      "bis, silakan, azan, subjek",
      "bus, silahkan, azan, subjek",
      "bus, silakan, azan, subyek",
      "bus, silakan, azan, subjek"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bentuk baku: bus (bukan bis), silakan (bukan silahkan), azan (bukan adzan), subjek (bukan subyek)."
  },
  {
    "id": 1209,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "efektif, antre, hembus, frekuensi",
      "efektif, antre, embus, frekwensi",
      "efektif, antri, embus, frekuensi",
      "efektif, antre, embus, frekuensi",
      "efektip, antre, embus, frekuensi"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bentuk baku: efektif (bukan efektip), antre (bukan antri), embus (bukan hembus), frekuensi (bukan frekwensi)."
  },
  {
    "id": 1210,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "mazhab, azan, jadwal, subjek",
      "mazhab, adzan, jadwal, subjek",
      "mazhab, azan, jadwal, subyek",
      "madzhab, azan, jadwal, subjek",
      "mazhab, azan, jadual, subjek"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Bentuk baku: mazhab (bukan madzhab), azan (bukan adzan), jadwal (bukan jadual), subjek (bukan subyek)."
  },
  {
    "id": 1211,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "kualitas, imbau, praktik, zaman",
      "kualitas, imbau, praktek, zaman",
      "kwalitas, imbau, praktik, zaman",
      "kualitas, imbau, praktik, jaman",
      "kualitas, himbau, praktik, zaman"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Bentuk baku: kualitas (bukan kwalitas), imbau (bukan himbau), praktik (bukan praktek), zaman (bukan jaman)."
  },
  {
    "id": 1212,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "cabai, kuitansi, Nopember, kompleks",
      "cabai, kuitansi, November, komplek",
      "cabe, kuitansi, November, kompleks",
      "cabai, kuitansi, November, kompleks",
      "cabai, kwitansi, November, kompleks"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bentuk baku: cabai (bukan cabe), kuitansi (bukan kwitansi), November (bukan Nopember), kompleks (bukan komplek)."
  },
  {
    "id": 1213,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "miliar, efektif, kompleks, apotek",
      "miliar, efektif, komplek, apotek",
      "milyar, efektif, kompleks, apotek",
      "miliar, efektip, kompleks, apotek",
      "miliar, efektif, kompleks, apotik"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Bentuk baku: miliar (bukan milyar), efektif (bukan efektip), kompleks (bukan komplek), apotek (bukan apotik)."
  },
  {
    "id": 1214,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "hakikat, konkret, karisma, ekstrim",
      "hakikat, konkret, kharisma, ekstrem",
      "hakikat, konkret, karisma, ekstrem",
      "hakekat, konkret, karisma, ekstrem",
      "hakikat, konkrit, karisma, ekstrem"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Bentuk baku: hakikat (bukan hakekat), konkret (bukan konkrit), karisma (bukan kharisma), ekstrem (bukan ekstrim)."
  },
  {
    "id": 1215,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kelompok kata berikut yang SELURUHNYA berejaan baku (sesuai KBBI/PUEBI) adalah ...",
    "options": [
      "imbau, November, obyek, risiko",
      "imbau, November, objek, risiko",
      "imbau, Nopember, objek, risiko",
      "imbau, November, objek, resiko",
      "himbau, November, objek, risiko"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Bentuk baku: imbau (bukan himbau), November (bukan Nopember), objek (bukan obyek), risiko (bukan resiko)."
  },
  {
    "id": 1216,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Pemerintah daerah akan membangun jembatan baru tahun depan.",
      "Pemerintah daerah-daerah akan membangun jembatan baru tahun depan.",
      "Pemerintah daerah, akan membangun jembatan baru tahun depan.",
      "Pemerintah daerah akan melakukan pembangunan membangun jembatan baru tahun depan.",
      "Pemerintah daerah akan segera membangun jembatan baru yang baru tahun depan."
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Kalimat efektif tidak berlebihan kata (pleonasme) dan tidak memisahkan subjek-predikat dengan koma."
  },
  {
    "id": 1217,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Tugas pegawai itu menerima tamu, mencatat pesan, dan jadwal pimpinan diatur.",
      "Tugas pegawai itu menerima tamu, mencatat pesan, dan mengatur jadwal pimpinan.",
      "Tugas pegawai itu menerima tamu, pesan dicatat, dan juga mengatur jadwal pimpinan.",
      "Tugas pegawai itu adalah menerima tamu, mencatat pesan, serta pengaturan jadwal pimpinan.",
      "Tugas pegawai itu menerima tamu, pencatatan pesan, dan mengatur jadwal pimpinan."
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Rincian harus paralel: ketiganya berbentuk verba aktif me-."
  },
  {
    "id": 1218,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Membaca laporan itu, proyek ditunda oleh direktur.",
      "Setelah laporan itu dibaca, direktur itu dia memutuskan menunda proyek.",
      "Laporan itu setelah dibaca oleh direktur memutuskan untuk menunda proyek.",
      "Setelah membaca laporan itu, direktur memutuskan untuk menunda proyek.",
      "Dengan membaca laporan itu menyebabkan direktur memutuskan menunda proyek."
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Subjek anak kalimat dan induk kalimat harus sama dan jelas."
  },
  {
    "id": 1219,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Kota tempat ia dilahirkan kini menjadi pusat perdagangan.",
      "Kota yang mana ia dilahirkan kini menjadi pusat perdagangan.",
      "Kota dimana ia dilahirkan kini menjadi pusat perdagangan.",
      "Kota tempat dimana ia dilahirkan kini menjadi pusat perdagangan.",
      "Kota di mana ia dilahirkan kini menjadi pusat perdagangan."
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Penggunaan 'di mana' dan 'yang mana' sebagai penghubung bukan kaidah bahasa Indonesia; gunakan 'tempat'."
  },
  {
    "id": 1220,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Panitia membahas masalah keamanan daripada dalam rapat kemarin.",
      "Panitia membahas mengenai tentang masalah keamanan dalam rapat kemarin.",
      "Panitia membahas tentang masalah keamanan dalam rapat kemarin.",
      "Panitia membahas masalah keamanan dalam rapat kemarin.",
      "Panitia membahas akan masalah keamanan dalam rapat kemarin."
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Verba transitif tidak diikuti preposisi 'tentang/mengenai/akan'."
  },
  {
    "id": 1221,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Banyak mahasiswa-mahasiswa mengikuti seminar nasional itu.",
      "Banyak para mahasiswa mengikuti seminar nasional itu.",
      "Banyak mahasiswa mengikuti seminar nasional itu.",
      "Para banyak mahasiswa mengikuti seminar nasional itu.",
      "Banyak dari mahasiswa mengikuti seminar nasional itu."
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 'Banyak' sudah menyatakan jamak, sehingga 'para' dan bentuk ulang menjadi mubazir."
  },
  {
    "id": 1222,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Karena hujan deras, sehingga pertandingan ditunda.",
      "Karena hujan deras maka akibatnya pertandingan ditunda.",
      "Disebabkan karena hujan deras, pertandingan ditunda.",
      "Karena hujan deras, pertandingan ditunda.",
      "Hujan deras, karena itu pertandingan, ditunda."
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Anak kalimat tidak boleh diikuti 'sehingga'; 'disebabkan karena' adalah pleonasme."
  },
  {
    "id": 1223,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kalimat yang efektif adalah ...",
    "options": [
      "Hasil penelitian itu menunjukkan bahwa adalah kualitas air sungai menurun.",
      "Dari hasil penelitian itu menunjukkan bahwa kualitas air sungai menurun.",
      "Hasil penelitian itu menunjukkan bahwa kualitas air sungai itu telah menurun menurun.",
      "Hasil penelitian itu menunjukkan, bahwa kualitas air sungai menurun.",
      "Hasil penelitian itu menunjukkan bahwa kualitas air sungai menurun."
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Subjek tidak boleh didahului preposisi, dan tidak ada koma sebelum 'bahwa'."
  },
  {
    "id": 1224,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Anjing menggonggong kafilah berlalu\" adalah ...",
    "options": [
      "ada maksud tersembunyi di balik suatu perbuatan",
      "orang yang dipercaya menjaga justru merusak",
      "berwawasan sempit karena kurang pengalaman",
      "kritik tidak menghalangi tujuan yang tetap dijalankan",
      "pengeluaran lebih besar daripada pendapatan"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Anjing menggonggong kafilah berlalu: kritik tidak menghalangi tujuan yang tetap dijalankan."
  },
  {
    "id": 1225,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Pagar makan tanaman\" adalah ...",
    "options": [
      "orang yang dipercaya menjaga justru merusak",
      "berbuat jahat lalu menyembunyikan diri",
      "tidak ada manusia yang sempurna",
      "membuka aib keluarga sendiri berarti mempermalukan diri sendiri",
      "sangat mirip atau serasi"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pagar makan tanaman: orang yang dipercaya menjaga justru merusak."
  },
  {
    "id": 1226,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Berat sama dipikul, ringan sama dijinjing\" adalah ...",
    "options": [
      "setelah dimanfaatkan lalu ditinggalkan",
      "menanggung suka dan duka bersama-sama",
      "sangat mirip atau serasi",
      "sekali bekerja beberapa tujuan tercapai",
      "kritik tidak menghalangi tujuan yang tetap dijalankan"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Berat sama dipikul, ringan sama dijinjing: menanggung suka dan duka bersama-sama."
  },
  {
    "id": 1227,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Tak ada gading yang tak retak\" adalah ...",
    "options": [
      "tidak ada manusia yang sempurna",
      "menghadapi pilihan sulit karena keduanya berakibat buruk",
      "setelah dimanfaatkan lalu ditinggalkan",
      "sekali bekerja beberapa tujuan tercapai",
      "orang yang dipercaya menjaga justru merusak"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Tak ada gading yang tak retak: tidak ada manusia yang sempurna."
  },
  {
    "id": 1228,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Seperti makan buah simalakama\" adalah ...",
    "options": [
      "menghadapi pilihan sulit karena keduanya berakibat buruk",
      "berbuat jahat lalu menyembunyikan diri",
      "tidak ada manusia yang sempurna",
      "orang yang banyak bicara biasanya kurang berilmu",
      "sangat mirip atau serasi"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Seperti makan buah simalakama: menghadapi pilihan sulit karena keduanya berakibat buruk."
  },
  {
    "id": 1229,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Besar pasak daripada tiang\" adalah ...",
    "options": [
      "pengeluaran lebih besar daripada pendapatan",
      "berwawasan sempit karena kurang pengalaman",
      "ada maksud tersembunyi di balik suatu perbuatan",
      "melupakan asal-usul atau jasa orang lain",
      "menanggung suka dan duka bersama-sama"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Besar pasak daripada tiang: pengeluaran lebih besar daripada pendapatan."
  },
  {
    "id": 1230,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Bagai air di daun talas\" adalah ...",
    "options": [
      "membuka aib keluarga sendiri berarti mempermalukan diri sendiri",
      "pengeluaran lebih besar daripada pendapatan",
      "sekali bekerja beberapa tujuan tercapai",
      "ada maksud tersembunyi di balik suatu perbuatan",
      "tidak berpendirian tetap"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bagai air di daun talas: tidak berpendirian tetap."
  },
  {
    "id": 1231,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Makna peribahasa \"Air beriak tanda tak dalam\" adalah ...",
    "options": [
      "tidak ada manusia yang sempurna",
      "orang yang banyak bicara biasanya kurang berilmu",
      "tidak berpendirian tetap",
      "menanggung suka dan duka bersama-sama",
      "menghadapi pilihan sulit karena keduanya berakibat buruk"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Air beriak tanda tak dalam: orang yang banyak bicara biasanya kurang berilmu."
  },
  {
    "id": 1232,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"gadget\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "daring",
      "tetikus",
      "gawai",
      "unduh",
      "pranala"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. gadget = gawai."
  },
  {
    "id": 1233,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"online\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "nirkabel",
      "unduh",
      "unggah",
      "pindai",
      "daring"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. online = daring."
  },
  {
    "id": 1234,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"e-mail\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "unduh",
      "daring",
      "surel",
      "nirkabel",
      "gawai"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. e-mail = surel."
  },
  {
    "id": 1235,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"offline\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "pranala",
      "tetikus",
      "daring",
      "luring",
      "peretas"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. offline = luring."
  },
  {
    "id": 1236,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"server\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "pranala",
      "tetikus",
      "surel",
      "peladen",
      "nirkabel"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. server = peladen."
  },
  {
    "id": 1237,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"scan\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "nirkabel",
      "daring",
      "pindai",
      "unggah",
      "pranala"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. scan = pindai."
  },
  {
    "id": 1238,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"download\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "peretas",
      "unduh",
      "pindai",
      "peladen",
      "gawai"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. download = unduh."
  },
  {
    "id": 1239,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Padanan kata asing \"upload\" dalam bahasa Indonesia yang tepat adalah ...",
    "options": [
      "surel",
      "pranala",
      "nirkabel",
      "luring",
      "unggah"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. upload = unggah."
  },
  {
    "id": 1240,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Urbanisasi yang tidak terkendali menimbulkan banyak persoalan di kota besar. Permukiman kumuh tumbuh di bantaran sungai, lalu lintas semakin macet, dan kebutuhan air bersih sulit dipenuhi. Di sisi lain, desa kehilangan tenaga muda yang produktif sehingga pertanian tertinggal. Pemerataan pembangunan menjadi kunci untuk menekan arus perpindahan penduduk. Gagasan utama paragraf tersebut adalah ...",
    "options": [
      "Desa kehilangan tenaga muda karena pertanian tertinggal.",
      "Urbanisasi tak terkendali menimbulkan masalah di kota dan desa sehingga diperlukan pemerataan pembangunan.",
      "Permukiman kumuh tumbuh di bantaran sungai akibat urbanisasi.",
      "Pemerataan pembangunan hanya dibutuhkan di wilayah perdesaan.",
      "Kota besar adalah pusat kemacetan terparah di Indonesia."
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Gagasan utama/simpulan harus mencakup keseluruhan isi paragraf, bukan hanya satu rincian."
  },
  {
    "id": 1241,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "(1) Membaca buku secara rutin melatih konsentrasi. (2) Konsentrasi yang terlatih membantu seseorang memahami teks yang panjang. (3) Harga buku di toko daring berbeda-beda setiap bulan. (4) Pemahaman yang baik pada akhirnya meningkatkan kemampuan menulis. Kalimat yang tidak padu dengan gagasan paragraf tersebut adalah ...",
    "options": [
      "kalimat (1)",
      "kalimat (4)",
      "kalimat (2)",
      "semua kalimat padu",
      "kalimat (3)"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Gagasan utama/simpulan harus mencakup keseluruhan isi paragraf, bukan hanya satu rincian."
  },
  {
    "id": 1242,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Penelitian di tiga kota menunjukkan bahwa siswa yang sarapan sebelum berangkat memiliki konsentrasi lebih baik pada jam pelajaran pertama. Namun, siswa yang sarapan dengan makanan tinggi gula justru cepat mengantuk sebelum istirahat. Peneliti menyimpulkan bahwa jenis sarapan sama pentingnya dengan kebiasaan sarapan itu sendiri. Pernyataan yang sesuai dengan isi paragraf tersebut adalah ...",
    "options": [
      "Penelitian itu dilakukan hanya di satu kota.",
      "Kebiasaan sarapan tidak berpengaruh terhadap konsentrasi.",
      "Semua siswa yang sarapan pasti berkonsentrasi baik.",
      "Siswa yang tidak sarapan lebih segar saat istirahat.",
      "Sarapan tinggi gula dapat membuat siswa cepat mengantuk."
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Gagasan utama/simpulan harus mencakup keseluruhan isi paragraf, bukan hanya satu rincian."
  },
  {
    "id": 1243,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Sungai-sungai di kota kerap dianggap tempat pembuangan. Padahal, sungai yang sehat menjadi sumber air baku, ruang rekreasi, sekaligus penyangga banjir. Komunitas peduli sungai di beberapa daerah membuktikan bahwa kerja bersama warga mampu memulihkan aliran yang tercemar. Judul yang paling tepat untuk paragraf tersebut adalah ...",
    "options": [
      "Sejarah Komunitas Peduli Sungai",
      "Memulihkan Sungai Kota melalui Kerja Bersama Warga",
      "Pemerintah dan Pencemaran Air Baku",
      "Sungai sebagai Tempat Rekreasi Keluarga",
      "Penyebab Banjir di Perkotaan"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Gagasan utama/simpulan harus mencakup keseluruhan isi paragraf, bukan hanya satu rincian."
  },
  {
    "id": 1244,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Kopi arabika tumbuh baik di dataran tinggi dengan suhu sejuk, sedangkan robusta lebih tahan di dataran rendah yang hangat. Karena itu, petani di kaki gunung umumnya menanam arabika, sementara petani pesisir memilih robusta. Perbedaan lokasi ini juga memengaruhi cita rasa: arabika cenderung asam dan harum, robusta lebih pahit. Simpulan yang paling tepat dari paragraf tersebut adalah ...",
    "options": [
      "Robusta tidak dapat tumbuh di dataran tinggi.",
      "Arabika lebih pahit daripada robusta.",
      "Semua jenis kopi tumbuh baik di dataran rendah.",
      "Lokasi tanam memengaruhi jenis kopi yang dipilih petani sekaligus cita rasanya.",
      "Petani pesisir hanya menanam arabika."
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Gagasan utama/simpulan harus mencakup keseluruhan isi paragraf, bukan hanya satu rincian."
  },
  {
    "id": 1245,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Bahasa daerah menyimpan pengetahuan lokal yang tidak tercatat dalam buku. Nama-nama tumbuhan obat, cara membaca musim, hingga aturan adat disampaikan melalui bahasa ibu. Ketika sebuah bahasa punah, pengetahuan itu ikut hilang. Gagasan utama paragraf tersebut adalah ...",
    "options": [
      "Aturan adat hanya dapat dijelaskan dengan bahasa Indonesia.",
      "Tumbuhan obat hanya dikenal di satu daerah.",
      "Punahnya bahasa daerah berarti hilangnya pengetahuan lokal yang dimilikinya.",
      "Semua pengetahuan lokal sudah dicatat dalam buku.",
      "Bahasa ibu tidak berhubungan dengan pengetahuan lokal."
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Gagasan utama/simpulan harus mencakup keseluruhan isi paragraf, bukan hanya satu rincian."
  },
  {
    "id": 1246,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Penulisan kata berimbuhan yang BENAR adalah ...",
    "options": [
      "mempengarui",
      "mengpengaruhi",
      "memperngaruhi",
      "memengaruhi",
      "mempengaruhi"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bentuk yang benar: memengaruhi."
  },
  {
    "id": 1247,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Penulisan kata berimbuhan yang BENAR adalah ...",
    "options": [
      "merubah",
      "mengobah",
      "memubah",
      "mengubah",
      "mengebah"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bentuk yang benar: mengubah."
  },
  {
    "id": 1248,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Penulisan kata berimbuhan yang BENAR adalah ...",
    "options": [
      "menganyi",
      "menyanyikan",
      "menyanyi",
      "mensanyi",
      "mennyanyi"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Bentuk yang benar: menyanyi."
  },
  {
    "id": 1249,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Penulisan kata berimbuhan yang BENAR adalah ...",
    "options": [
      "berpikirkan",
      "berpikiran",
      "berpikir",
      "perpikir",
      "berfikir"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Bentuk yang benar: berpikir."
  },
  {
    "id": 1250,
    "moduleId": "verbal",
    "category": "Verbal",
    "question": "Penulisan kata berimbuhan yang BENAR adalah ...",
    "options": [
      "mempertanggung jawabkan",
      "mempertanggungjawabi",
      "mempertanggungjawabkan",
      "mempertanggungjawaban",
      "memper-tanggungjawab"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Bentuk yang benar: mempertanggungjawabkan."
  }
];
