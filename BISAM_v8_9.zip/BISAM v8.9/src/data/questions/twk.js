export const TWK = [
  {
    "id": 2301,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Dasar negara Republik Indonesia adalah ...",
    "options": [
      "UUD 1945",
      "Pancasila",
      "Bhinneka Tunggal Ika",
      "Proklamasi",
      "NKRI"
    ],
    "answer": "B",
    "explanation": "Pancasila adalah dasar negara."
  },
  {
    "id": 2302,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Rumusan Pancasila tercantum dalam Pembukaan UUD 1945 alinea ...",
    "options": [
      "Pertama",
      "Kedua",
      "Ketiga",
      "Keempat",
      "Penjelasan"
    ],
    "answer": "D",
    "explanation": "Rumusan Pancasila tercantum pada alinea keempat."
  },
  {
    "id": 2303,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Bhinneka Tunggal Ika berarti ...",
    "options": [
      "Bersatu kita teguh",
      "Berbeda-beda tetapi tetap satu",
      "Satu bangsa satu bahasa",
      "Keadilan untuk rakyat",
      "Kedaulatan rakyat"
    ],
    "answer": "B",
    "explanation": "Maknanya berbeda-beda tetapi tetap satu."
  },
  {
    "id": 2304,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Proklamasi Kemerdekaan Indonesia dibacakan tanggal ...",
    "options": [
      "1 Juni 1945",
      "17 Agustus 1945",
      "18 Agustus 1945",
      "28 Oktober 1928",
      "10 November 1945"
    ],
    "answer": "B",
    "explanation": "Proklamasi dibacakan 17 Agustus 1945."
  },
  {
    "id": 2305,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Tokoh yang membacakan teks Proklamasi adalah ...",
    "options": [
      "Mohammad Hatta",
      "Soepomo",
      "Soekarno",
      "Sutan Sjahrir",
      "Ahmad Soebardjo"
    ],
    "answer": "C",
    "explanation": "Soekarno membacakan Proklamasi didampingi Hatta."
  },
  {
    "id": 2306,
    "moduleId": "twk",
    "category": "TWK",
    "question": "UUD 1945 disahkan pada ...",
    "options": [
      "17 Agustus 1945",
      "18 Agustus 1945",
      "19 Agustus 1945",
      "20 Mei 1908",
      "1 Juni 1945"
    ],
    "answer": "B",
    "explanation": "Disahkan PPKI pada 18 Agustus 1945."
  },
  {
    "id": 2307,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Lembaga yang berwenang mengubah dan menetapkan UUD adalah ...",
    "options": [
      "DPR",
      "DPD",
      "MPR",
      "MA",
      "MK"
    ],
    "answer": "C",
    "explanation": "MPR memiliki kewenangan tersebut."
  },
  {
    "id": 2308,
    "moduleId": "twk",
    "category": "TWK",
    "question": "MPR terdiri atas anggota ...",
    "options": [
      "DPR dan MA",
      "DPR dan DPD",
      "DPD dan MK",
      "DPR dan BPK",
      "DPD dan KY"
    ],
    "answer": "B",
    "explanation": "MPR terdiri atas anggota DPR dan DPD."
  },
  {
    "id": 2309,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Masa jabatan Presiden dan Wakil Presiden adalah ...",
    "options": [
      "4 tahun",
      "5 tahun",
      "6 tahun",
      "7 tahun",
      "8 tahun"
    ],
    "answer": "B",
    "explanation": "Masa jabatan adalah lima tahun."
  },
  {
    "id": 2310,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Presiden dan Wakil Presiden dapat dipilih kembali untuk jabatan yang sama paling banyak ...",
    "options": [
      "Tanpa batas",
      "Satu kali masa jabatan",
      "Dua kali setelah masa pertama",
      "Tiga kali",
      "Empat kali"
    ],
    "answer": "B",
    "explanation": "Dapat dipilih kembali satu kali."
  },
  {
    "id": 2311,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Kekuasaan membentuk undang-undang berada pada ...",
    "options": [
      "Presiden",
      "DPR",
      "MPR",
      "MA",
      "BPK"
    ],
    "answer": "B",
    "explanation": "DPR memegang kekuasaan membentuk undang-undang."
  },
  {
    "id": 2312,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Lembaga yang memeriksa pengelolaan dan tanggung jawab keuangan negara adalah ...",
    "options": [
      "BPK",
      "Bappenas",
      "KPK",
      "MA",
      "MK"
    ],
    "answer": "A",
    "explanation": "BPK menjalankan fungsi pemeriksaan tersebut."
  },
  {
    "id": 2313,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Mahkamah Konstitusi menguji undang-undang terhadap ...",
    "options": [
      "Perpres",
      "PP",
      "UUD 1945",
      "Perda",
      "Permen"
    ],
    "answer": "C",
    "explanation": "MK menguji UU terhadap UUD 1945."
  },
  {
    "id": 2314,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Yang bukan lingkungan peradilan di bawah Mahkamah Agung adalah ...",
    "options": [
      "Peradilan umum",
      "Peradilan agama",
      "Peradilan militer",
      "Peradilan TUN",
      "Mahkamah Konstitusi"
    ],
    "answer": "E",
    "explanation": "MK adalah lembaga kehakiman tersendiri."
  },
  {
    "id": 2315,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Komisi Yudisial terutama berkaitan dengan ...",
    "options": [
      "APBN",
      "Kehormatan dan perilaku hakim",
      "Pemilu",
      "Pertahanan",
      "Pajak"
    ],
    "answer": "B",
    "explanation": "KY berkaitan dengan kehormatan dan perilaku hakim."
  },
  {
    "id": 2316,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Sila pertama Pancasila adalah ...",
    "options": [
      "Kemanusiaan yang adil dan beradab",
      "Persatuan Indonesia",
      "Ketuhanan Yang Maha Esa",
      "Keadilan sosial",
      "Kerakyatan"
    ],
    "answer": "C",
    "explanation": "Sila pertama adalah Ketuhanan Yang Maha Esa."
  },
  {
    "id": 2317,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Sila kedua Pancasila menekankan nilai ...",
    "options": [
      "Kemanusiaan",
      "Persatuan",
      "Musyawarah",
      "Keadilan sosial",
      "Ketuhanan"
    ],
    "answer": "A",
    "explanation": "Sila kedua adalah Kemanusiaan yang adil dan beradab."
  },
  {
    "id": 2318,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Musyawarah untuk mufakat paling erat dengan sila ke ...",
    "options": [
      "1",
      "2",
      "3",
      "4",
      "5"
    ],
    "answer": "D",
    "explanation": "Sila keempat menekankan permusyawaratan/perwakilan."
  },
  {
    "id": 2319,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Keadilan sosial bagi seluruh rakyat Indonesia merupakan sila ke ...",
    "options": [
      "1",
      "2",
      "3",
      "4",
      "5"
    ],
    "answer": "E",
    "explanation": "Itu sila kelima."
  },
  {
    "id": 2320,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Simbol sila ketiga Pancasila adalah ...",
    "options": [
      "Bintang",
      "Rantai",
      "Pohon beringin",
      "Kepala banteng",
      "Padi kapas"
    ],
    "answer": "C",
    "explanation": "Pohon beringin melambangkan Persatuan Indonesia."
  },
  {
    "id": 2321,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Sumpah Pemuda diperingati setiap tanggal ...",
    "options": [
      "20 Mei",
      "1 Juni",
      "17 Agustus",
      "28 Oktober",
      "10 November"
    ],
    "answer": "D",
    "explanation": "Sumpah Pemuda 28 Oktober 1928."
  },
  {
    "id": 2322,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Sumpah Pemuda menegaskan satu tanah air, satu bangsa, dan satu ...",
    "options": [
      "Negara",
      "Bahasa",
      "Agama",
      "Pemerintahan",
      "Ideologi"
    ],
    "answer": "B",
    "explanation": "Satu bahasa persatuan, Bahasa Indonesia."
  },
  {
    "id": 2323,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Budi Utomo berdiri pada tahun ...",
    "options": [
      "1908",
      "1912",
      "1928",
      "1942",
      "1945"
    ],
    "answer": "A",
    "explanation": "Budi Utomo berdiri 1908."
  },
  {
    "id": 2324,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Hari Kebangkitan Nasional diperingati setiap ...",
    "options": [
      "2 Mei",
      "20 Mei",
      "1 Juni",
      "17 Agustus",
      "28 Oktober"
    ],
    "answer": "B",
    "explanation": "Diperingati 20 Mei."
  },
  {
    "id": 2325,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Pertempuran 10 November 1945 terjadi di ...",
    "options": [
      "Bandung",
      "Semarang",
      "Surabaya",
      "Yogyakarta",
      "Medan"
    ],
    "answer": "C",
    "explanation": "Pertempuran tersebut terjadi di Surabaya."
  },
  {
    "id": 2326,
    "moduleId": "twk",
    "category": "TWK",
    "question": "BPUPKI dibentuk pada masa pendudukan ...",
    "options": [
      "Belanda",
      "Inggris",
      "Jepang",
      "Portugis",
      "Spanyol"
    ],
    "answer": "C",
    "explanation": "BPUPKI dibentuk pada masa pendudukan Jepang."
  },
  {
    "id": 2327,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Salah satu peran PPKI setelah Proklamasi adalah ...",
    "options": [
      "Mendirikan Budi Utomo",
      "Mengesahkan UUD 1945",
      "Menyusun Sumpah Pemuda",
      "Membentuk VOC",
      "Membubarkan KNIP"
    ],
    "answer": "B",
    "explanation": "PPKI mengesahkan UUD 1945."
  },
  {
    "id": 2328,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Bentuk negara Indonesia adalah ...",
    "options": [
      "Federasi",
      "Konfederasi",
      "Kesatuan",
      "Monarki",
      "Protektorat"
    ],
    "answer": "C",
    "explanation": "Indonesia adalah negara kesatuan."
  },
  {
    "id": 2329,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Bentuk pemerintahan Indonesia adalah ...",
    "options": [
      "Monarki absolut",
      "Monarki konstitusional",
      "Republik",
      "Federasi kerajaan",
      "Kerajaan parlementer"
    ],
    "answer": "C",
    "explanation": "Indonesia berbentuk republik."
  },
  {
    "id": 2330,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Kedaulatan berada di tangan rakyat dan dilaksanakan menurut ...",
    "options": [
      "Perpres",
      "UUD",
      "Permen",
      "Keputusan DPR",
      "Adat"
    ],
    "answer": "B",
    "explanation": "Pasal 1 ayat (2) UUD 1945."
  },
  {
    "id": 2331,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Indonesia adalah negara hukum terdapat dalam Pasal ...",
    "options": [
      "1 ayat (1)",
      "1 ayat (2)",
      "1 ayat (3)",
      "2 ayat (1)",
      "3 ayat (1)"
    ],
    "answer": "C",
    "explanation": "Pasal 1 ayat (3)."
  },
  {
    "id": 2332,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Bahasa negara adalah ...",
    "options": [
      "Melayu",
      "Bahasa Indonesia",
      "Jawa",
      "Nusantara",
      "Bahasa Nasional"
    ],
    "answer": "B",
    "explanation": "Bahasa negara ialah Bahasa Indonesia."
  },
  {
    "id": 2333,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Bendera negara Indonesia adalah ...",
    "options": [
      "Merah Putih",
      "Merah Biru",
      "Putih Merah",
      "Garuda",
      "Sang Saka Biru"
    ],
    "answer": "A",
    "explanation": "Bendera negara adalah Sang Merah Putih."
  },
  {
    "id": 2334,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Lambang negara adalah ...",
    "options": [
      "Harimau Sumatra",
      "Garuda Pancasila",
      "Rajawali Nusantara",
      "Cenderawasih",
      "Elang Jawa"
    ],
    "answer": "B",
    "explanation": "Lambang negara adalah Garuda Pancasila."
  },
  {
    "id": 2335,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Lagu kebangsaan Indonesia adalah ...",
    "options": [
      "Bagimu Negeri",
      "Indonesia Raya",
      "Garuda Pancasila",
      "Hari Merdeka",
      "Tanah Airku"
    ],
    "answer": "B",
    "explanation": "Lagu kebangsaan ialah Indonesia Raya."
  },
  {
    "id": 2336,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Hak memperoleh pendidikan diatur dalam UUD 1945 Pasal ...",
    "options": [
      "27",
      "28",
      "29",
      "31",
      "33"
    ],
    "answer": "D",
    "explanation": "Pasal 31 mengatur pendidikan."
  },
  {
    "id": 2337,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Perekonomian disusun sebagai usaha bersama berdasar asas kekeluargaan terdapat dalam Pasal ...",
    "options": [
      "27",
      "28",
      "30",
      "31",
      "33"
    ],
    "answer": "E",
    "explanation": "Ketentuan itu berada pada Pasal 33."
  },
  {
    "id": 2338,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Hak dan kewajiban ikut serta dalam upaya pembelaan negara diatur dalam ...",
    "options": [
      "Pasal 27 ayat (3)",
      "Pasal 28A",
      "Pasal 29 ayat (2)",
      "Pasal 31 ayat (1)",
      "Pasal 33 ayat (1)"
    ],
    "answer": "A",
    "explanation": "Pasal 27 ayat (3)."
  },
  {
    "id": 2339,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Kemerdekaan memeluk agama dan beribadat dijamin terutama dalam Pasal ...",
    "options": [
      "27",
      "28",
      "29",
      "30",
      "31"
    ],
    "answer": "C",
    "explanation": "Pasal 29 ayat (2)."
  },
  {
    "id": 2340,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Asas Pemilu dikenal sebagai Luber Jurdil. Huruf 'A' dalam 'adil' berarti ...",
    "options": [
      "Cepat",
      "Terbuka",
      "Adil",
      "Serentak",
      "Sederhana"
    ],
    "answer": "C",
    "explanation": "Jurdil = jujur dan adil."
  },
  {
    "id": 2341,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Lembaga penyelenggara Pemilu yang nasional, tetap, dan mandiri adalah ...",
    "options": [
      "DPR",
      "KPU",
      "Bawaslu",
      "MPR",
      "DPD"
    ],
    "answer": "B",
    "explanation": "KPU menyelenggarakan Pemilu."
  },
  {
    "id": 2342,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Otonomi daerah pada prinsipnya memberi kewenangan daerah untuk ...",
    "options": [
      "Memisahkan diri",
      "Mengatur dan mengurus urusan pemerintahan sesuai ketentuan",
      "Membentuk militer sendiri",
      "Mencetak uang",
      "Membuat konstitusi negara"
    ],
    "answer": "B",
    "explanation": "Itulah inti otonomi daerah."
  },
  {
    "id": 2343,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Sikap yang sesuai Bhinneka Tunggal Ika adalah ...",
    "options": [
      "Menolak budaya lain",
      "Mengutamakan kelompok sendiri",
      "Menghargai perbedaan suku dan agama",
      "Menyamakan semua tradisi",
      "Menghindari kerja sama"
    ],
    "answer": "C",
    "explanation": "Bhinneka Tunggal Ika menekankan persatuan dalam keberagaman."
  },
  {
    "id": 2344,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Contoh pengamalan sila kedua adalah ...",
    "options": [
      "Memaksakan pendapat",
      "Membantu korban bencana tanpa membeda-bedakan",
      "Mengutamakan kelompok",
      "Menghindari musyawarah",
      "Menolak perbedaan"
    ],
    "answer": "B",
    "explanation": "Itu mencerminkan kemanusiaan yang adil dan beradab."
  },
  {
    "id": 2345,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Contoh pengamalan sila ketiga adalah ...",
    "options": [
      "Menjaga persatuan meski berbeda suku",
      "Mendahulukan kepentingan pribadi",
      "Tidak mau bekerja sama",
      "Memaksakan agama",
      "Mengabaikan bangsa"
    ],
    "answer": "A",
    "explanation": "Itu mencerminkan Persatuan Indonesia."
  },
  {
    "id": 2346,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Dalam demokrasi konstitusional, kekuasaan pemerintah harus ...",
    "options": [
      "Tidak terbatas",
      "Tunduk pada konstitusi dan hukum",
      "Bergantung satu orang",
      "Bebas pengawasan",
      "Di atas hukum"
    ],
    "answer": "B",
    "explanation": "Kekuasaan dibatasi konstitusi dan hukum."
  },
  {
    "id": 2347,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Salah satu tujuan negara dalam Pembukaan UUD 1945 adalah ...",
    "options": [
      "Memperluas wilayah",
      "Melindungi segenap bangsa Indonesia dan seluruh tumpah darah Indonesia",
      "Membentuk kerajaan",
      "Menguasai perdagangan dunia",
      "Membatasi pendidikan"
    ],
    "answer": "B",
    "explanation": "Itu salah satu tujuan negara."
  },
  {
    "id": 2348,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Persamaan kedudukan warga negara di depan hukum berarti ...",
    "options": [
      "Hukum hanya untuk pejabat",
      "Setiap warga diperlakukan setara di hadapan hukum",
      "Warga kaya mendapat khusus",
      "Hukum berbeda menurut pekerjaan",
      "Pejabat kebal hukum"
    ],
    "answer": "B",
    "explanation": "Equality before the law."
  },
  {
    "id": 2349,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Upaya menjaga keutuhan NKRI paling tepat adalah ...",
    "options": [
      "Menyebarkan permusuhan",
      "Menghormati perbedaan dan menaati hukum",
      "Mendahulukan daerah di atas negara",
      "Menolak musyawarah",
      "Menghindari kerja sama"
    ],
    "answer": "B",
    "explanation": "Persatuan dan ketaatan hukum memperkuat NKRI."
  },
  {
    "id": 2350,
    "moduleId": "twk",
    "category": "TWK",
    "question": "Nilai utama sila keempat Pancasila adalah ...",
    "options": [
      "Individualisme",
      "Musyawarah dan demokrasi",
      "Persaingan bebas",
      "Kekuasaan mutlak",
      "Monarki"
    ],
    "answer": "B",
    "explanation": "Sila keempat menekankan kerakyatan dan permusyawaratan."
  }
];
