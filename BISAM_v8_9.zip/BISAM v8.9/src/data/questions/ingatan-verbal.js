export const INGATAN_VERBAL = [
  {
    "id": 2501,
    "moduleId": "ingatan-verbal",
    "category": "Ingatan Verbal",
    "question": "Dua kata berturut-turut yang termasuk dalam kelompok bunga dan benda memiliki huruf pertama ?",
    "options": [
      "T dan B",
      "A dan D",
      "W dan R",
      "I dan F",
      "M dan E"
    ],
    "answer": "B",
    "explanation": "A dan D adalah aster dan dipan. Aster termasuk bunga dan dipan termasuk benda."
  },
  {
    "id": 2502,
    "moduleId": "ingatan-verbal",
    "category": "Ingatan Verbal",
    "question": "Huruf pertama dari kata yang termasuk ke dalam kelompok kota adalah ?",
    "options": [
      "S",
      "T",
      "G",
      "R",
      "B"
    ],
    "answer": "A",
    "explanation": "S adalah Solok, yaitu kata yang termasuk kelompok kota."
  },
  {
    "id": 2503,
    "moduleId": "ingatan-verbal",
    "category": "Ingatan Verbal",
    "question": "Huruf pertama dari kata yang termasuk dalam kelompok bunga dan benda adalah ?",
    "options": [
      "kota dan bunga",
      "bunga dan benda",
      "benda dan binatang",
      "kota dan bunga",
      "kota dan binatang"
    ],
    "answer": "B",
    "explanation": "V dan E adalah verbena dan emas. Verbena termasuk bunga dan emas termasuk benda."
  },
  {
    "id": 2504,
    "moduleId": "ingatan-verbal",
    "category": "Ingatan Verbal",
    "question": "Huruf pertama dari kata yang termasuk dalam kelompok kota dan binatang adalah ?",
    "options": [
      "A dan D",
      "D dan B",
      "F dan B",
      "S dan R",
      "M dan U"
    ],
    "answer": "E",
    "explanation": "M dan U adalah Magelang dan unta. Magelang termasuk kota dan unta termasuk binatang."
  }
];
