export const KONSENTRASI = [
  {
    "id": 2001,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"58\" (berurutan) muncul pada deret berikut?  2497103674454280607843069635813859490466",
    "options": [
      "4",
      "5",
      "1",
      "6",
      "0"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Periksa setiap pasangan angka bersebelahan; \"58\" muncul 1 kali."
  },
  {
    "id": 2002,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"21\" (berurutan) muncul pada deret berikut?  6212485740673034587626636560484887195238",
    "options": [
      "6",
      "1",
      "2",
      "3",
      "7"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Periksa setiap pasangan angka bersebelahan; \"21\" muncul 1 kali."
  },
  {
    "id": 2003,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"46\" (berurutan) muncul pada deret berikut?  7453214670965872879506489500439853798639",
    "options": [
      "7",
      "2",
      "3",
      "1",
      "4"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Periksa setiap pasangan angka bersebelahan; \"46\" muncul 1 kali."
  },
  {
    "id": 2004,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"90\" (berurutan) muncul pada deret berikut?  0739542695926187753162585723359687849042",
    "options": [
      "9",
      "1",
      "5",
      "2",
      "0"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Periksa setiap pasangan angka bersebelahan; \"90\" muncul 1 kali."
  },
  {
    "id": 2005,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"90\" (berurutan) muncul pada deret berikut?  0697070664839818924513075035900077002058",
    "options": [
      "0",
      "7",
      "1",
      "2",
      "3"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Periksa setiap pasangan angka bersebelahan; \"90\" muncul 1 kali."
  },
  {
    "id": 2006,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"21\" (berurutan) muncul pada deret berikut?  3895220489107948641783188071214994949309",
    "options": [
      "4",
      "9",
      "7",
      "1",
      "0"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Periksa setiap pasangan angka bersebelahan; \"21\" muncul 1 kali."
  },
  {
    "id": 2007,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"37\" (berurutan) muncul pada deret berikut?  7759372394328186852915594708987146129965",
    "options": [
      "3",
      "5",
      "2",
      "1",
      "9"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Periksa setiap pasangan angka bersebelahan; \"37\" muncul 1 kali."
  },
  {
    "id": 2008,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali pasangan angka \"21\" (berurutan) muncul pada deret berikut?  9921357480012243152040633109374171379030",
    "options": [
      "1",
      "5",
      "4",
      "7",
      "2"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Periksa setiap pasangan angka bersebelahan; \"21\" muncul 1 kali."
  },
  {
    "id": 2009,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 7 muncul pada deret berikut?  2 1 5 6 9 4 9 3 6 8 6 6 9 3 2 5 6 6 6 6 1 3 1 4 6 3 5 2 6 9 4 3 7 5 7 8 3 4 6 0 6 1 6 1 1",
    "options": [
      "5",
      "2",
      "3",
      "6",
      "4"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Angka 7 muncul 2 kali."
  },
  {
    "id": 2010,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 8 muncul pada deret berikut?  3 8 4 8 9 3 4 4 8 9 2 4 3 3 8 0 7 1 4 9 2 3 8 5 0 9 8 5 5 9 1 7 1 0 4 0 5 9 2 8 8 4 7 2 0",
    "options": [
      "6",
      "8",
      "10",
      "7",
      "5"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Angka 8 muncul 8 kali."
  },
  {
    "id": 2011,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 5 muncul pada deret berikut?  6 2 9 9 3 1 0 9 2 6 2 0 4 7 8 4 2 6 5 2 2 3 2 3 3 1 7 4 3 0 7 1 6 2 6 1 9 8 2 4 7 1 0 4 0",
    "options": [
      "1",
      "5",
      "4",
      "0",
      "6"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Angka 5 muncul 1 kali."
  },
  {
    "id": 2012,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 9 muncul pada deret berikut?  3 4 1 0 8 0 9 1 3 5 4 7 6 0 6 8 7 2 3 0 3 8 6 6 5 2 1 7 7 0 9 4 3 7 1 0 5 3 0 7 8 2 6 0 1",
    "options": [
      "3",
      "0",
      "1",
      "2",
      "7"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Angka 9 muncul 2 kali."
  },
  {
    "id": 2013,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 5 muncul pada deret berikut?  5 8 6 5 4 5 0 4 0 2 8 1 2 8 7 4 4 8 2 7 7 3 0 4 2 0 2 0 2 0 4 9 8 4 8 3 8 3 1 9 4 5 0 6 1",
    "options": [
      "8",
      "4",
      "2",
      "0",
      "1"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Angka 5 muncul 4 kali."
  },
  {
    "id": 2014,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 6 muncul pada deret berikut?  3 3 5 4 4 1 1 0 3 0 2 9 1 7 9 0 1 4 7 9 8 3 3 3 8 7 9 2 9 8 1 2 5 6 4 0 9 7 4 6 3 9 0 3 2",
    "options": [
      "2",
      "0",
      "5",
      "1",
      "4"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Angka 6 muncul 2 kali."
  },
  {
    "id": 2015,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 0 muncul pada deret berikut?  4 9 4 5 3 6 2 8 3 1 8 8 9 7 6 4 7 5 6 6 0 3 0 8 2 8 8 3 6 4 4 3 5 0 7 2 5 5 6 1 7 6 8 8 8",
    "options": [
      "5",
      "2",
      "3",
      "4",
      "7"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Angka 0 muncul 3 kali."
  },
  {
    "id": 2016,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali angka 8 muncul pada deret berikut?  5 1 4 5 1 7 8 2 2 0 2 0 7 0 0 8 2 6 2 2 5 1 7 5 0 3 5 4 9 1 2 0 0 2 9 7 1 5 3 5 7 5 0 5 3",
    "options": [
      "1",
      "4",
      "3",
      "6",
      "2"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Angka 8 muncul 2 kali."
  },
  {
    "id": 2017,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: 0DDE, 943A, CH90, B1F9, DG00, 86BH, E8G2, GFH9, BC86, 821F. Daftar 2: 0DDE, 943A, CH90, B1F9, 3G00, 87BH, E8B2, GFH9, BC87, 82HF. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "2",
      "8",
      "5",
      "6",
      "7"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Terdapat 5 pasang yang identik."
  },
  {
    "id": 2018,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: E4G8, 2333, BA30, 13AJ, BG20, 21H5, BFGB, 73HE, FKG9, 6HBJ. Daftar 2: E4G8, 2333, BA30, 1GAJ, BG20, 21H5, 9FGB, 73HE, FBG9, 6HBJ. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "3",
      "9",
      "10",
      "7",
      "6"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Terdapat 7 pasang yang identik."
  },
  {
    "id": 2019,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: 7B90, J3FJ, JD40, 10GE, HB84, 46F5, 0JKE, E98G, 39H7, 559J. Daftar 2: 7B90, J3FJ, JG40, 107E, HB84, 46F5, 0JKE, E98G, 30H7, 559J. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "9",
      "7",
      "11",
      "10",
      "6"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Terdapat 7 pasang yang identik."
  },
  {
    "id": 2020,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: A86B, C038, A95E, JE7F, H3HB, 4BFB, HEA7, 2598, G45F, A13E. Daftar 2: A8KB, C028, A95E, J77F, H3HB, 4B7B, HEA7, 2590, G45F, A13E. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "1",
      "6",
      "7",
      "3",
      "5"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Terdapat 5 pasang yang identik."
  },
  {
    "id": 2021,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: HKCA, A847, 9E33, 753J, 2022, GK4G, ED28, KF77, HB93, 57AE. Daftar 2: HKCA, A847, 9E37, 753J, 2022, GKEG, ED98, KF87, HB93, 57AE. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "4",
      "3",
      "6",
      "9",
      "10"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Terdapat 6 pasang yang identik."
  },
  {
    "id": 2022,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: 69E9, FC97, 74GK, J9A9, 5933, JH08, JC62, JD3D, 5FBD, 246G. Daftar 2: 69E9, FC97, D4GK, JBA9, 5933, JH08, JC62, JD3D, 5FBD, 146G. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "7",
      "9",
      "3",
      "6",
      "4"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Terdapat 7 pasang yang identik."
  },
  {
    "id": 2023,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: C3JE, E3G2, 37DF, 7663, 0C2D, F1G0, 2245, 93G3, EEHG, K146. Daftar 2: CGJE, E3GC, 37DF, J663, 0C2D, F1G1, H245, 93G3, EEHF, K1A6. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "6",
      "2",
      "3",
      "0",
      "1"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Terdapat 3 pasang yang identik."
  },
  {
    "id": 2024,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Bandingkan dua daftar kode berikut baris demi baris. Daftar 1: 82B1, 42E6, 5H7A, 618G, 8BB1, 66BC, 7ACF, DH79, 0KDF, 652J. Daftar 2: 82B1, 42E6, 5H7A, 618G, 8BB1, 66BH, 7ACF, DH99, 0KDF, 6E2J. Berapa pasang kode yang SAMA PERSIS pada baris yang sama?",
    "options": [
      "5",
      "11",
      "6",
      "7",
      "4"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Terdapat 7 pasang yang identik."
  },
  {
    "id": 2025,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  28, 85, 85, 72, 93, 30, 87, 66, 78, 67, 74, 20, 92, 56, 27, 37",
    "options": [
      "4",
      "3",
      "7",
      "5",
      "2"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bilangan prima yang muncul: 67, 37 (2 buah)."
  },
  {
    "id": 2026,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  74, 47, 19, 80, 99, 78, 44, 73, 23, 53, 59, 46, 45, 48, 29, 41",
    "options": [
      "9",
      "4",
      "10",
      "8",
      "6"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bilangan prima yang muncul: 47, 19, 73, 23, 53, 59, 29, 41 (8 buah)."
  },
  {
    "id": 2027,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  77, 43, 12, 17, 51, 15, 44, 61, 35, 46, 93, 75, 91, 35, 87, 34",
    "options": [
      "4",
      "7",
      "8",
      "3",
      "2"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bilangan prima yang muncul: 43, 17, 61 (3 buah)."
  },
  {
    "id": 2028,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  10, 62, 75, 86, 60, 10, 12, 31, 37, 27, 20, 87, 72, 46, 66, 25",
    "options": [
      "5",
      "1",
      "8",
      "0",
      "2"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bilangan prima yang muncul: 31, 37 (2 buah)."
  },
  {
    "id": 2029,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  25, 69, 47, 39, 83, 94, 50, 93, 69, 81, 63, 83, 28, 30, 93, 55",
    "options": [
      "4",
      "7",
      "1",
      "3",
      "6"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bilangan prima yang muncul: 47, 83, 83 (3 buah)."
  },
  {
    "id": 2030,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  68, 42, 19, 96, 83, 17, 55, 63, 55, 44, 92, 22, 84, 94, 10, 26",
    "options": [
      "6",
      "8",
      "1",
      "3",
      "2"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Bilangan prima yang muncul: 19, 83, 17 (3 buah)."
  },
  {
    "id": 2031,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  70, 93, 17, 50, 17, 60, 67, 85, 30, 35, 24, 78, 86, 37, 11, 34",
    "options": [
      "4",
      "5",
      "6",
      "3",
      "9"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Bilangan prima yang muncul: 17, 17, 67, 37, 11 (5 buah)."
  },
  {
    "id": 2032,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak bilangan prima pada deret berikut?  32, 37, 58, 45, 98, 45, 26, 11, 58, 34, 38, 90, 88, 68, 79, 74",
    "options": [
      "6",
      "3",
      "1",
      "4",
      "7"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Bilangan prima yang muncul: 37, 11, 79 (3 buah)."
  },
  {
    "id": 2033,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Deret berikut disusun dari angka 1 sampai 9 secara acak, tetapi satu angka tidak muncul. Angka yang hilang adalah ...  5 6 8 2 9 1 3 7",
    "options": [
      "5",
      "4",
      "2",
      "3",
      "1"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Jumlah 1..9 = 45; jumlah deret = 41; selisih = 4."
  },
  {
    "id": 2034,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Deret berikut disusun dari angka 1 sampai 9 secara acak, tetapi satu angka tidak muncul. Angka yang hilang adalah ...  6 3 1 8 9 5 7 2",
    "options": [
      "1",
      "5",
      "4",
      "2",
      "3"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Jumlah 1..9 = 45; jumlah deret = 41; selisih = 4."
  },
  {
    "id": 2035,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Deret berikut disusun dari angka 1 sampai 9 secara acak, tetapi satu angka tidak muncul. Angka yang hilang adalah ...  4 1 9 5 3 8 6 2",
    "options": [
      "2",
      "1",
      "4",
      "3",
      "7"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Jumlah 1..9 = 45; jumlah deret = 38; selisih = 7."
  },
  {
    "id": 2036,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Deret berikut disusun dari angka 1 sampai 9 secara acak, tetapi satu angka tidak muncul. Angka yang hilang adalah ...  1 9 3 5 2 6 7 4",
    "options": [
      "2",
      "8",
      "3",
      "4",
      "1"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Jumlah 1..9 = 45; jumlah deret = 37; selisih = 8."
  },
  {
    "id": 2037,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Deret berikut disusun dari angka 1 sampai 9 secara acak, tetapi satu angka tidak muncul. Angka yang hilang adalah ...  8 3 1 2 9 4 6 5",
    "options": [
      "3",
      "2",
      "7",
      "1",
      "4"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Jumlah 1..9 = 45; jumlah deret = 38; selisih = 7."
  },
  {
    "id": 2038,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Deret berikut disusun dari angka 1 sampai 9 secara acak, tetapi satu angka tidak muncul. Angka yang hilang adalah ...  4 5 2 3 9 1 8 7",
    "options": [
      "6",
      "4",
      "2",
      "1",
      "3"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Jumlah 1..9 = 45; jumlah deret = 39; selisih = 6."
  },
  {
    "id": 2039,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak huruf vokal (A, I, U, E, O) pada deret berikut?  A M I E R I O O S I S I T R I B U A L I B M R I K I K E A K B B",
    "options": [
      "13",
      "20",
      "16",
      "12",
      "18"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Vokal muncul 16 kali."
  },
  {
    "id": 2040,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak huruf vokal (A, I, U, E, O) pada deret berikut?  A K R B R R I N T T N N B M N N M B N M M L I B I I E M I B U M",
    "options": [
      "6",
      "11",
      "10",
      "8",
      "7"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Vokal muncul 8 kali."
  },
  {
    "id": 2041,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak huruf vokal (A, I, U, E, O) pada deret berikut?  O L T A R S O I O L N K S I L E O N L M A U T B K I A T A S S I",
    "options": [
      "18",
      "10",
      "13",
      "15",
      "14"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Vokal muncul 14 kali."
  },
  {
    "id": 2042,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak huruf vokal (A, I, U, E, O) pada deret berikut?  R N B L B M T M U I N M E L L E R M L R O M K B I E A T K M M O",
    "options": [
      "5",
      "12",
      "10",
      "11",
      "9"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Vokal muncul 9 kali."
  },
  {
    "id": 2043,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa banyak huruf vokal (A, I, U, E, O) pada deret berikut?  B R S E O L L E S O I R A O S S R E L T O U R U M R K M T A I S",
    "options": [
      "11",
      "15",
      "14",
      "17",
      "13"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Vokal muncul 13 kali."
  },
  {
    "id": 2044,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali huruf A langsung diikuti huruf B pada deret berikut?  CCAACABCAAACBCCAABCBACBCACCCAABABBCC",
    "options": [
      "3",
      "7",
      "1",
      "8",
      "4"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Pasangan \"AB\" muncul 4 kali."
  },
  {
    "id": 2045,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali huruf C langsung diikuti huruf A pada deret berikut?  ABAACAABCCABABACAACBCCBACCBBACBCCBBA",
    "options": [
      "3",
      "2",
      "7",
      "0",
      "4"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pasangan \"CA\" muncul 3 kali."
  },
  {
    "id": 2046,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali huruf B langsung diikuti huruf C pada deret berikut?  CCCCAAABAAAAACCBBBCCABCAACCBBCBCCCAC",
    "options": [
      "4",
      "6",
      "7",
      "1",
      "0"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pasangan \"BC\" muncul 4 kali."
  },
  {
    "id": 2047,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali huruf A langsung diikuti huruf B pada deret berikut?  BCBAABBABAACCBBBBAAABACCABCACBCAABCC",
    "options": [
      "5",
      "3",
      "9",
      "6",
      "7"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pasangan \"AB\" muncul 5 kali."
  },
  {
    "id": 2048,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa kali huruf B langsung diikuti huruf A pada deret berikut?  AACBCBBCBBABCABBACAABACCBBCACCACBABC",
    "options": [
      "3",
      "7",
      "6",
      "2",
      "4"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Pasangan \"BA\" muncul 4 kali."
  },
  {
    "id": 2049,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa jumlah semua angka genap pada deret berikut?  8 2 9 1 9 8 1 8 3 9 7 9 7 9",
    "options": [
      "26",
      "32",
      "18",
      "30",
      "22"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Penjumlahan angka genap = 26."
  },
  {
    "id": 2050,
    "moduleId": "konsentrasi",
    "category": "Kecepatan Konsentrasi",
    "question": "Berapa jumlah semua angka genap pada deret berikut?  7 2 3 6 3 9 4 2 4 3 5 3 4 5",
    "options": [
      "20",
      "28",
      "26",
      "24",
      "22"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Penjumlahan angka genap = 22."
  }
];
