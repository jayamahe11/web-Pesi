export const MATEMATIKA = [
  {
    "id": 1601,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Seorang pedagang menaikkan harga beli sebesar 25% untuk menentukan harga label, lalu memberi diskon 40% dari harga label. Hasil penjualan per barang adalah ...",
    "options": [
      "rugi 22%",
      "rugi 30%",
      "rugi 25%",
      "rugi 15%",
      "rugi 35%"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. (1+25%)(1−40%) = 0,75, sehingga rugi 25%."
  },
  {
    "id": 1602,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Setelah diskon 40%, sebuah barang dijual seharga Rp300.000. Harga label barang tersebut adalah ...",
    "options": [
      "Rp550.000",
      "Rp475.000",
      "Rp450.000",
      "Rp525.000",
      "Rp500.000"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Rp300.000 : 60% = Rp500.000."
  },
  {
    "id": 1603,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah toko memberikan diskon bertingkat 40% lalu 50% dari harga setelah diskon pertama. Besar diskon tunggal yang setara adalah ...",
    "options": [
      "65%",
      "70%",
      "72%",
      "67%",
      "73%"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 100 − (100−40)(100−50)/100 = 70%."
  },
  {
    "id": 1604,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Dengan untung 20% dari harga beli, sebuah barang dijual Rp720.000. Harga beli barang tersebut adalah ...",
    "options": [
      "Rp580.000",
      "Rp630.000",
      "Rp620.000",
      "Rp560.000",
      "Rp600.000"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Rp720.000 : 120% = Rp600.000."
  },
  {
    "id": 1605,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah barang dijual Rp405.000 sehingga rugi 10%. Agar memperoleh untung 20%, barang itu harus dijual seharga ...",
    "options": [
      "Rp510.000",
      "Rp570.000",
      "Rp585.000",
      "Rp540.000",
      "Rp480.000"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Harga beli Rp450.000; harga jual Rp540.000."
  },
  {
    "id": 1606,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Keuntungan 20% dari harga beli sama dengan berapa persen dari harga jual?",
    "options": [
      "19%",
      "24%",
      "17%",
      "25%",
      "50/3%"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. 20/(100+20) = 50/3%."
  },
  {
    "id": 1607,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "20 mesin menghasilkan 1080 unit dalam 6 jam. Jika dioperasikan 18 mesin yang sama selama 9 jam, banyak unit yang dihasilkan adalah ...",
    "options": [
      "1690",
      "1458",
      "1284",
      "1516",
      "1574"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Laju per mesin per jam = 9; 18×9×9 = 1458."
  },
  {
    "id": 1608,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "15 pekerja dapat menyelesaikan suatu pekerjaan dalam 24 hari. Setelah 8 hari bekerja, ditambah 5 pekerja baru dengan kemampuan sama. Sisa pekerjaan selesai dalam ... hari lagi.",
    "options": [
      "8",
      "16",
      "9",
      "12",
      "15"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Sisa 240 hari-pekerja : 20 pekerja = 12 hari."
  },
  {
    "id": 1609,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Persediaan pakan cukup untuk 36 ekor ternak selama 15 hari. Setelah 3 hari, datang 12 ekor ternak baru. Sisa pakan cukup untuk ... hari lagi.",
    "options": [
      "13",
      "5",
      "9",
      "6",
      "10"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Sisa 432 hari-ekor : 48 ekor = 9 hari."
  },
  {
    "id": 1610,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "8 mesin menghasilkan 768 unit dalam 8 jam. Jika dioperasikan 16 mesin yang sama selama 5 jam, banyak unit yang dihasilkan adalah ...",
    "options": [
      "960",
      "922",
      "808",
      "1074",
      "884"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Laju per mesin per jam = 12; 16×5×12 = 960."
  },
  {
    "id": 1611,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "10 pekerja dapat menyelesaikan suatu pekerjaan dalam 36 hari. Setelah 9 hari bekerja, ditambah 5 pekerja baru dengan kemampuan sama. Sisa pekerjaan selesai dalam ... hari lagi.",
    "options": [
      "18",
      "19",
      "20",
      "17",
      "16"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Sisa 270 hari-pekerja : 15 pekerja = 18 hari."
  },
  {
    "id": 1612,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Persediaan pakan cukup untuk 20 ekor ternak selama 18 hari. Setelah 6 hari, datang 4 ekor ternak baru. Sisa pakan cukup untuk ... hari lagi.",
    "options": [
      "10",
      "12",
      "7",
      "14",
      "9"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Sisa 240 hari-ekor : 24 ekor = 10 hari."
  },
  {
    "id": 1613,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Mobil A berangkat dari kota P dengan kecepatan 60 km/jam. 1 jam kemudian mobil B menyusul dari kota P dengan kecepatan 90 km/jam melalui jalan yang sama. Mobil B menyusul mobil A pada jarak ... km dari kota P.",
    "options": [
      "165",
      "225",
      "195",
      "180",
      "210"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. B menyusul setelah 2 jam: 90×2 = 180 km."
  },
  {
    "id": 1614,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Kecepatan perahu di air tenang 12 km/jam dan kecepatan arus sungai 3 km/jam. Perahu menempuh 45 km ke hilir lalu kembali ke hulu. Total waktu perjalanan pergi-pulang adalah ... jam.",
    "options": [
      "7,5",
      "7",
      "8",
      "8,5",
      "11"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 45/15 + 45/9 = 8 jam."
  },
  {
    "id": 1615,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah kereta api sepanjang 80 m melaju 36 km/jam dan melewati sebuah terowongan sejak bagian depan masuk sampai bagian belakang keluar selama 40 detik. Panjang terowongan adalah ... m.",
    "options": [
      "288",
      "192",
      "352",
      "320",
      "224"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Jarak total = 10×40 = 400 m; dikurangi panjang kereta 80 m = 320 m."
  },
  {
    "id": 1616,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Mobil A berangkat dari kota P dengan kecepatan 30 km/jam. 2 jam kemudian mobil B menyusul dari kota P dengan kecepatan 40 km/jam melalui jalan yang sama. Mobil B menyusul mobil A pada jarak ... km dari kota P.",
    "options": [
      "280",
      "240",
      "320",
      "220",
      "180"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. B menyusul setelah 6 jam: 40×6 = 240 km."
  },
  {
    "id": 1617,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Kecepatan perahu di air tenang 20 km/jam dan kecepatan arus sungai 4 km/jam. Perahu menempuh 48 km ke hilir lalu kembali ke hulu. Total waktu perjalanan pergi-pulang adalah ... jam.",
    "options": [
      "6",
      "5,5",
      "8",
      "5",
      "7"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 48/24 + 48/16 = 5 jam."
  },
  {
    "id": 1618,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah kereta api sepanjang 100 m melaju 72 km/jam dan melewati sebuah terowongan sejak bagian depan masuk sampai bagian belakang keluar selama 30 detik. Panjang terowongan adalah ... m.",
    "options": [
      "450",
      "600",
      "300",
      "400",
      "500"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Jarak total = 20×30 = 600 m; dikurangi panjang kereta 100 m = 500 m."
  },
  {
    "id": 1619,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Pipa A dapat mengisi bak dalam 10 jam, pipa B dalam 20 jam, sedangkan pipa C dapat mengosongkan bak penuh dalam 20 jam. Jika semua pipa dibuka bersamaan pada bak kosong, bak penuh setelah ... menit.",
    "options": [
      "640",
      "440",
      "680",
      "600",
      "560"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Laju gabungan = 1/10 + 1/20 − 1/20 = 1/10 bak/jam; waktu 10 jam = 600 menit."
  },
  {
    "id": 1620,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Keran A saja dapat mengisi kolam dalam 12 jam. Jika keran A dan B dibuka bersamaan, kolam penuh dalam 8 jam. Keran B saja akan mengisi kolam sampai penuh dalam ... jam.",
    "options": [
      "26",
      "28",
      "25",
      "22",
      "24"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. 1/B = 1/8 − 1/12 = 1/24, maka B = 24 jam."
  },
  {
    "id": 1621,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Pipa A dapat mengisi bak dalam 6 jam, pipa B dalam 12 jam, sedangkan pipa C dapat mengosongkan bak penuh dalam 12 jam. Jika semua pipa dibuka bersamaan pada bak kosong, bak penuh setelah ... menit.",
    "options": [
      "336",
      "360",
      "408",
      "456",
      "264"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Laju gabungan = 1/6 + 1/12 − 1/12 = 1/6 bak/jam; waktu 6 jam = 360 menit."
  },
  {
    "id": 1622,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Keran A saja dapat mengisi kolam dalam 10 jam. Jika keran A dan B dibuka bersamaan, kolam penuh dalam 6 jam. Keran B saja akan mengisi kolam sampai penuh dalam ... jam.",
    "options": [
      "17",
      "16",
      "15",
      "19",
      "12"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 1/B = 1/6 − 1/10 = 1/15, maka B = 15 jam."
  },
  {
    "id": 1623,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Pipa A dapat mengisi bak dalam 8 jam, pipa B dalam 12 jam, sedangkan pipa C dapat mengosongkan bak penuh dalam 24 jam. Jika semua pipa dibuka bersamaan pada bak kosong, bak penuh setelah ... menit.",
    "options": [
      "360",
      "408",
      "432",
      "336",
      "264"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Laju gabungan = 1/8 + 1/12 − 1/24 = 1/6 bak/jam; waktu 6 jam = 360 menit."
  },
  {
    "id": 1624,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Beras seharga Rp12.000/kg dicampur dengan beras seharga Rp15.000/kg dengan perbandingan 2 : 3. Campuran dijual dengan untung 20%. Harga jual per kg adalah ...",
    "options": [
      "Rp16.560",
      "Rp15.810",
      "Rp15.560",
      "Rp15.060",
      "Rp17.310"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Harga pokok Rp13.800/kg; harga jual Rp16.560/kg."
  },
  {
    "id": 1625,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebanyak 50 liter larutan berkadar 20% dicampur dengan 50 liter larutan berkadar 40%. Kadar larutan campuran adalah ...",
    "options": [
      "33%",
      "25%",
      "30%",
      "27%",
      "32%"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. (50×20+50×40) : 100 = 30%."
  },
  {
    "id": 1626,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Rata-rata nilai 10 siswa kelas A adalah 90 dan rata-rata nilai 40 siswa kelas B adalah 70. Rata-rata nilai gabungan adalah ...",
    "options": [
      "72",
      "75",
      "73,5",
      "74",
      "73"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. (10×90+40×70) : 50 = 74."
  },
  {
    "id": 1627,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Larutan gula 80 liter berkadar 25% akan diencerkan dengan menambah air hingga berkadar 20%. Air yang harus ditambahkan adalah ... liter.",
    "options": [
      "10",
      "35",
      "45",
      "25",
      "20"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Gula 20 liter; volume akhir 100 liter; air tambahan 20 liter."
  },
  {
    "id": 1628,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Rina menabung Rp8.000.000 dengan bunga tunggal 10% per tahun. Setelah 9 bulan, besar bunga yang diperoleh adalah ...",
    "options": [
      "Rp690.000",
      "Rp630.000",
      "Rp660.000",
      "Rp570.000",
      "Rp600.000"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Bunga = Rp8.000.000 × 10% × 9/12 = Rp600.000."
  },
  {
    "id": 1629,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Modal Rp6.000.000 didepositokan dengan bunga majemuk 12% per tahun. Setelah 2 tahun, jumlah uang menjadi ...",
    "options": [
      "Rp7.626.400",
      "Rp7.526.400",
      "Rp7.476.400",
      "Rp7.440.000",
      "Rp7.576.400"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Rp6.000.000 × (1+12%)² = Rp7.526.400."
  },
  {
    "id": 1630,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Dengan bunga tunggal 6% per tahun, selama 10 bulan sebuah modal menghasilkan bunga Rp600.000. Modal tersebut adalah ...",
    "options": [
      "Rp12.000.000",
      "Rp11.000.000",
      "Rp13.000.000",
      "Rp14.000.000",
      "Rp11.500.000"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Modal = bunga : (6% × 10/12) = Rp12.000.000."
  },
  {
    "id": 1631,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Modal Rp12.000.000 dengan bunga majemuk 10% per tahun. Setelah 3 tahun, bunga yang diperoleh adalah ...",
    "options": [
      "Rp4.172.000",
      "Rp3.972.000",
      "Rp4.272.000",
      "Rp4.072.000",
      "Rp3.872.000"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Rp12.000.000 × (1+10%)³ − Rp12.000.000 = Rp3.972.000."
  },
  {
    "id": 1632,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Harga 4 pensil dan 1 buku adalah Rp24.000, sedangkan harga 1 pensil dan 3 buku adalah Rp33.500. Harga 4 pensil dan 2 buku adalah ...",
    "options": [
      "Rp32.500",
      "Rp29.500",
      "Rp34.000",
      "Rp35.500",
      "Rp38.500"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Dari kedua persamaan diperoleh pensil Rp3.500 dan buku Rp10.000; total Rp34.000."
  },
  {
    "id": 1633,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Harga 3 pensil dan 2 buku adalah Rp25.500, sedangkan harga 2 pensil dan 3 buku adalah Rp27.000. Harga 1 pensil dan 1 buku adalah ...",
    "options": [
      "Rp13.500",
      "Rp6.000",
      "Rp15.000",
      "Rp7.500",
      "Rp10.500"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Dari kedua persamaan diperoleh pensil Rp4.500 dan buku Rp6.000; total Rp10.500."
  },
  {
    "id": 1634,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Harga 4 pensil dan 1 buku adalah Rp20.000, sedangkan harga 1 pensil dan 3 buku adalah Rp32.500. Harga 1 pensil dan 1 buku adalah ...",
    "options": [
      "Rp12.500",
      "Rp11.000",
      "Rp9.500",
      "Rp14.000",
      "Rp8.000"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Dari kedua persamaan diperoleh pensil Rp2.500 dan buku Rp10.000; total Rp12.500."
  },
  {
    "id": 1635,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Harga 3 pensil dan 2 buku adalah Rp25.500, sedangkan harga 2 pensil dan 3 buku adalah Rp27.000. Harga 2 pensil dan 3 buku adalah ...",
    "options": [
      "Rp30.000",
      "Rp25.500",
      "Rp31.500",
      "Rp22.500",
      "Rp27.000"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Dari kedua persamaan diperoleh pensil Rp4.500 dan buku Rp6.000; total Rp27.000."
  },
  {
    "id": 1636,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Harga 3 pensil dan 2 buku adalah Rp18.000, sedangkan harga 2 pensil dan 3 buku adalah Rp22.000. Harga 2 pensil dan 3 buku adalah ...",
    "options": [
      "Rp25.000",
      "Rp26.500",
      "Rp22.000",
      "Rp17.500",
      "Rp20.500"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Dari kedua persamaan diperoleh pensil Rp2.000 dan buku Rp6.000; total Rp22.000."
  },
  {
    "id": 1637,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah bangun terdiri atas persegi panjang berukuran 66 cm × 42 cm dengan setengah lingkaran berdiameter 42 cm di salah satu sisi lebarnya. Luas bangun (π = 22/7) adalah ... cm².",
    "options": [
      "3458",
      "3465",
      "3479",
      "3451",
      "3486"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 66×42 + ½×22/7×21² = 3465."
  },
  {
    "id": 1638,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Volume sebuah tabung berjari-jari 7 cm dan tinggi 14 cm (π = 22/7) adalah ... cm³.",
    "options": [
      "2464",
      "2079",
      "2156",
      "2310",
      "2002"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 22/7×7²×14 = 2156."
  },
  {
    "id": 1639,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah segitiga siku-siku memiliki sisi miring 13 cm dan salah satu sisi siku-sikunya 5 cm. Luas segitiga tersebut adalah ... cm².",
    "options": [
      "36",
      "28",
      "30",
      "26",
      "32"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Sisi siku lain = √(13²−5²) = 12; luas = ½×5×12."
  },
  {
    "id": 1640,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Panjang busur lingkaran berjari-jari 7 cm dengan sudut pusat 45° (π = 22/7) adalah ... cm.",
    "options": [
      "11/2",
      "21/2",
      "-11/2",
      "99/14",
      "19/2"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. 45/360 × 2 × 22/7 × 7 = 11/2."
  },
  {
    "id": 1641,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah kubus memiliki panjang rusuk 12 cm. Jika setiap rusuknya diperpanjang menjadi 1,5 kali, selisih luas permukaan kubus baru dan lama adalah ... cm².",
    "options": [
      "1080",
      "1128",
      "1092",
      "1104",
      "1116"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Luas lama 864; baru 1944; selisih 1080."
  },
  {
    "id": 1642,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah kode terdiri atas 3 huruf berbeda yang dipilih dari 6 huruf, diikuti 2 angka yang boleh sama dari angka 1 sampai 4. Banyak kode yang mungkin adalah ...",
    "options": [
      "1536",
      "2432",
      "2048",
      "1920",
      "1408"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. P(6,3) × 4² = 1920."
  },
  {
    "id": 1643,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Dari 8 orang akan dipilih 3 orang sebagai panitia, tetapi dua orang tertentu (Ani dan Budi) tidak boleh terpilih bersamaan sekaligus. Banyak cara memilih panitia adalah ...",
    "options": [
      "66",
      "54",
      "50",
      "38",
      "34"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. C(8,3) − C(6,1) = 50."
  },
  {
    "id": 1644,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah kantong berisi 6 bola merah dan 4 bola biru. Dua bola diambil sekaligus secara acak. Peluang kedua bola berwarna merah adalah ...",
    "options": [
      "9/25",
      "2/15",
      "31/90",
      "1/3",
      "3/5"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. C(6,2)/C(10,2) = 1/3."
  },
  {
    "id": 1645,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Sebuah koin dilempar 5 kali. Peluang muncul paling sedikit satu sisi gambar adalah ...",
    "options": [
      "1/32",
      "31/32",
      "15/16",
      "5/32",
      "1/2"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 1 − (1/2)^5 = 31/32."
  },
  {
    "id": 1646,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Banyak cara 7 orang duduk melingkar mengelilingi meja bundar (susunan yang hanya diputar dianggap sama) adalah ...",
    "options": [
      "2880",
      "1440",
      "5040",
      "720",
      "120"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Permutasi siklis: (7−1)! = 720."
  },
  {
    "id": 1647,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Data nilai: 70, 69, 53, 79, 73, 74, 50, 71, 55. Selisih antara rata-rata dan median data tersebut adalah ... (mutlak).",
    "options": [
      "8",
      "6",
      "5",
      "4",
      "3"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Rata-rata 66; median 70."
  },
  {
    "id": 1648,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Rata-rata dari data 86, 59, 75, 78, 82, 73, 65 adalah ...",
    "options": [
      "71",
      "74",
      "72",
      "75",
      "78"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Jumlah 518 : 7 = 74."
  },
  {
    "id": 1649,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Rata-rata 7 nilai adalah 62. Setelah satu nilai 62 ditambahkan, rata-rata baru menjadi ...",
    "options": [
      "59",
      "66",
      "58",
      "62",
      "64"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. (434 + 62) : 8 = 62."
  },
  {
    "id": 1650,
    "moduleId": "matematika",
    "category": "Matematika Dasar",
    "question": "Median dari data 85, 58, 71, 77, 62, 68, 67, 75, 76 adalah ...",
    "options": [
      "71",
      "77",
      "65",
      "75",
      "63"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Urutkan data: 58, 62, 67, 68, 71, 75, 76, 77, 85; nilai tengah = 71."
  }
];
