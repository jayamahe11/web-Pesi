export const TKP2 = [
  {
    "id": 2801,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Menjelang jam tutup loket, seorang lansia dari luar kota datang dengan berkas yang kurang satu lembar fotokopi, sedangkan mesin fotokopi kantor rusak. Sikap Anda adalah ...",
    "options": [
      "menjelaskan bahwa berkas harus lengkap dan menyilakannya mengurus kekurangan itu sendiri",
      "menolak berkasnya karena jam layanan hampir habis dan memintanya pulang",
      "meminta orang lain di antrean membantunya karena Anda harus menutup loket tepat waktu",
      "menunjukkan tempat fotokopi terdekat dan memprioritaskan berkasnya begitu lengkap",
      "menjelaskan kekurangan berkasnya dengan ramah, lalu menuliskan daftar kelengkapan agar ia dapat kembali besok pagi"
    ],
    "answer": "D",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=3, B=1, C=2, D=5, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2802,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang pasien marah-marah karena antrean lama, padahal dokter sedang menangani pasien gawat darurat. Sikap Anda adalah ...",
    "options": [
      "menjelaskan bahwa dokter sedang menangani pasien gawat darurat, lalu memintanya bersabar",
      "menjawab bahwa semua pasien juga menunggu sehingga ia tidak perlu mengeluh",
      "mempersilakan pasien menyampaikan keluhannya kepada petugas lain di bagian pengaduan",
      "mendengarkan keluhannya dengan tenang, lalu meminta maaf dan menjelaskan perkiraan waktu tunggu",
      "mengabaikan pasien tersebut sampai ia berhenti marah dengan sendirinya"
    ],
    "answer": "D",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=4, B=2, C=3, D=5, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2803,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang warga menawarkan uang tambahan agar izin usahanya diproses lebih cepat dari antrean. Sikap Anda adalah ...",
    "options": [
      "menolak tawaran itu dengan singkat tanpa menjelaskan prosedur kepada warga",
      "menolak dengan sopan, menjelaskan tarif resmi, lalu melaporkan kejadian itu kepada atasan",
      "menolak sambil menyarankan warga menemui rekan yang biasa mengurus hal seperti itu",
      "menerima uang itu dan memprosesnya lebih cepat karena dianggap tidak merugikan siapa pun",
      "menolak dengan sopan dan menjelaskan bahwa semua pemohon dilayani sesuai antrean, tarif, dan prosedur resmi"
    ],
    "answer": "B",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=3, B=5, C=2, D=1, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2804,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Sistem antrean online kantor Anda error sehingga banyak warga datang tanpa nomor antrean. Sikap Anda adalah ...",
    "options": [
      "meminta warga pulang dan kembali lagi besok setelah sistem diperbaiki",
      "menutup loket sementara dan beristirahat sampai sistem berfungsi lagi",
      "melayani warga yang datang lebih awal sambil menunggu instruksi dari atasan",
      "melayani manual sesuai urutan kedatangan dengan daftar, lalu melapor ke TI dan mengumumkan kondisinya",
      "melapor ke bagian TI, lalu meminta warga menunggu sampai sistem kembali normal"
    ],
    "answer": "D",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=2, B=1, C=3, D=5, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2805,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang pengguna kursi roda datang untuk mengurus dokumen di kantor lantai dua yang tidak memiliki lift. Sikap Anda adalah ...",
    "options": [
      "memindahkan layanan ke lantai satu, lalu mengusulkan perbaikan akses kepada atasan",
      "turun ke lantai satu dan melayani warga tersebut dengan ramah, lalu mencatat kebutuhan akses fasilitas",
      "meminta warga mencari bantuan orang lain agar bisa naik ke lantai dua",
      "menawarkan agar berkasnya dititipkan kepada anggota keluarga yang bisa naik ke lantai dua",
      "menyatakan bahwa layanan hanya ada di lantai dua dan tidak dapat diubah"
    ],
    "answer": "A",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=4, C=2, D=3, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2806,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang warga menanyakan layanan yang bukan wewenang unit Anda. Sikap Anda adalah ...",
    "options": [
      "memberi jawaban sekenanya agar warga cepat meninggalkan loket",
      "menyebutkan unit yang berwenang beserta lokasi kantornya, lalu mempersilakan warga ke sana",
      "menjelaskan unit yang berwenang beserta alurnya, lalu menghubungi unit itu agar warga tak bolak-balik",
      "mengatakan bahwa hal itu bukan wewenang unit Anda dan menyarankan bertanya lagi",
      "menyuruh warga bertanya kepada petugas keamanan di depan kantor"
    ],
    "answer": "C",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=1, B=4, C=5, D=3, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2807,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda menyadari ada kesalahan ketik nama pada sertifikat yang baru diproses dan sudah dibawa pulang pemohon. Sikap Anda adalah ...",
    "options": [
      "segera menghubungi pemohon, meminta maaf, lalu memperbaiki dokumen tanpa biaya",
      "membiarkan kesalahan itu karena dokumen sudah selesai diproses",
      "menunggu sampai pemohon menyadari kesalahan itu dan datang melapor sendiri",
      "memperbaiki data di arsip internal saja tanpa mengabari pemohon",
      "menghubungi pemohon dan menjelaskan kesalahannya, lalu memintanya datang kembali untuk memperbaiki dokumen"
    ],
    "answer": "A",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=1, C=3, D=2, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2808,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Banyak warga mengeluh karena formulir layanan sulit dipahami. Sikap Anda adalah ...",
    "options": [
      "mengabaikan keluhan itu karena formulir sudah ditetapkan oleh pimpinan",
      "menyampaikan keluhan warga kepada atasan tanpa disertai usulan perbaikan",
      "meminta warga membaca petunjuk pengisian dengan lebih teliti",
      "membantu setiap warga yang kesulitan, lalu mencatat bagian formulir yang paling membingungkan",
      "menyusun usulan panduan pengisian yang sederhana, lalu menyediakannya di loket setelah disetujui atasan"
    ],
    "answer": "E",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=1, B=3, C=2, D=4, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2809,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Survei kepuasan menunjukkan layanan unit Anda dinilai lambat, padahal Anda merasa sudah bekerja maksimal. Sikap Anda adalah ...",
    "options": [
      "menerima hasil survei dengan lapang dada dan berusaha bekerja lebih cepat, lalu memantau hasilnya bulan depan",
      "mengabaikan hasil survei karena tidak memengaruhi penilaian kinerja Anda",
      "menganalisis penyebab keterlambatan bersama tim, lalu memperbaiki alur kerja",
      "menganggap penilaian warga tidak objektif karena Anda sudah bekerja maksimal",
      "meminta survei diulang dengan responden yang berbeda untuk memastikan hasilnya"
    ],
    "answer": "C",
    "explanation": "Aspek Pelayanan Publik. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=4, B=1, C=5, D=2, E=3. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2810,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Dalam proyek lintas unit, rekan dari unit lain terlambat menyerahkan data sehingga laporan Anda tertunda. Sikap Anda adalah ...",
    "options": [
      "melaporkan kelalaian rekan itu kepada atasan tanpa menghubunginya lebih dulu",
      "menghubungi rekan itu untuk menanyakan kendalanya, lalu menawarkan bantuan dan menyepakati tenggat baru",
      "menyelesaikan bagian Anda lebih dahulu dan menunggu data dari unit tersebut",
      "mengingatkan rekan itu melalui pesan, lalu menyiapkan bagian laporan lain sambil menunggu",
      "menyalahkan rekan itu di grup kerja agar semua orang mengetahuinya"
    ],
    "answer": "B",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=2, B=5, C=3, D=4, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2811,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda baru dipindahkan ke unit baru dan beberapa senior tampak enggan berbagi informasi. Sikap Anda adalah ...",
    "options": [
      "mencari informasi dari dokumen kerja dengan teliti, lalu bertanya kepada rekan lain yang bersedia membantu",
      "menunggu para senior menjelaskan sendiri hal-hal yang perlu Anda ketahui",
      "menghindari para senior dan memilih bekerja sendiri di unit baru",
      "mendekati mereka dengan hormat untuk meminta bimbingan, lalu menawarkan bantuan",
      "mengeluh kepada atasan bahwa para senior tidak mau bekerja sama"
    ],
    "answer": "D",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=4, B=3, C=1, D=5, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2812,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Dua rekan satu tim berselisih sehingga pekerjaan terhambat, dan keduanya meminta Anda memihak. Sikap Anda adalah ...",
    "options": [
      "menemui masing-masing untuk mendengarkan, lalu mempertemukan mereka mencari kesepakatan tanpa memihak",
      "menceritakan perselisihan itu kepada rekan-rekan lain di kantor",
      "memilih tidak ikut campur karena itu urusan kedua rekan tersebut",
      "menyarankan keduanya menyelesaikan masalah secara pribadi, lalu memantau perkembangan pekerjaan tim",
      "memihak rekan yang lebih dekat dengan Anda agar tetap punya sekutu"
    ],
    "answer": "A",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=1, C=3, D=4, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2813,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Instansi lain meminta data yang penyebarannya memerlukan izin pimpinan Anda. Sikap Anda adalah ...",
    "options": [
      "menyarankan instansi itu mengirim surat resmi lalu menunggu balasan",
      "menolak permintaan tersebut tanpa memberikan penjelasan apa pun",
      "meneruskan surat permintaan tersebut kepada pimpinan dengan lengkap, lalu menunggu keputusan untuk disampaikan",
      "memberikan data secara informal agar permintaan cepat terselesaikan",
      "menjelaskan prosedur kepada instansi itu, lalu meneruskan permintaan kepada pimpinan"
    ],
    "answer": "E",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=3, B=1, C=4, D=2, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2814,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Dalam rapat koordinasi, usulan Anda ditolak oleh sebagian besar peserta. Sikap Anda adalah ...",
    "options": [
      "meninggalkan ruang rapat karena merasa usulan Anda tidak dihargai",
      "menerima keputusan itu, lalu mendukung pelaksanaan hasil rapat sepenuhnya",
      "diam saja selama sisa rapat dan tidak memberi tanggapan lagi",
      "mengajukan keberatan berulang kali sampai rapat berlangsung terlalu lama",
      "menerima keputusan dan menanyakan alasan penolakan, lalu menyempurnakan usulan untuk dibahas kembali"
    ],
    "answer": "E",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=1, B=4, C=3, D=2, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2815,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda mewakili instansi dalam forum dengan pemangku kepentingan yang pandangannya saling berlawanan. Sikap Anda adalah ...",
    "options": [
      "menyampaikan posisi instansi dengan jelas dan sopan di depan semua pihak, lalu mencatat tanggapan mereka",
      "mempelajari kepentingan tiap pihak, lalu mengarahkan diskusi ke titik temu",
      "mencatat semua masukan lalu melaporkannya kepada atasan setelah forum",
      "menyerang pihak yang bersikap berlawanan dengan instansi Anda",
      "mengikuti pendapat pihak yang paling dominan agar forum cepat selesai"
    ],
    "answer": "B",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=4, B=5, C=3, D=1, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2816,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Tim lain berhasil membuat inovasi yang berkaitan erat dengan pekerjaan unit Anda. Sikap Anda adalah ...",
    "options": [
      "mengajak tim itu berbagi pengalaman, lalu mengadaptasi bagian inovasinya yang relevan bagi unit Anda",
      "menganggap inovasi itu tidak cocok bagi unit Anda tanpa mencobanya",
      "menunggu instruksi atasan sebelum mempelajari inovasi tim lain",
      "membaca laporan inovasi tim tersebut, lalu mendiskusikannya dengan rekan satu unit",
      "meremehkan keberhasilan tim tersebut di depan rekan lain"
    ],
    "answer": "A",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=2, C=3, D=4, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2817,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda ingin memperluas jejaring dengan komunitas profesi di luar instansi tanpa mengganggu tugas utama. Sikap Anda adalah ...",
    "options": [
      "mengikuti kegiatan komunitas hanya bila diperintahkan oleh atasan",
      "menolak ajakan komunitas karena takut dianggap mencari muka",
      "mengikuti kegiatan komunitas bila ada undangan yang sesuai tugas, lalu menceritakan manfaatnya kepada rekan",
      "aktif mengikuti komunitas di luar jam kerja, lalu membagikan ilmunya kepada rekan",
      "memusatkan diri pada pekerjaan karena jejaring dianggap kurang penting"
    ],
    "answer": "D",
    "explanation": "Aspek Jejaring Kerja. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=3, B=1, C=4, D=5, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2818,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Rekan baru Anda berasal dari budaya yang berbeda dan kebiasaannya sering dianggap aneh oleh rekan lain. Sikap Anda adalah ...",
    "options": [
      "mengajaknya berbincang untuk mengenal kebiasaannya, lalu mengingatkan rekan lain agar saling menghargai",
      "bersikap ramah dan menghargai kebiasaannya, lalu melibatkannya dalam pekerjaan tim",
      "menjaga jarak agar tidak dianggap berpihak kepada salah satu pihak",
      "ikut menertawakan kebiasaannya bersama rekan-rekan yang lain",
      "bersikap netral dan tidak ikut campur dalam pembicaraan rekan lain"
    ],
    "answer": "A",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=4, C=2, D=1, E=3. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2819,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Atasan baru Anda jauh lebih muda dan berasal dari suku yang berbeda. Sikap Anda adalah ...",
    "options": [
      "meremehkan arahannya karena ia jauh lebih muda dari Anda",
      "menggunjingkan atasan itu bersama rekan-rekan sekantor",
      "bekerja seperlunya saja sesuai uraian tugas Anda",
      "melaksanakan tugas dengan baik sesuai arahan atasan, lalu melaporkan hasilnya tepat waktu setiap kali",
      "menghormati kebijakannya dan belajar dari kelebihannya, lalu menjaga komunikasi"
    ],
    "answer": "E",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=2, B=1, C=3, D=4, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2820,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Rekan Anda yang beragama berbeda meminta izin mengikuti kegiatan ibadah yang bertepatan dengan rapat penting. Sikap Anda adalah ...",
    "options": [
      "mengabaikan permintaan itu dan tetap menggelar rapat sesuai jadwal",
      "mengizinkannya beribadah, lalu memintanya menyusul atau membaca notulen rapat",
      "menyuruhnya mengutamakan rapat karena agenda sudah ditetapkan",
      "meminta ia memilih salah satu antara ibadah dan rapat tersebut",
      "mengusulkan penjadwalan ulang atau pembagian tugas agar ia tetap dapat beribadah dan berpartisipasi"
    ],
    "answer": "E",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=1, B=4, C=2, D=3, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2821,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Tetangga Anda yang berbeda adat menggelar acara yang menimbulkan kebisingan hingga larut malam. Sikap Anda adalah ...",
    "options": [
      "menemui mereka baik-baik dan menghargai acaranya, lalu menyepakati batas waktu",
      "menegur mereka dengan nada tinggi di tengah acara berlangsung",
      "bersabar dan menutup pintu rumah sampai acara selesai",
      "menyampaikan keberatan secara sopan kepada pengurus RT, lalu memintanya memediasi dengan tetangga",
      "melaporkan kepada polisi tanpa berbicara lebih dulu dengan tetangga"
    ],
    "answer": "A",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=2, C=3, D=4, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2822,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Warga sebuah desa menolak program pemerintah karena dianggap bertentangan dengan kebiasaan setempat. Sikap Anda adalah ...",
    "options": [
      "memaksakan pelaksanaan program dengan menyebut aturan yang berlaku",
      "melaporkan kepada atasan bahwa warga desa menolak program tersebut",
      "menghentikan pelaksanaan program di desa itu untuk seterusnya",
      "berdialog dengan tokoh adat untuk memahami kekhawatiran warga, lalu menyesuaikan pendekatan tanpa mengubah tujuan",
      "menjelaskan manfaat program dengan bahasa sederhana, lalu membuka sesi tanya jawab warga"
    ],
    "answer": "D",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=2, B=3, C=1, D=5, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2823,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang rekan mengunggah candaan bernuansa SARA di grup kerja. Sikap Anda adalah ...",
    "options": [
      "mengabaikannya karena candaan itu dianggap sekadar bercanda",
      "mengingatkan semua anggota di grup agar tidak mengulangi, lalu menyarankan topik yang lebih pantas",
      "menyebarkan candaan itu kepada kenalan di luar kantor",
      "membalas dengan candaan serupa agar suasana tetap akrab",
      "menegurnya secara pribadi dan santun, lalu mengusulkan aturan etika grup"
    ],
    "answer": "E",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=3, B=4, C=1, D=2, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2824,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda ditugaskan di daerah yang bahasanya belum Anda kuasai. Sikap Anda adalah ...",
    "options": [
      "hanya bergaul dengan sesama pendatang agar tidak canggung",
      "memakai penerjemah pada awal masa tugas, lalu perlahan belajar bahasa setempat",
      "mempelajari bahasa dan kebiasaan setempat, lalu bergaul dengan warga sambil bersikap ramah",
      "berkomunikasi seperlunya saja dengan warga setempat",
      "meminta dipindahkan ke daerah lain yang bahasanya dikuasai"
    ],
    "answer": "C",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=2, B=4, C=5, D=3, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2825,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Dalam pembagian tugas lapangan, seorang rekan mengusulkan agar rekan perempuan tidak dilibatkan karena dianggap kurang mampu. Sikap Anda adalah ...",
    "options": [
      "menyampaikan bahwa penugasan berdasar kompetensi, lalu mengusulkan kriteria objektif",
      "diam saja agar tidak menimbulkan perdebatan di dalam rapat",
      "mendukung usulan itu dengan alasan kebiasaan yang sudah berlaku",
      "menyatakan keberatan secara halus kepada rekan yang mengusulkannya, lalu menunggu tanggapan dari rapat",
      "ikut menyetujui usulan itu agar rapat cepat selesai"
    ],
    "answer": "A",
    "explanation": "Aspek Sosial Budaya. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=3, C=1, D=4, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2826,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda menerima email berisi tautan 'pembaruan data kepegawaian' yang meminta kata sandi akun. Sikap Anda adalah ...",
    "options": [
      "mengklik tautan itu tetapi tidak mengisi data apa pun",
      "mengisi data yang diminta karena email tampak resmi",
      "menanyakan kepada rekan apakah mereka juga menerima email serupa",
      "tidak mengklik tautan itu, lalu menghapus emailnya dari kotak masuk",
      "tidak mengklik dan memverifikasi lewat saluran resmi, lalu melaporkan email itu sebagai phishing"
    ],
    "answer": "E",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=2, B=1, C=3, D=4, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2827,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Untuk menyelesaikan laporan, rekan Anda menawarkan kata sandi akunnya agar Anda dapat mengakses data yang belum menjadi hak Anda. Sikap Anda adalah ...",
    "options": [
      "menolak, tetapi meminta rekan mengunduh data lalu mengirimkannya lewat pesan pribadi",
      "tidak mengklik tautan itu dan menghapus emailnya, lalu mengingatkan rekan satu ruangan agar berhati-hati",
      "tidak mengklik dan memverifikasi lewat saluran resmi, lalu melaporkannya",
      "menerima tawaran itu dan memakai akunnya secara rutin",
      "memakai akun rekan itu hanya sekali lalu segera keluar dari sistem"
    ],
    "answer": "C",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=3, B=4, C=5, D=1, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2828,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda menemukan celah keamanan pada aplikasi internal instansi. Sikap Anda adalah ...",
    "options": [
      "mengujinya lebih jauh untuk memastikan celah itu benar-benar ada",
      "mengabarkannya di media sosial agar cepat diperbaiki",
      "mendokumentasikan temuan tanpa mengeksploitasinya, lalu segera melapor kepada tim TI dan atasan",
      "segera memberi tahu rekan terdekat, lalu bersama-sama membicarakan cara melaporkannya",
      "menunggu sampai ada pihak yang menanyakan temuan tersebut"
    ],
    "answer": "C",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=2, B=1, C=5, D=4, E=3. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2829,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Instansi menerapkan aplikasi baru dan sejumlah rekan senior kesulitan menggunakannya. Sikap Anda adalah ...",
    "options": [
      "mengejek ketidakmampuan mereka di depan rekan yang lain",
      "menyuruh mereka belajar sendiri karena aplikasinya mudah dipahami",
      "menyarankan mereka mengikuti pelatihan resmi yang disediakan instansi",
      "mendokumentasikan temuan tanpa mengeksploitasinya, lalu segera melapor kepada tim TI",
      "segera memberi tahu rekan terdekat, lalu bersama-sama membicarakan cara melaporkannya kepada tim TI"
    ],
    "answer": "D",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=1, B=2, C=3, D=5, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2830,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Sebuah informasi hoaks tentang kebijakan pemerintah beredar di grup WhatsApp keluarga Anda. Sikap Anda adalah ...",
    "options": [
      "menyampaikan bahwa informasi itu hoaks, lalu meminta anggota keluarga tidak meneruskannya",
      "tidak membalas pesan itu supaya tidak memicu perdebatan",
      "ikut meneruskannya agar lebih banyak orang waspada",
      "memeriksa kebenarannya di sumber resmi, lalu menyampaikan klarifikasi dengan tautan dan mengimbau agar tidak disebarkan",
      "menunggu anggota keluarga lain yang mengoreksi informasi itu"
    ],
    "answer": "D",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=4, B=3, C=1, D=5, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2831,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Flashdisk pribadi Anda yang berisi data peserta layanan hilang. Sikap Anda adalah ...",
    "options": [
      "memeriksa kebenarannya di sumber resmi, lalu menyampaikan klarifikasi disertai tautan",
      "menyembunyikan kejadian itu sampai ada yang menanyakan",
      "menyampaikan bahwa informasi itu hoaks, lalu meminta semua anggota keluarga tidak meneruskannya",
      "mencari dulu dengan harapan ditemukan sebelum melaporkannya",
      "menyalahkan rekan yang terakhir meminjam flashdisk tersebut"
    ],
    "answer": "A",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=2, C=4, D=3, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2832,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Tugas besar Anda memiliki batas waktu ketat dan ada aplikasi otomatisasi yang dapat mempercepat, tetapi belum dipakai di instansi. Sikap Anda adalah ...",
    "options": [
      "tetap memakai cara manual walaupun waktu semakin mepet",
      "mengabaikan target waktu karena aplikasinya belum disetujui",
      "mempelajari dan menguji aplikasi pada data tiruan, lalu mengusulkannya kepada atasan dengan analisis risiko",
      "memakai aplikasi itu tanpa memberi tahu siapa pun",
      "mengusulkan pemakaian aplikasi itu kepada atasan, lalu menunggu persetujuan sebelum memakainya"
    ],
    "answer": "C",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=3, B=1, C=5, D=2, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2833,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda akan menyosialisasikan layanan baru kepada masyarakat yang banyak belum melek digital. Sikap Anda adalah ...",
    "options": [
      "menguji aplikasi pada data tiruan, lalu mengusulkannya kepada atasan dengan analisis risiko",
      "mengirim surat edaran kepada pihak kelurahan setempat",
      "tidak menyosialisasikannya karena sudah tersedia di situs resmi",
      "mengandalkan warga yang paham teknologi untuk meneruskan informasi",
      "mengusulkan pemakaian aplikasi itu kepada atasan dengan alasan yang kuat, lalu menunggu persetujuan"
    ],
    "answer": "A",
    "explanation": "Aspek Teknologi Informasi dan Komunikasi. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=3, C=1, D=2, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2834,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Atasan memberi dua tugas penting dengan tenggat sama, dan Anda tidak mungkin menyelesaikan keduanya sendirian. Sikap Anda adalah ...",
    "options": [
      "mengerjakan keduanya sekaligus dengan menambah jam kerja, lalu melapor setelah selesai",
      "menyusun prioritas dan mengonsultasikannya kepada atasan, lalu meminta bantuan rekan bila diperlukan",
      "mengeluh kepada rekan tentang beban kerja yang terlalu berat",
      "mengerjakan satu tugas saja tanpa melaporkannya kepada atasan",
      "mengerjakan tugas yang paling mudah terlebih dahulu"
    ],
    "answer": "B",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=4, B=5, C=2, D=1, E=3. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2835,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda menemukan kesalahan pada laporan yang sudah diserahkan kepada atasan. Sikap Anda adalah ...",
    "options": [
      "menyalahkan data yang diberikan rekan sebagai penyebab kesalahan",
      "menyembunyikan kesalahan itu agar tidak diketahui siapa pun",
      "mengerjakan keduanya sekaligus dengan menambah jam kerja sendiri, lalu melapor setelah semuanya selesai",
      "menyusun prioritas dan mengonsultasikannya kepada atasan, lalu meminta bantuan bila perlu",
      "menunggu sampai atasan sendiri yang menyadari kesalahan itu"
    ],
    "answer": "D",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=2, B=1, C=4, D=5, E=3. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2836,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Karena rekan sakit, Anda diminta mengerjakan tugas di luar jabatan Anda. Sikap Anda adalah ...",
    "options": [
      "menolak dan menyalahkan atasan yang dianggap tidak adil",
      "menolak karena tugas itu bukan bagian dari tugas pokok Anda",
      "menerima dengan bertanggung jawab dan memastikan lingkup tugasnya, lalu tetap menuntaskan tugas utama",
      "menerima tugas itu sambil menggerutu kepada rekan lain",
      "menerima dan mengerjakannya sebisa mungkin selama rekan belum masuk kerja"
    ],
    "answer": "C",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=1, B=2, C=5, D=3, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2837,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Atasan memberi instruksi yang menurut Anda tidak sesuai dengan peraturan yang berlaku. Sikap Anda adalah ...",
    "options": [
      "menjalankan instruksi itu tanpa bertanya apa pun",
      "menjalankan instruksi sambil mencatat kejadiannya untuk berjaga-jaga",
      "menolak instruksi itu di depan banyak orang",
      "menerima tugas itu dan mengerjakannya sebisa mungkin sampai rekan yang sakit kembali masuk kerja",
      "menerima dengan bertanggung jawab dan memastikan lingkup tugasnya"
    ],
    "answer": "E",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=2, B=3, C=1, D=4, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2838,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Pada proyek besar, sebagian anggota tim ingin memangkas langkah pengendalian mutu demi mengejar tenggat. Sikap Anda adalah ...",
    "options": [
      "diam saja agar tidak dianggap menghambat penyelesaian proyek",
      "tetap menjalankan semua langkah mutu pada bagian Anda, lalu melaporkan perbedaan pendapat itu",
      "menjelaskan risikonya dan mengusulkan efisiensi tanpa menurunkan standar, lalu menyepakati rencana dengan atasan",
      "mengikuti keputusan mayoritas tim demi menjaga kekompakan",
      "ikut memangkas langkah itu dan menyembunyikannya dari atasan"
    ],
    "answer": "C",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=2, B=4, C=5, D=3, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2839,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda menguasai keahlian baru yang bermanfaat, tetapi jabatan Anda belum membutuhkannya. Sikap Anda adalah ...",
    "options": [
      "mengabaikan keahlian itu dan tidak mengembangkannya lagi",
      "tetap menjalankan semua langkah mutu pada bagian Anda, lalu melaporkan perbedaan pendapat itu kepada atasan",
      "menjelaskan risikonya dan mengusulkan efisiensi tanpa menurunkan standar mutu",
      "menunggu sampai jabatan Anda benar-benar membutuhkannya",
      "merasa keahlian itu sia-sia karena tidak terpakai"
    ],
    "answer": "C",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=1, B=4, C=5, D=3, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2840,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Pekerjaan Anda selesai lebih awal, sementara beberapa rekan masih kewalahan. Sikap Anda adalah ...",
    "options": [
      "beristirahat sampai jam kerja berakhir seperti biasa",
      "pulang lebih awal tanpa meminta izin kepada atasan",
      "memeriksa ulang hasil kerja Anda, lalu menawarkan bantuan kepada rekan yang membutuhkan",
      "memakai waktu itu untuk mengurus keperluan pribadi",
      "meminta tugas tambahan dari atasan, lalu mengerjakannya dengan teliti"
    ],
    "answer": "C",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=3, B=1, C=5, D=2, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2841,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda dipuji atasan atas hasil kerja yang sebenarnya dikerjakan bersama tim. Sikap Anda adalah ...",
    "options": [
      "diam saja dan tidak menanggapi pujian tersebut",
      "memeriksa ulang hasil kerja Anda, lalu menawarkan bantuan kepada rekan",
      "meminta tugas tambahan dari atasan agar waktu luang terpakai, lalu mengerjakannya dengan teliti",
      "menyebut bahwa rekan-rekan lain tidak berkontribusi sama sekali",
      "menerima pujian itu seolah-olah hasil kerja Anda sendiri"
    ],
    "answer": "B",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=3, B=5, C=4, D=1, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2842,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Rekanan menawarkan hadiah mahal kepada Anda terkait keputusan pengadaan yang akan Anda ambil. Sikap Anda adalah ...",
    "options": [
      "menerima dahulu lalu mengembalikannya setelah proses pengadaan selesai",
      "menolak dengan tegas, lalu tidak membahasnya lagi dengan rekanan",
      "menolak dengan sopan dan melaporkannya sebagai gratifikasi, lalu memutuskan murni berdasarkan aturan",
      "menerima dan meminta tambahan hadiah lain dari rekanan itu",
      "menerima dan menyimpannya karena merasa tidak akan terpengaruh"
    ],
    "answer": "C",
    "explanation": "Aspek Profesionalisme. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=3, B=4, C=5, D=1, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2843,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang rekan sering mengajak membenci kelompok tertentu dan menyatakan Pancasila bertentangan dengan agama. Sikap Anda adalah ...",
    "options": [
      "ikut menyebarkan pandangan itu kepada orang-orang lain",
      "menghindari pembicaraan tentang topik itu setiap kali ia membahasnya",
      "menolak dengan tegas pemberian itu, lalu tidak membahasnya lagi dengan rekanan tersebut",
      "mengikuti pandangannya agar Anda tidak dijauhi oleh rekan",
      "menolak dengan sopan dan melaporkannya sebagai gratifikasi sesuai ketentuan"
    ],
    "answer": "E",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah E. Skor tiap pilihan: A=1, B=3, C=4, D=2, E=5. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2844,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda menemukan ujaran kebencian terhadap pemerintah dan etnis tertentu di media sosial. Sikap Anda adalah ...",
    "options": [
      "tidak menanggapi dengan emosi, lalu melaporkan konten kepada pihak berwenang dan menyebarkan konten positif",
      "mengabaikannya karena dianggap bukan urusan Anda",
      "membalas dengan ujaran yang sama kerasnya",
      "membagikan ulang konten itu kepada teman-teman Anda",
      "melaporkan konten itu kepada platform terkait, lalu memblokir akun penyebarnya"
    ],
    "answer": "A",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=3, C=2, D=1, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2845,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang kenalan mengajak Anda bergabung dengan organisasi yang menolak sistem negara dan membenarkan kekerasan. Sikap Anda adalah ...",
    "options": [
      "bergabung dengan organisasi itu karena rasa penasaran",
      "menghadiri pertemuannya sekadar untuk mengetahui isinya",
      "tidak menanggapi dengan emosi, lalu melaporkan konten kepada pihak berwenang",
      "menolak secara halus tanpa melaporkannya kepada siapa pun",
      "melaporkan konten itu kepada platform terkait, lalu memblokir akun penyebarnya agar tidak menjangkau orang lain"
    ],
    "answer": "C",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah C. Skor tiap pilihan: A=1, B=2, C=5, D=3, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2846,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Saat upacara bendera, seorang bawahan Anda menolak menghormat bendera dengan alasan keyakinan. Sikap Anda adalah ...",
    "options": [
      "membiarkannya karena hal itu menyangkut keyakinan pribadi",
      "berbicara baik-baik tentang makna hormat bendera, lalu melibatkan atasan atau pembina bila perlu",
      "mencatat kejadian itu lalu melaporkannya kepada pimpinan",
      "mempermalukannya di depan seluruh peserta upacara",
      "menegurnya dan mengingatkan aturan pelaksanaan upacara, lalu mencatat tanggapannya"
    ],
    "answer": "B",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=2, B=5, C=3, D=1, E=4. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2847,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Dalam diskusi kantor, seorang rekan membenarkan aksi kekerasan terhadap kelompok yang dianggap menyimpang. Sikap Anda adalah ...",
    "options": [
      "menyemangati rekan itu karena merasa pendapatnya ada benarnya",
      "mengalihkan pembicaraan ke topik lain agar suasana reda",
      "menegurnya dan mengingatkan aturan pelaksanaan upacara, lalu mencatat tanggapannya untuk dilaporkan",
      "berbicara baik-baik tentang makna hormat bendera, lalu melibatkan atasan bila perlu",
      "diam saja dan tidak menanggapi pendapat tersebut"
    ],
    "answer": "D",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah D. Skor tiap pilihan: A=1, B=3, C=4, D=5, E=2. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2848,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Anda menerima pesan berantai berisi seruan demonstrasi yang berpotensi anarkistis dan menyebut nama instansi Anda. Sikap Anda adalah ...",
    "options": [
      "meneruskan pesan itu kepada satu teman dekat saja",
      "memeriksa sumbernya dan memberi tahu atasan, lalu mengimbau penyampaian pendapat secara damai",
      "meneruskan pesan itu ke banyak grup agar semua tahu",
      "tidak menyebarkan pesan itu, lalu menghapusnya dari semua grup",
      "menghapus pesan itu tanpa melakukan tindakan lain"
    ],
    "answer": "B",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=2, B=5, C=1, D=4, E=3. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2849,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Sebagai pembina kegiatan remaja, Anda mendapati salah satu pemateri menyampaikan ajaran yang menolak toleransi. Sikap Anda adalah ...",
    "options": [
      "mengganti pemateri itu pada sesi berikutnya, lalu meluruskan materi kepada peserta",
      "menghentikan sesi dengan sopan dan meluruskan materi, lalu melapor kepada pengurus serta menyeleksi pemateri",
      "membiarkan pemateri sampai sesinya berakhir",
      "mengevaluasi materi itu setelah seluruh acara selesai",
      "mendukung materi itu dan membagikannya kepada peserta"
    ],
    "answer": "B",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah B. Skor tiap pilihan: A=4, B=5, C=2, D=3, E=1. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  },
  {
    "id": 2850,
    "moduleId": "tkp2",
    "category": "TKP#2",
    "question": "Seorang rekan mulai menutup diri dan menyatakan ingin bergabung dengan kelompok ekstrem. Sikap Anda adalah ...",
    "options": [
      "mendekatinya dengan empati dan mengarahkannya ke pembimbing, lalu berkonsultasi dengan atasan atau pihak berwenang",
      "menasihatinya secara pribadi, lalu memantau perubahan sikapnya dalam beberapa waktu",
      "mengabaikannya karena itu urusan pribadi rekan tersebut",
      "menjauhinya agar Anda tidak ikut terpengaruh",
      "memantau perkembangannya tanpa melakukan tindakan lain"
    ],
    "answer": "A",
    "explanation": "Aspek Anti Radikalisme. Jawaban terbaik (skor 5) adalah A. Skor tiap pilihan: A=5, B=4, C=1, D=2, E=3. Pilihan terbaik menggabungkan sikap profesional, solusi konkret, dan prosedur yang benar."
  }
];
