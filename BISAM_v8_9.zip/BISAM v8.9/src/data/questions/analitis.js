export const ANALITIS = [
  {
    "id": 1701,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam pelari (Bagas, Cindy, Elsa, Fikri, Gina, Hendra) mengikuti lomba lari tanpa ada yang finis bersamaan. Di antara Cindy dan Elsa terdapat tepat 3 pelari yang finis. Hendra finis tepat satu peringkat setelah Fikri. Di antara Elsa dan Bagas terdapat tepat 4 pelari yang finis. Fikri tidak finis pada peringkat 4. Cindy finis lebih awal daripada Gina. Pada peringkat berapa Hendra finis?",
    "options": [
      "3",
      "1",
      "4",
      "5",
      "2"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Susun semua syarat sehingga hanya satu peringkat yang mungkin untuk pelari tersebut."
  },
  {
    "id": 1702,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam pelari (Arman, Bagas, Cindy, Dani, Elsa, Fikri) mengikuti lomba lari tanpa ada yang finis bersamaan. Di antara Arman dan Bagas terdapat tepat 1 pelari yang finis. Bagas finis lebih awal daripada Cindy. Arman finis tepat satu peringkat setelah Fikri. Di antara Fikri dan Dani terdapat tepat 2 pelari yang finis. Cindy finis lebih awal daripada Elsa. Pada peringkat berapa Dani finis?",
    "options": [
      "4",
      "3",
      "2",
      "5",
      "1"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Susun semua syarat sehingga hanya satu peringkat yang mungkin untuk pelari tersebut."
  },
  {
    "id": 1703,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam pelari (Arman, Cindy, Dani, Elsa, Fikri, Hendra) mengikuti lomba lari tanpa ada yang finis bersamaan. Dani tidak finis pada peringkat 1. Cindy finis lebih awal daripada Fikri. Hendra finis lebih awal daripada Elsa. Hendra finis lebih awal daripada Cindy. Dani finis lebih awal daripada Arman. Pada peringkat berapa Hendra finis?",
    "options": [
      "3",
      "5",
      "4",
      "2",
      "1"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Susun semua syarat sehingga hanya satu peringkat yang mungkin untuk pelari tersebut."
  },
  {
    "id": 1704,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam pelari (Cindy, Dani, Elsa, Fikri, Gina, Hendra) mengikuti lomba lari tanpa ada yang finis bersamaan. Di antara Dani dan Elsa terdapat tepat 3 pelari yang finis. Hendra finis lebih awal daripada Cindy. Di antara Hendra dan Cindy terdapat tepat 3 pelari yang finis. Di antara Cindy dan Elsa terdapat tepat 2 pelari yang finis. Pada peringkat berapa Dani finis?",
    "options": [
      "6",
      "3",
      "1",
      "4",
      "2"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Susun semua syarat sehingga hanya satu peringkat yang mungkin untuk pelari tersebut."
  },
  {
    "id": 1705,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam pelari (Cindy, Dani, Elsa, Fikri, Gina, Hendra) mengikuti lomba lari tanpa ada yang finis bersamaan. Cindy finis lebih awal daripada Dani. Hendra finis tepat satu peringkat setelah Dani. Di antara Fikri dan Gina terdapat tepat 3 pelari yang finis. Hendra finis lebih awal daripada Elsa. Pada peringkat berapa Dani finis?",
    "options": [
      "5",
      "2",
      "1",
      "4",
      "3"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Susun semua syarat sehingga hanya satu peringkat yang mungkin untuk pelari tersebut."
  },
  {
    "id": 1706,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam pelari (Arman, Cindy, Dani, Elsa, Fikri, Hendra) mengikuti lomba lari tanpa ada yang finis bersamaan. Fikri dan Elsa tidak finis berurutan. Arman finis tepat satu peringkat setelah Cindy. Di antara Fikri dan Cindy terdapat tepat 1 pelari yang finis. Di antara Hendra dan Cindy terdapat tepat 1 pelari yang finis. Dani dan Fikri tidak finis berurutan. Pada peringkat berapa Arman finis?",
    "options": [
      "5",
      "2",
      "3",
      "1",
      "4"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Susun semua syarat sehingga hanya satu peringkat yang mungkin untuk pelari tersebut."
  },
  {
    "id": 1707,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Lima kegiatan (Inventaris, Laporan, Presentasi, Rapat, Survei) dikerjakan pada hari Senin sampai Jumat, masing-masing satu kegiatan per hari. Di antara pengerjaan Inventaris dan Laporan terdapat tepat 1 hari kerja. Laporan tidak dikerjakan pada hari Senin. Inventaris dikerjakan sebelum Presentasi. Laporan tidak dikerjakan pada hari Rabu. Presentasi dikerjakan sebelum Rapat. Kegiatan yang dikerjakan pada hari Senin adalah ...",
    "options": [
      "Rapat",
      "Inventaris",
      "Presentasi",
      "Laporan",
      "Survei"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Dari semua syarat hanya ada satu kegiatan yang mungkin pada hari tersebut."
  },
  {
    "id": 1708,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Lima kegiatan (Audit, Laporan, Pelatihan, Rapat, Survei) dikerjakan pada hari Senin sampai Jumat, masing-masing satu kegiatan per hari. Rapat dikerjakan sebelum Audit. Laporan dikerjakan sebelum Audit. Audit dikerjakan sebelum Survei. Pelatihan dikerjakan sebelum Audit. Kegiatan yang dikerjakan pada hari Kamis adalah ...",
    "options": [
      "Pelatihan",
      "Rapat",
      "Laporan",
      "Survei",
      "Audit"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Dari semua syarat hanya ada satu kegiatan yang mungkin pada hari tersebut."
  },
  {
    "id": 1709,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Lima kegiatan (Audit, Inventaris, Pelatihan, Presentasi, Rapat) dikerjakan pada hari Senin sampai Jumat, masing-masing satu kegiatan per hari. Di antara pengerjaan Pelatihan dan Rapat terdapat tepat 2 hari kerja. Di antara pengerjaan Presentasi dan Audit terdapat tepat 1 hari kerja. Audit dikerjakan tepat sehari setelah Pelatihan. Rapat dikerjakan sebelum Audit. Kegiatan yang dikerjakan pada hari Selasa adalah ...",
    "options": [
      "Audit",
      "Inventaris",
      "Pelatihan",
      "Presentasi",
      "Rapat"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dari semua syarat hanya ada satu kegiatan yang mungkin pada hari tersebut."
  },
  {
    "id": 1710,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Lima kegiatan (Audit, Inventaris, Laporan, Pelatihan, Presentasi) dikerjakan pada hari Senin sampai Jumat, masing-masing satu kegiatan per hari. Presentasi dikerjakan sebelum Inventaris. Laporan dikerjakan sebelum Presentasi. Audit dikerjakan sebelum Inventaris. Pelatihan dikerjakan tepat sehari setelah Presentasi. Kegiatan yang dikerjakan pada hari Jumat adalah ...",
    "options": [
      "Inventaris",
      "Laporan",
      "Pelatihan",
      "Audit",
      "Presentasi"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Dari semua syarat hanya ada satu kegiatan yang mungkin pada hari tersebut."
  },
  {
    "id": 1711,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Lima kegiatan (Inventaris, Pelatihan, Presentasi, Rapat, Survei) dikerjakan pada hari Senin sampai Jumat, masing-masing satu kegiatan per hari. Di antara pengerjaan Inventaris dan Rapat terdapat tepat 1 hari kerja. Pelatihan tidak dikerjakan pada hari Senin. Pelatihan dikerjakan sebelum Survei. Di antara pengerjaan Presentasi dan Inventaris terdapat tepat 2 hari kerja. Kegiatan yang dikerjakan pada hari Jumat adalah ...",
    "options": [
      "Pelatihan",
      "Survei",
      "Presentasi",
      "Inventaris",
      "Rapat"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dari semua syarat hanya ada satu kegiatan yang mungkin pada hari tersebut."
  },
  {
    "id": 1712,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Lima kegiatan (Audit, Inventaris, Pelatihan, Presentasi, Rapat) dikerjakan pada hari Senin sampai Jumat, masing-masing satu kegiatan per hari. Rapat dikerjakan sebelum Presentasi. Rapat dikerjakan sebelum Inventaris. Rapat dikerjakan sebelum Pelatihan. Pelatihan dikerjakan sebelum Audit. Kegiatan yang dikerjakan pada hari Senin adalah ...",
    "options": [
      "Inventaris",
      "Rapat",
      "Audit",
      "Presentasi",
      "Pelatihan"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dari semua syarat hanya ada satu kegiatan yang mungkin pada hari tersebut."
  },
  {
    "id": 1713,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Bima, Citra, Dimas, Eka, Farhan, Gilang) duduk melingkar mengelilingi meja bundar menghadap pusat meja, dengan Eka sebagai patokan. Eka duduk berhadapan langsung dengan Dimas. Farhan dan Bima tidak duduk bersebelahan. Eka duduk tepat di kursi berikutnya searah jarum jam dari Gilang. Di antara Farhan dan Dimas terdapat tepat satu kursi (pada salah satu sisi). Siapa yang duduk tepat searah jarum jam setelah Citra?",
    "options": [
      "Bima",
      "Citra",
      "Gilang",
      "Eka",
      "Dimas"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Letakkan orang pada 6 posisi lingkaran dan gunakan semua syarat sampai hanya satu kemungkinan tersisa."
  },
  {
    "id": 1714,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Bima, Citra, Eka, Gilang, Hana) duduk melingkar mengelilingi meja bundar menghadap pusat meja, dengan Gilang sebagai patokan. Bima dan Citra tidak duduk bersebelahan. Hana duduk tepat di kursi berikutnya searah jarum jam dari Citra. Hana duduk berhadapan langsung dengan Ayu. Gilang dan Ayu tidak duduk bersebelahan. Siapa yang duduk tepat searah jarum jam setelah Gilang?",
    "options": [
      "Bima",
      "Hana",
      "Ayu",
      "Gilang",
      "Eka"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Letakkan orang pada 6 posisi lingkaran dan gunakan semua syarat sampai hanya satu kemungkinan tersisa."
  },
  {
    "id": 1715,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Citra, Dimas, Farhan, Gilang, Hana) duduk melingkar mengelilingi meja bundar menghadap pusat meja, dengan Citra sebagai patokan. Hana duduk tepat di kursi berikutnya searah jarum jam dari Citra. Citra dan Dimas tidak duduk bersebelahan. Farhan duduk berhadapan langsung dengan Dimas. Di antara Citra dan Gilang terdapat tepat satu kursi (pada salah satu sisi). Siapa yang duduk tepat searah jarum jam setelah Dimas?",
    "options": [
      "Dimas",
      "Farhan",
      "Citra",
      "Ayu",
      "Gilang"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Letakkan orang pada 6 posisi lingkaran dan gunakan semua syarat sampai hanya satu kemungkinan tersisa."
  },
  {
    "id": 1716,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Bima, Citra, Dimas, Gilang, Hana) duduk melingkar mengelilingi meja bundar menghadap pusat meja, dengan Dimas sebagai patokan. Hana duduk berhadapan langsung dengan Citra. Hana duduk tepat di kursi berikutnya searah jarum jam dari Dimas. Dimas duduk berhadapan langsung dengan Gilang. Dimas dan Bima tidak duduk bersebelahan. Siapa yang duduk tepat searah jarum jam setelah Ayu?",
    "options": [
      "Dimas",
      "Gilang",
      "Bima",
      "Hana",
      "Ayu"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Letakkan orang pada 6 posisi lingkaran dan gunakan semua syarat sampai hanya satu kemungkinan tersisa."
  },
  {
    "id": 1717,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Bima, Citra, Dimas, Eka, Gilang, Hana) duduk melingkar mengelilingi meja bundar menghadap pusat meja, dengan Citra sebagai patokan. Hana duduk tepat di kursi berikutnya searah jarum jam dari Eka. Di antara Bima dan Hana terdapat tepat satu kursi (pada salah satu sisi). Dimas dan Hana tidak duduk bersebelahan. Bima duduk tepat di kursi berikutnya searah jarum jam dari Dimas. Siapa yang duduk tepat searah jarum jam setelah Bima?",
    "options": [
      "Dimas",
      "Gilang",
      "Citra",
      "Eka",
      "Bima"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Letakkan orang pada 6 posisi lingkaran dan gunakan semua syarat sampai hanya satu kemungkinan tersisa."
  },
  {
    "id": 1718,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Bima, Citra, Dimas, Farhan, Gilang) duduk melingkar mengelilingi meja bundar menghadap pusat meja, dengan Dimas sebagai patokan. Dimas duduk berhadapan langsung dengan Ayu. Di antara Farhan dan Ayu terdapat tepat satu kursi (pada salah satu sisi). Bima duduk berhadapan langsung dengan Citra. Bima duduk tepat di kursi berikutnya searah jarum jam dari Dimas. Siapa yang duduk tepat searah jarum jam setelah Gilang?",
    "options": [
      "Ayu",
      "Dimas",
      "Gilang",
      "Citra",
      "Farhan"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Letakkan orang pada 6 posisi lingkaran dan gunakan semua syarat sampai hanya satu kemungkinan tersisa."
  },
  {
    "id": 1719,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Bima, Dimas, Eka, Farhan, Gilang) dibagi menjadi dua tim beranggotakan 3 orang. Eka dan Bima tidak berada dalam satu tim. Gilang dan Eka berada dalam satu tim. Ayu dan Farhan berada dalam satu tim. Siapa saja yang satu tim dengan Gilang?",
    "options": [
      "Dimas dan Farhan",
      "Ayu dan Dimas",
      "Ayu dan Farhan",
      "Dimas dan Eka",
      "Ayu dan Bima"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Uji semua pembagian tim yang mungkin; hanya satu yang memenuhi seluruh syarat."
  },
  {
    "id": 1720,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Dimas, Eka, Farhan, Gilang, Hana) dibagi menjadi dua tim beranggotakan 3 orang. Hana dan Farhan berada dalam satu tim. Hana dan Gilang tidak berada dalam satu tim. Eka dan Dimas berada dalam satu tim. Siapa saja yang satu tim dengan Gilang?",
    "options": [
      "Farhan dan Hana",
      "Ayu dan Hana",
      "Dimas dan Eka",
      "Ayu dan Dimas",
      "Dimas dan Farhan"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Uji semua pembagian tim yang mungkin; hanya satu yang memenuhi seluruh syarat."
  },
  {
    "id": 1721,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Bima, Citra, Dimas, Farhan, Hana) dibagi menjadi dua tim beranggotakan 3 orang. Dimas dan Hana tidak berada dalam satu tim. Dimas dan Farhan tidak berada dalam satu tim. Ayu dan Bima tidak berada dalam satu tim. Ayu dan Dimas berada dalam satu tim. Siapa saja yang satu tim dengan Citra?",
    "options": [
      "Farhan dan Hana",
      "Ayu dan Hana",
      "Bima dan Dimas",
      "Ayu dan Farhan",
      "Ayu dan Dimas"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Uji semua pembagian tim yang mungkin; hanya satu yang memenuhi seluruh syarat."
  },
  {
    "id": 1722,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Ayu, Citra, Dimas, Farhan, Gilang, Hana) dibagi menjadi dua tim beranggotakan 3 orang. Citra dan Gilang berada dalam satu tim. Citra dan Ayu tidak berada dalam satu tim. Gilang dan Farhan tidak berada dalam satu tim. Hana dan Gilang tidak berada dalam satu tim. Siapa saja yang satu tim dengan Hana?",
    "options": [
      "Ayu dan Gilang",
      "Citra dan Farhan",
      "Ayu dan Farhan",
      "Dimas dan Farhan",
      "Farhan dan Gilang"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Uji semua pembagian tim yang mungkin; hanya satu yang memenuhi seluruh syarat."
  },
  {
    "id": 1723,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Bima, Citra, Dimas, Eka, Gilang, Hana) dibagi menjadi dua tim beranggotakan 3 orang. Dimas dan Hana berada dalam satu tim. Gilang dan Dimas tidak berada dalam satu tim. Bima dan Citra berada dalam satu tim. Siapa saja yang satu tim dengan Bima?",
    "options": [
      "Dimas dan Hana",
      "Dimas dan Eka",
      "Eka dan Hana",
      "Citra dan Eka",
      "Citra dan Gilang"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Uji semua pembagian tim yang mungkin; hanya satu yang memenuhi seluruh syarat."
  },
  {
    "id": 1724,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Enam orang (Bima, Citra, Dimas, Farhan, Gilang, Hana) dibagi menjadi dua tim beranggotakan 3 orang. Hana dan Bima berada dalam satu tim. Gilang dan Dimas tidak berada dalam satu tim. Bima dan Gilang tidak berada dalam satu tim. Siapa saja yang satu tim dengan Dimas?",
    "options": [
      "Bima dan Farhan",
      "Farhan dan Hana",
      "Bima dan Hana",
      "Bima dan Gilang",
      "Farhan dan Gilang"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Uji semua pembagian tim yang mungkin; hanya satu yang memenuhi seluruh syarat."
  },
  {
    "id": 1725,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Perhatikan hubungan keluarga berikut (semua keturunan berasal dari satu garis keluarga). Lina adalah anak perempuan dari Rudi. Rudi adalah saudara laki-laki dari Dewi. Dewi adalah ibu dari Yuni. Lina adalah ... dari Yuni.",
    "options": [
      "cucu perempuan",
      "sepupu",
      "ibu",
      "keponakan perempuan",
      "nenek"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Telusuri rantai hubungan: Lina adalah sepupu dari Yuni."
  },
  {
    "id": 1726,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Perhatikan hubungan keluarga berikut (semua keturunan berasal dari satu garis keluarga). Ivan adalah anak laki-laki dari Yuni. Yuni adalah saudara perempuan dari Maya. Maya adalah ibu dari Rudi. Ivan adalah ... dari Rudi.",
    "options": [
      "saudara laki-laki",
      "sepupu",
      "ayah",
      "paman",
      "kakek"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Telusuri rantai hubungan: Ivan adalah sepupu dari Rudi."
  },
  {
    "id": 1727,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Perhatikan hubungan keluarga berikut (semua keturunan berasal dari satu garis keluarga). Rudi adalah anak laki-laki dari Dewi. Dewi adalah saudara perempuan dari Nina. Nina adalah ibu dari Hasan. Rudi adalah ... dari Hasan.",
    "options": [
      "keponakan laki-laki",
      "sepupu",
      "paman",
      "saudara laki-laki",
      "cucu laki-laki"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Telusuri rantai hubungan: Rudi adalah sepupu dari Hasan."
  },
  {
    "id": 1728,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Perhatikan hubungan keluarga berikut (semua keturunan berasal dari satu garis keluarga). Nina adalah anak perempuan dari Doni. Doni adalah saudara laki-laki dari Maya. Maya adalah ibu dari Hasan. Nina adalah ... dari Hasan.",
    "options": [
      "cucu perempuan",
      "bibi",
      "sepupu",
      "saudara perempuan",
      "keponakan perempuan"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Telusuri rantai hubungan: Nina adalah sepupu dari Hasan."
  },
  {
    "id": 1729,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Perhatikan hubungan keluarga berikut (semua keturunan berasal dari satu garis keluarga). Yuni adalah anak perempuan dari Faisal. Faisal adalah saudara laki-laki dari Budi. Budi adalah ayah dari Tono. Yuni adalah ... dari Tono.",
    "options": [
      "cucu perempuan",
      "saudara perempuan",
      "sepupu",
      "nenek",
      "bibi"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Telusuri rantai hubungan: Yuni adalah sepupu dari Tono."
  },
  {
    "id": 1730,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Perhatikan hubungan keluarga berikut (semua keturunan berasal dari satu garis keluarga). Wati adalah anak perempuan dari Dewi. Dewi adalah saudara perempuan dari Siti. Siti adalah ibu dari Faisal. Wati adalah ... dari Faisal.",
    "options": [
      "keponakan perempuan",
      "bibi",
      "cucu perempuan",
      "ibu",
      "sepupu"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Telusuri rantai hubungan: Wati adalah sepupu dari Faisal."
  },
  {
    "id": 1731,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Data penjualan (unit) per kuartal: Palembang: K1=150, K2=90, K3=170; Makassar: K1=100, K2=60, K3=170; Medan: K1=170, K2=170, K3=110; Denpasar: K1=190, K2=50, K3=60. Wilayah dengan total penjualan tiga kuartal tertinggi adalah ...",
    "options": [
      "Palembang",
      "Tidak ada yang tertinggi",
      "Medan",
      "Denpasar",
      "Makassar"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Jumlahkan K1+K2+K3 setiap wilayah: Palembang=410, Makassar=330, Medan=450, Denpasar=300."
  },
  {
    "id": 1732,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Data penjualan (unit) per kuartal: Bandung: K1=50, K2=140, K3=120; Surabaya: K1=150, K2=60, K3=90; Makassar: K1=100, K2=80, K3=150; Denpasar: K1=90, K2=120, K3=180. Rata-rata penjualan per kuartal wilayah Denpasar adalah ...",
    "options": [
      "130",
      "120",
      "125",
      "135",
      "110"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. (90+120+180) : 3 = 130."
  },
  {
    "id": 1733,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Data penjualan (unit) per kuartal: Palembang: K1=160, K2=60, K3=130; Denpasar: K1=80, K2=80, K3=70; Medan: K1=90, K2=40, K3=100; Bandung: K1=70, K2=80, K3=170. Wilayah dengan kenaikan penjualan terbesar dari K1 ke K3 mengalami kenaikan sebesar ... unit.",
    "options": [
      "120",
      "100",
      "130",
      "90",
      "110"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Selisih K3-K1: Palembang=-30, Denpasar=-10, Medan=10, Bandung=100. Terbesar Bandung."
  },
  {
    "id": 1734,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Data penjualan (unit) per kuartal: Denpasar: K1=80, K2=50, K3=120; Bandung: K1=60, K2=170, K3=60; Palembang: K1=70, K2=170, K3=190; Makassar: K1=140, K2=60, K3=40. Wilayah dengan total penjualan tiga kuartal tertinggi adalah ...",
    "options": [
      "Tidak ada yang tertinggi",
      "Makassar",
      "Bandung",
      "Palembang",
      "Denpasar"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Jumlahkan K1+K2+K3 setiap wilayah: Denpasar=250, Bandung=290, Palembang=430, Makassar=240."
  },
  {
    "id": 1735,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Data penjualan (unit) per kuartal: Surabaya: K1=170, K2=160, K3=50; Medan: K1=140, K2=130, K3=120; Palembang: K1=190, K2=160, K3=40; Denpasar: K1=40, K2=160, K3=160. Rata-rata penjualan per kuartal wilayah Denpasar adalah ...",
    "options": [
      "130",
      "135",
      "140",
      "110",
      "120"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. (40+160+160) : 3 = 120."
  },
  {
    "id": 1736,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Data penjualan (unit) per kuartal: Palembang: K1=100, K2=50, K3=180; Medan: K1=90, K2=100, K3=190; Makassar: K1=90, K2=40, K3=130; Bandung: K1=80, K2=40, K3=70. Wilayah dengan kenaikan penjualan terbesar dari K1 ke K3 mengalami kenaikan sebesar ... unit.",
    "options": [
      "100",
      "60",
      "90",
      "80",
      "140"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Selisih K3-K1: Palembang=80, Medan=100, Makassar=40, Bandung=-10. Terbesar Medan."
  },
  {
    "id": 1737,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Tiga dari enam kandidat (A, B, C, D, E, F) akan dipilih untuk sebuah tim. Syarat: C dan E tidak boleh terpilih bersamaan; Paling sedikit salah satu dari B dan F harus terpilih; A dan B tidak boleh terpilih bersamaan; Jika C terpilih maka D harus terpilih. Susunan tim yang memenuhi semua syarat adalah ...",
    "options": [
      "C, D, E",
      "B, D, F",
      "A, B, C",
      "A, D, E",
      "B, C, F"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Periksa tiap susunan terhadap semua syarat; hanya satu pilihan yang tidak melanggar satu pun."
  },
  {
    "id": 1738,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Tiga dari enam kandidat (A, B, C, D, E, F) akan dipilih untuk sebuah tim. Syarat: Jika E terpilih maka A harus terpilih; A dan B tidak boleh terpilih bersamaan; D dan F tidak boleh terpilih bersamaan; Jika C terpilih maka D harus terpilih. Susunan tim yang memenuhi semua syarat adalah ...",
    "options": [
      "B, C, F",
      "A, C, D",
      "B, C, E",
      "A, C, E",
      "B, E, F"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Periksa tiap susunan terhadap semua syarat; hanya satu pilihan yang tidak melanggar satu pun."
  },
  {
    "id": 1739,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Tiga dari enam kandidat (A, B, C, D, E, F) akan dipilih untuk sebuah tim. Syarat: Jika F terpilih maka C tidak boleh terpilih; Paling sedikit salah satu dari B dan F harus terpilih; A dan B tidak boleh terpilih bersamaan; C dan E tidak boleh terpilih bersamaan. Susunan tim yang memenuhi semua syarat adalah ...",
    "options": [
      "C, D, F",
      "C, E, F",
      "B, C, E",
      "B, C, D",
      "A, B, F"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Periksa tiap susunan terhadap semua syarat; hanya satu pilihan yang tidak melanggar satu pun."
  },
  {
    "id": 1740,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Tiga dari enam kandidat (A, B, C, D, E, F) akan dipilih untuk sebuah tim. Syarat: D dan F tidak boleh terpilih bersamaan; C dan E tidak boleh terpilih bersamaan; Jika C terpilih maka D harus terpilih; Jika E terpilih maka A harus terpilih. Susunan tim yang memenuhi semua syarat adalah ...",
    "options": [
      "B, C, E",
      "A, B, E",
      "B, D, F",
      "B, C, F",
      "A, C, E"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Periksa tiap susunan terhadap semua syarat; hanya satu pilihan yang tidak melanggar satu pun."
  },
  {
    "id": 1741,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Tiga dari enam kandidat (A, B, C, D, E, F) akan dipilih untuk sebuah tim. Syarat: A dan B tidak boleh terpilih bersamaan; C dan E tidak boleh terpilih bersamaan; D dan F tidak boleh terpilih bersamaan; Jika C terpilih maka D harus terpilih. Susunan tim yang memenuhi semua syarat adalah ...",
    "options": [
      "A, B, F",
      "B, C, E",
      "A, B, C",
      "B, E, F",
      "C, D, F"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Periksa tiap susunan terhadap semua syarat; hanya satu pilihan yang tidak melanggar satu pun."
  },
  {
    "id": 1742,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Tiga dari enam kandidat (A, B, C, D, E, F) akan dipilih untuk sebuah tim. Syarat: D dan F tidak boleh terpilih bersamaan; Paling sedikit salah satu dari B dan F harus terpilih; Jika C terpilih maka D harus terpilih; C dan E tidak boleh terpilih bersamaan. Susunan tim yang memenuhi semua syarat adalah ...",
    "options": [
      "A, C, D",
      "B, C, E",
      "A, B, C",
      "B, D, F",
      "B, C, D"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Periksa tiap susunan terhadap semua syarat; hanya satu pilihan yang tidak melanggar satu pun."
  },
  {
    "id": 1743,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Umur Pak Joko sekarang 4 kali umur Kakak. 3 tahun yang lalu, umur Pak Joko adalah 5 kali umur Kakak. Umur Pak Joko sekarang adalah ... tahun.",
    "options": [
      "40",
      "52",
      "56",
      "48",
      "50"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Misal umur Kakak=12: 4b-3=5(b-3) memberi b=12, sehingga Pak Joko=48."
  },
  {
    "id": 1744,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Jumlah umur tiga bersaudara adalah 34 tahun. Yang tengah 3 tahun lebih tua daripada yang termuda, dan yang tertua 4 tahun lebih tua daripada yang tengah. Umur yang termuda adalah ... tahun.",
    "options": [
      "8",
      "6",
      "10",
      "12",
      "5"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. 3b+10=34 sehingga b=8; umur: 8, 11, 15."
  },
  {
    "id": 1745,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Umur Pak Joko sekarang 3 kali umur Kakak. 17 tahun yang lalu, umur Pak Joko adalah 20 kali umur Kakak. Umur Pak Joko sekarang adalah ... tahun.",
    "options": [
      "51",
      "57",
      "63",
      "59",
      "55"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Misal umur Kakak=19: 3b-17=20(b-17) memberi b=19, sehingga Pak Joko=57."
  },
  {
    "id": 1746,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Jumlah umur tiga bersaudara adalah 34 tahun. Yang tengah 6 tahun lebih tua daripada yang termuda, dan yang tertua 4 tahun lebih tua daripada yang tengah. Umur yang termuda adalah ... tahun.",
    "options": [
      "9",
      "4",
      "8",
      "2",
      "6"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. 3b+16=34 sehingga b=6; umur: 6, 12, 16."
  },
  {
    "id": 1747,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Umur Ayah sekarang 4 kali umur Pak Joko. 5 tahun yang lalu, umur Ayah adalah 5 kali umur Pak Joko. Umur Ayah sekarang adalah ... tahun.",
    "options": [
      "86",
      "88",
      "80",
      "72",
      "84"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Misal umur Pak Joko=20: 4b-5=5(b-5) memberi b=20, sehingga Ayah=80."
  },
  {
    "id": 1748,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Jumlah umur tiga bersaudara adalah 40 tahun. Yang tengah 5 tahun lebih tua daripada yang termuda, dan yang tertua 6 tahun lebih tua daripada yang tengah. Umur yang tengah adalah ... tahun.",
    "options": [
      "17",
      "13",
      "16",
      "12",
      "10"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 3b+16=40 sehingga b=8; umur: 8, 13, 19."
  },
  {
    "id": 1749,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Umur Paman sekarang 2 kali umur Kakak. 16 tahun yang lalu, umur Paman adalah 18 kali umur Kakak. Umur Paman sekarang adalah ... tahun.",
    "options": [
      "28",
      "36",
      "30",
      "34",
      "26"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Misal umur Kakak=17: 2b-16=18(b-16) memberi b=17, sehingga Paman=34."
  },
  {
    "id": 1750,
    "moduleId": "analitis",
    "category": "Penalaran Analitis",
    "question": "Jumlah umur tiga bersaudara adalah 57 tahun. Yang tengah 2 tahun lebih tua daripada yang termuda, dan yang tertua 2 tahun lebih tua daripada yang tengah. Umur yang tertua adalah ... tahun.",
    "options": [
      "22",
      "24",
      "21",
      "19",
      "25"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 3b+6=57 sehingga b=17; umur: 17, 19, 21."
  }
];
