export const NUMERIK = [
  {
    "id": 1101,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 6² − 2³ ÷ 2 + √121 adalah ...",
    "options": [
      "46",
      "55",
      "49",
      "31",
      "43"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. 36 − 4 + 11 = 43."
  },
  {
    "id": 1102,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (19² − 6²) ÷ (19 − 6) × 8 adalah ...",
    "options": [
      "188",
      "208",
      "212",
      "200",
      "196"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. (25) × 8 = 200."
  },
  {
    "id": 1103,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 120 × 0,25 + 20 ÷ 0,5 − 5 × 2,5 adalah ...",
    "options": [
      "59,5",
      "59",
      "57,5",
      "56",
      "58,5"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 30 + 40 − 12,5 = 57,5."
  },
  {
    "id": 1104,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari ∛64 × √9 − 11² adalah ...",
    "options": [
      "-121",
      "-106",
      "-109",
      "-103",
      "-100"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 4 × 3 − 121 = -109."
  },
  {
    "id": 1105,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 3 − [6 − (8 − 3 × 8)] × 3 adalah ...",
    "options": [
      "-69",
      "-72",
      "-57",
      "-63",
      "-60"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 8 − 24 = -16; 6 − (-16) = 22; hasil akhir -63."
  },
  {
    "id": 1106,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 6² − 2³ ÷ 2 + √144 adalah ...",
    "options": [
      "41",
      "35",
      "50",
      "44",
      "32"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 36 − 4 + 12 = 44."
  },
  {
    "id": 1107,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (18² − 3²) ÷ (18 − 3) × 4 adalah ...",
    "options": [
      "80",
      "88",
      "84",
      "72",
      "68"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. (21) × 4 = 84."
  },
  {
    "id": 1108,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 24 × 0,25 + 16 ÷ 0,5 − 4 × 2,5 adalah ...",
    "options": [
      "30",
      "26",
      "27",
      "28",
      "27,5"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 6 + 32 − 10 = 28."
  },
  {
    "id": 1109,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari ∛125 × √9 − 11² adalah ...",
    "options": [
      "-106",
      "-97",
      "-118",
      "-103",
      "-115"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. 5 × 3 − 121 = -106."
  },
  {
    "id": 1110,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 7 − [9 − (2 − 9 × 2)] × 4 adalah ...",
    "options": [
      "-87",
      "-93",
      "-99",
      "-84",
      "-96"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 2 − 18 = -16; 9 − (-16) = 25; hasil akhir -93."
  },
  {
    "id": 1111,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (6/5 + 7/3) ÷ (1/2 − 3/7) dalam bentuk paling sederhana adalah ...",
    "options": [
      "739/15",
      "743/15",
      "746/15",
      "246/5",
      "742/15"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1112,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 2/3 ÷ 1/2 + 5/3 × 1/2 dalam bentuk paling sederhana adalah ...",
    "options": [
      "13/6",
      "8/3",
      "5/3",
      "5/2",
      "2"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1113,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (3/8 + 2/3) ÷ (7/9 − 1/6) dalam bentuk paling sederhana adalah ...",
    "options": [
      "79/44",
      "75/44",
      "7/4",
      "19/11",
      "37/22"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1114,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 7/5 ÷ 1/3 + 1/5 × 4/9 dalam bentuk paling sederhana adalah ...",
    "options": [
      "197/45",
      "194/45",
      "64/15",
      "13/3",
      "193/45"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1115,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (1/3 + 3/2) ÷ (4/3 − 5/4) dalam bentuk paling sederhana adalah ...",
    "options": [
      "22",
      "20",
      "23",
      "18",
      "19"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1116,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 7/3 ÷ 5/6 + 5/3 × 1/4 dalam bentuk paling sederhana adalah ...",
    "options": [
      "16/5",
      "197/60",
      "13/4",
      "191/60",
      "193/60"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1117,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (5/8 + 1/2) ÷ (2/3 − 4/9) dalam bentuk paling sederhana adalah ...",
    "options": [
      "5",
      "77/16",
      "41/8",
      "83/16",
      "81/16"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1118,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 7/8 ÷ 3/2 + 1/8 × 2/3 dalam bentuk paling sederhana adalah ...",
    "options": [
      "8/3",
      "2/3",
      "4/3",
      "1",
      "5/3"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Samakan penyebut, lakukan operasi sesuai urutan, lalu sederhanakan."
  },
  {
    "id": 1119,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Berapakah 40% dari 50% dari 1200?",
    "options": [
      "264",
      "192",
      "336",
      "240",
      "144"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 1200 × 40/100 × 50/100 = 240."
  },
  {
    "id": 1120,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Berapakah 25% dari 40% dari 1600?",
    "options": [
      "192",
      "112",
      "144",
      "160",
      "128"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 1600 × 25/100 × 40/100 = 160."
  },
  {
    "id": 1121,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Harga barang naik 10%, kemudian turun 40%. Dibandingkan harga semula, harga akhir berubah sebesar ... (negatif berarti turun).",
    "options": [
      "-26%",
      "-32%",
      "-33%",
      "-36%",
      "-34%"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. (1+10/100)(1−40/100) = 0,66."
  },
  {
    "id": 1122,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Harga barang naik 40%, kemudian turun 25%. Dibandingkan harga semula, harga akhir berubah sebesar ... (negatif berarti turun).",
    "options": [
      "10%",
      "5%",
      "13%",
      "6%",
      "3%"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. (1+40/100)(1−25/100) = 1,05."
  },
  {
    "id": 1123,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Jika 75% dari suatu bilangan adalah 900, maka 10% dari bilangan tersebut adalah ...",
    "options": [
      "150",
      "120",
      "80",
      "90",
      "140"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Bilangan = 900 : 75% = 1200; 10% × 1200 = 120."
  },
  {
    "id": 1124,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Diketahui A : B = 3 : 5 dan B : C = 2 : 3. Perbandingan A : B : C adalah ...",
    "options": [
      "6:10:15",
      "6:10:16",
      "3:2:3",
      "7:10:15",
      "3:5:3"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Samakan nilai B pada kedua perbandingan."
  },
  {
    "id": 1125,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Harga sebuah barang Rp400.000. Barang itu mendapat diskon 20%, lalu dikenai pajak 10% dari harga setelah diskon. Harga yang harus dibayar adalah ...",
    "options": [
      "Rp352.000",
      "Rp367.000",
      "Rp337.000",
      "Rp332.000",
      "Rp342.000"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Rp400.000 × 80% × 110% = Rp352.000."
  },
  {
    "id": 1126,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Setelah naik 25%, nilai suatu besaran menjadi 750. Nilai semula adalah ...",
    "options": [
      "510",
      "690",
      "600",
      "570",
      "660"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. 750 : 5/4 = 600."
  },
  {
    "id": 1127,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Tiga lampu menyala setiap 12, 15, dan 20 detik. Jika ketiganya menyala bersamaan pada detik ke-0, ketiganya akan menyala bersamaan lagi pada detik ke ...",
    "options": [
      "75",
      "65",
      "70",
      "60",
      "55"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. KPK(12,15,20) = 60."
  },
  {
    "id": 1128,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Sebuah toko memiliki 60 pensil, 90 buku, dan 150 penghapus yang akan dibagi ke dalam paket yang isinya sama persis tanpa sisa. Banyak paket terbanyak yang dapat dibuat adalah ...",
    "options": [
      "35",
      "50",
      "30",
      "40",
      "45"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. FPB(60,90,150) = 30."
  },
  {
    "id": 1129,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Dua bus berangkat bersamaan dari terminal pada pukul 06.00. Bus pertama kembali ke terminal setiap 15 menit dan bus kedua setiap 24 menit. Setelah keberangkatan pertama, berapa kali keduanya tepat bersamaan lagi di terminal selama 1080 menit pertama?",
    "options": [
      "12",
      "13",
      "9",
      "10",
      "11"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Mereka bersamaan setiap KPK = 120 menit, sehingga 9 kali dalam 1080 menit."
  },
  {
    "id": 1130,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Tiga lampu menyala setiap 20, 18, dan 15 detik. Jika ketiganya menyala bersamaan pada detik ke-0, ketiganya akan menyala bersamaan lagi pada detik ke ...",
    "options": [
      "135",
      "165",
      "150",
      "195",
      "180"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. KPK(20,18,15) = 180."
  },
  {
    "id": 1131,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Sebuah toko memiliki 72 pensil, 108 buku, dan 144 penghapus yang akan dibagi ke dalam paket yang isinya sama persis tanpa sisa. Banyak paket terbanyak yang dapat dibuat adalah ...",
    "options": [
      "36",
      "18",
      "48",
      "54",
      "24"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. FPB(72,108,144) = 36."
  },
  {
    "id": 1132,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Dua bus berangkat bersamaan dari terminal pada pukul 06.00. Bus pertama kembali ke terminal setiap 28 menit dan bus kedua setiap 15 menit. Setelah keberangkatan pertama, berapa kali keduanya tepat bersamaan lagi di terminal selama 3360 menit pertama?",
    "options": [
      "7",
      "12",
      "11",
      "8",
      "10"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Mereka bersamaan setiap KPK = 420 menit, sehingga 8 kali dalam 3360 menit."
  },
  {
    "id": 1133,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (4 × 10^5) × (25 × 10^-2) adalah ...",
    "options": [
      "100000",
      "1000",
      "10000",
      "10000000",
      "1000000"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. 4×25 = 100; 10^5×10^-2 = 10^3."
  },
  {
    "id": 1134,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 0,096 ÷ 0,16 adalah ...",
    "options": [
      "0,7",
      "0,06",
      "60",
      "0,6",
      "6"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. 0,096 ÷ 0,16 = 0,6."
  },
  {
    "id": 1135,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 3,2 × 0,125 adalah ...",
    "options": [
      "1,4",
      "0,4",
      "-0,1",
      "4",
      "0,04"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 3,2 × 0,125 = 0,4."
  },
  {
    "id": 1136,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari (3 × 10^6) × (5 × 10^-3) adalah ...",
    "options": [
      "15000",
      "1500000",
      "150000",
      "1500",
      "150"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. 3×5 = 15; 10^6×10^-3 = 10^3."
  },
  {
    "id": 1137,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 0,036 ÷ 0,09 adalah ...",
    "options": [
      "4",
      "0,4",
      "0,04",
      "0,5",
      "40"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 0,036 ÷ 0,09 = 0,4."
  },
  {
    "id": 1138,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Hasil dari 12,5 × 0,8 adalah ...",
    "options": [
      "11",
      "10",
      "100",
      "9,5",
      "1"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 12,5 × 0,8 = 10."
  },
  {
    "id": 1139,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Angka satuan dari 2^2024 adalah ...",
    "options": [
      "6",
      "2",
      "1",
      "3",
      "0"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pola satuan berulang; 2^2024 mod 10 = 6."
  },
  {
    "id": 1140,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Sisa pembagian 7^100 oleh 11 adalah ...",
    "options": [
      "4",
      "1",
      "0",
      "3",
      "2"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. 7^100 mod 11 = 1."
  },
  {
    "id": 1141,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Banyak bilangan asli kelipatan 13 yang tidak lebih dari 1000 adalah ...",
    "options": [
      "74",
      "80",
      "76",
      "84",
      "70"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. ⌊1000/13⌋ = 76."
  },
  {
    "id": 1142,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Angka satuan dari 2^4567 adalah ...",
    "options": [
      "0",
      "3",
      "8",
      "2",
      "1"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola satuan berulang; 2^4567 mod 10 = 8."
  },
  {
    "id": 1143,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Sisa pembagian 2^200 oleh 9 adalah ...",
    "options": [
      "0",
      "1",
      "3",
      "2",
      "4"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. 2^200 mod 9 = 4."
  },
  {
    "id": 1144,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Banyak bilangan asli kelipatan 11 yang tidak lebih dari 888 adalah ...",
    "options": [
      "74",
      "80",
      "78",
      "76",
      "72"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. ⌊888/11⌋ = 80."
  },
  {
    "id": 1145,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Jumlah semua bilangan kelipatan 13 yang lebih dari 150 dan tidak lebih dari 400 adalah ...",
    "options": [
      "5187",
      "5109",
      "5161",
      "5265",
      "5291"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Deret aritmetika 156..390 (19 suku): n(a+U)/2 = 5187."
  },
  {
    "id": 1146,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Suku ke-23 dari deret 9, 15, 21, 27, ... adalah ...",
    "options": [
      "123",
      "135",
      "159",
      "165",
      "141"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Un = a + (n−1)b = 141."
  },
  {
    "id": 1147,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Jumlah 20 suku pertama deret 4, 6, 8, ... adalah ...",
    "options": [
      "412",
      "428",
      "524",
      "476",
      "460"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Sn = n/2 (2a + (n−1)b) = 460."
  },
  {
    "id": 1148,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Jumlah semua bilangan kelipatan 11 yang lebih dari 300 dan tidak lebih dari 500 adalah ...",
    "options": [
      "7271",
      "7205",
      "7227",
      "7249",
      "7293"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Deret aritmetika 308..495 (18 suku): n(a+U)/2 = 7227."
  },
  {
    "id": 1149,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Suku ke-20 dari deret 5, 10, 15, 20, ... adalah ...",
    "options": [
      "90",
      "100",
      "110",
      "95",
      "120"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Un = a + (n−1)b = 100."
  },
  {
    "id": 1150,
    "moduleId": "numerik",
    "category": "Numerik Dasar",
    "question": "Jumlah 20 suku pertama deret 5, 8, 11, ... adalah ...",
    "options": [
      "742",
      "670",
      "574",
      "766",
      "622"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Sn = n/2 (2a + (n−1)b) = 670."
  }
];
