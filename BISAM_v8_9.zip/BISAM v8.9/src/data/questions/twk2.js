export const TWK2 = [
  {
    "id": 2601,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Pada sidang pertama BPUPKI, tokoh yang pada 29 Mei 1945 mengemukakan lima asas dasar negara berupa peri kebangsaan, peri kemanusiaan, peri ketuhanan, peri kerakyatan, dan kesejahteraan rakyat adalah ...",
    "options": [
      "Soepomo",
      "Soekarno",
      "Mohammad Yamin",
      "Ki Bagoes Hadikoesoemo",
      "Mohammad Hatta"
    ],
    "answer": "C",
    "explanation": "Yamin berpidato 29 Mei 1945, Soepomo 31 Mei 1945, dan Soekarno 1 Juni 1945."
  },
  {
    "id": 2602,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Dalam pidato 31 Mei 1945, Soepomo mengusulkan dasar negara yang bercorak ...",
    "options": [
      "liberal-individualistik yang mengutamakan hak perorangan",
      "sosialis-marxis yang berbasis perjuangan kelas",
      "federalistik yang menekankan kedaulatan negara bagian",
      "integralistik, yaitu persatuan antara negara dan seluruh rakyat tanpa dualisme",
      "teokratis yang berdasar satu agama"
    ],
    "answer": "D",
    "explanation": "Soepomo mengemukakan teori negara integralistik: persatuan, kekeluargaan, dan keseimbangan lahir batin."
  },
  {
    "id": 2603,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Dalam pidato 1 Juni 1945, Soekarno menyatakan bahwa Pancasila dapat diperas menjadi Trisila dan akhirnya Ekasila, yaitu ...",
    "options": [
      "kekeluargaan",
      "gotong royong",
      "persatuan",
      "keadilan sosial",
      "musyawarah mufakat"
    ],
    "answer": "B",
    "explanation": "Trisila: sosio-nasionalisme, sosio-demokrasi, ketuhanan; Ekasila: gotong royong."
  },
  {
    "id": 2604,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Piagam Jakarta yang memuat rumusan 'Ketuhanan dengan kewajiban menjalankan syariat Islam bagi pemeluk-pemeluknya' disusun oleh Panitia Sembilan pada tanggal ...",
    "options": [
      "29 Mei 1945",
      "1 Juni 1945",
      "18 Agustus 1945",
      "17 Agustus 1945",
      "22 Juni 1945"
    ],
    "answer": "E",
    "explanation": "Panitia Sembilan menyusun Piagam Jakarta pada 22 Juni 1945."
  },
  {
    "id": 2605,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Penghapusan frasa 'dengan kewajiban menjalankan syariat Islam bagi pemeluk-pemeluknya' dan penggantiannya dengan 'Ketuhanan Yang Maha Esa' disepakati pada ...",
    "options": [
      "sidang KNIP November 1945",
      "sidang PPKI 18 Agustus 1945",
      "sidang kedua BPUPKI 10-17 Juli 1945",
      "sidang pertama BPUPKI 29 Mei-1 Juni 1945",
      "rapat Panitia Sembilan 22 Juni 1945"
    ],
    "answer": "B",
    "explanation": "Perubahan dilakukan pada sidang PPKI 18 Agustus 1945 demi persatuan bangsa."
  },
  {
    "id": 2606,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Pasal 1 ayat (2) UUD NRI 1945 setelah perubahan berbunyi ...",
    "options": [
      "Kedaulatan berada di tangan negara dan dilaksanakan menurut hukum",
      "Kedaulatan berada di tangan Presiden dan dilaksanakan bersama Dewan Perwakilan Rakyat",
      "Kedaulatan berada di tangan rakyat dan dilaksanakan menurut Undang-Undang Dasar",
      "Kedaulatan adalah di tangan rakyat dan dilakukan sepenuhnya oleh Majelis Permusyawaratan Rakyat",
      "Kedaulatan rakyat dilaksanakan oleh lembaga perwakilan menurut ketetapan MPR"
    ],
    "answer": "C",
    "explanation": "Rumusan lama menyebut MPR sebagai pelaksana sepenuhnya kedaulatan rakyat; setelah perubahan ketiga, kedaulatan dilaksanakan menurut UUD."
  },
  {
    "id": 2607,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Pembatasan masa jabatan Presiden dan Wakil Presiden yang dihasilkan perubahan pertama UUD 1945 (1999) tercantum dalam Pasal ...",
    "options": [
      "9",
      "7A",
      "6A",
      "8",
      "7"
    ],
    "answer": "E",
    "explanation": "Pasal 7: jabatan lima tahun dan dapat dipilih kembali hanya untuk satu kali masa jabatan."
  },
  {
    "id": 2608,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Pemilihan Presiden dan Wakil Presiden secara langsung oleh rakyat (Pasal 6A) lahir dari perubahan UUD 1945 yang ...",
    "options": [
      "ketiga (2001)",
      "keempat (2002)",
      "kedua (2000)",
      "pertama (1999)",
      "Dekrit Presiden 5 Juli 1959"
    ],
    "answer": "A",
    "explanation": "Pasal 6A ditambahkan pada perubahan ketiga tahun 2001."
  },
  {
    "id": 2609,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Menurut Pasal 6A ayat (3), pasangan calon Presiden dan Wakil Presiden terpilih bila memperoleh suara lebih dari lima puluh persen dengan sedikitnya dua puluh persen suara di setiap provinsi yang tersebar di lebih dari ...",
    "options": [
      "setengah jumlah provinsi di Indonesia",
      "sepertiga jumlah provinsi di Indonesia",
      "dua pertiga jumlah provinsi di Indonesia",
      "seluruh provinsi di Indonesia",
      "tiga perempat jumlah provinsi di Indonesia"
    ],
    "answer": "A",
    "explanation": "Syarat persebaran suara: lebih dari setengah jumlah provinsi."
  },
  {
    "id": 2610,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Wewenang yang BUKAN merupakan wewenang Mahkamah Konstitusi adalah ...",
    "options": [
      "memutus sengketa kewenangan lembaga negara yang kewenangannya diberikan UUD",
      "memutus perselisihan tentang hasil pemilihan umum",
      "menguji peraturan perundang-undangan di bawah undang-undang terhadap undang-undang",
      "menguji undang-undang terhadap UUD",
      "memutus pembubaran partai politik"
    ],
    "answer": "C",
    "explanation": "Pengujian peraturan di bawah UU terhadap UU adalah wewenang Mahkamah Agung (Pasal 24A)."
  },
  {
    "id": 2611,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Lembaga negara yang anggotanya dipilih melalui pemilihan umum dari setiap provinsi dan berstatus perseorangan (bukan wakil partai politik) adalah ...",
    "options": [
      "Komisi Pemilihan Umum",
      "Dewan Perwakilan Daerah",
      "Majelis Permusyawaratan Rakyat",
      "Dewan Perwakilan Rakyat",
      "Badan Pemeriksa Keuangan"
    ],
    "answer": "B",
    "explanation": "DPD diatur Pasal 22C-22D; pesertanya perseorangan (Pasal 22E ayat 4)."
  },
  {
    "id": 2612,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Menurut Pasal 22E ayat (4), peserta pemilihan umum untuk memilih anggota DPR dan DPRD adalah partai politik, sedangkan peserta pemilu untuk memilih anggota DPD adalah ...",
    "options": [
      "kelompok kepentingan",
      "calon yang diusulkan fraksi di DPR",
      "partai politik lokal",
      "organisasi kemasyarakatan",
      "perseorangan"
    ],
    "answer": "E",
    "explanation": "Peserta pemilu DPD adalah perseorangan."
  },
  {
    "id": 2613,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Menurut Pasal 20 ayat (5) UUD NRI 1945, RUU yang telah disetujui bersama DPR dan Presiden tetapi tidak disahkan Presiden dalam waktu ... hari sejak disetujui sah menjadi undang-undang dan wajib diundangkan.",
    "options": [
      "empat belas",
      "tujuh",
      "enam puluh",
      "tiga puluh",
      "sembilan puluh"
    ],
    "answer": "D",
    "explanation": "Batas waktu pengesahan: 30 hari sejak RUU disetujui bersama."
  },
  {
    "id": 2614,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Peraturan Pemerintah Pengganti Undang-Undang (Perppu) yang ditetapkan Presiden dalam hal ihwal kegentingan yang memaksa harus ...",
    "options": [
      "mendapat persetujuan MPR dalam sidang tahunan",
      "diuji Mahkamah Agung sebelum berlaku",
      "mendapat persetujuan DPR dalam persidangan yang berikut",
      "disetujui seluruh fraksi di DPR sebelum ditetapkan",
      "mendapat pertimbangan DPD terlebih dahulu"
    ],
    "answer": "C",
    "explanation": "Pasal 22 ayat (2): Perppu harus mendapat persetujuan DPR pada persidangan berikutnya; jika tidak disetujui harus dicabut."
  },
  {
    "id": 2615,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Apabila DPR tidak menyetujui RAPBN yang diusulkan Presiden, maka Pemerintah menjalankan ...",
    "options": [
      "anggaran darurat yang ditetapkan MPR",
      "APBN-Perubahan tahun berjalan",
      "APBN tahun yang lalu",
      "anggaran minimal setengah dari RAPBN usulan",
      "RAPBN usulan Presiden tanpa persetujuan DPR"
    ],
    "answer": "C",
    "explanation": "Pasal 23 ayat (3) UUD NRI 1945."
  },
  {
    "id": 2616,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Putusan perubahan pasal-pasal UUD dilakukan dengan persetujuan sekurang-kurangnya ... dari seluruh anggota MPR.",
    "options": [
      "tiga perempat anggota",
      "separuh dari anggota yang hadir",
      "dua pertiga dari anggota yang hadir",
      "dua pertiga anggota",
      "lima puluh persen ditambah satu anggota"
    ],
    "answer": "E",
    "explanation": "Pasal 37 ayat (4); usul diajukan 1/3 anggota dan sidang dihadiri 2/3 anggota."
  },
  {
    "id": 2617,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Sidang MPR untuk memutuskan usul pemberhentian Presiden dihadiri sekurang-kurangnya ... jumlah anggota dan disetujui sekurang-kurangnya dua pertiga dari anggota yang hadir.",
    "options": [
      "satu per dua",
      "dua pertiga",
      "tiga per lima",
      "tiga perempat",
      "satu pertiga"
    ],
    "answer": "D",
    "explanation": "Pasal 7B ayat (7) UUD NRI 1945."
  },
  {
    "id": 2618,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Mahkamah Konstitusi wajib memeriksa, mengadili, dan memutus pendapat DPR tentang dugaan pelanggaran oleh Presiden paling lambat ... hari setelah permintaan diterima.",
    "options": [
      "sembilan puluh",
      "seratus delapan puluh",
      "tiga puluh",
      "enam puluh",
      "seratus dua puluh"
    ],
    "answer": "A",
    "explanation": "Pasal 7B ayat (4) UUD NRI 1945."
  },
  {
    "id": 2619,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Komisi Yudisial memiliki wewenang mengusulkan pengangkatan ...",
    "options": [
      "hakim agung",
      "hakim pengadilan negeri",
      "Jaksa Agung",
      "hakim konstitusi",
      "Ketua Mahkamah Konstitusi"
    ],
    "answer": "A",
    "explanation": "Pasal 24B ayat (1): mengusulkan pengangkatan hakim agung dan menjaga kehormatan serta perilaku hakim."
  },
  {
    "id": 2620,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Prinsip efisiensi berkeadilan, berkelanjutan, berwawasan lingkungan, kemandirian, serta menjaga keseimbangan kemajuan dan kesatuan ekonomi nasional terdapat pada Pasal 33 ayat ...",
    "options": [
      "(4)",
      "(3)",
      "(2)",
      "(1)",
      "(5)"
    ],
    "answer": "A",
    "explanation": "Ayat (4) ditambahkan pada perubahan keempat (2002)."
  },
  {
    "id": 2621,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Hak asasi yang menurut Pasal 28I ayat (1) UUD NRI 1945 tidak dapat dikurangi dalam keadaan apa pun adalah ...",
    "options": [
      "hak memperoleh pekerjaan dan imbalan yang layak",
      "hak atas lingkungan hidup yang baik dan sehat",
      "hak berkomunikasi dan memperoleh informasi",
      "hak untuk tidak dituntut atas dasar hukum yang berlaku surut",
      "hak berserikat, berkumpul, dan mengeluarkan pendapat"
    ],
    "answer": "D",
    "explanation": "Hak non-derogable di Pasal 28I(1): hidup, tidak disiksa, pikiran dan hati nurani, beragama, tidak diperbudak, diakui sebagai pribadi di hadapan hukum, tidak dituntut atas hukum berlaku surut."
  },
  {
    "id": 2622,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Pasal 31 ayat (4) UUD NRI 1945 mewajibkan negara memprioritaskan anggaran pendidikan sekurang-kurangnya ... persen dari APBN dan APBD.",
    "options": [
      "10",
      "20",
      "15",
      "30",
      "25"
    ],
    "answer": "B",
    "explanation": "Anggaran pendidikan minimal 20% dari APBN serta APBD."
  },
  {
    "id": 2623,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Ketentuan tentang Lagu Kebangsaan Indonesia Raya terdapat dalam Pasal ... UUD NRI 1945.",
    "options": [
      "36",
      "35",
      "36C",
      "36A",
      "36B"
    ],
    "answer": "E",
    "explanation": "Pasal 35 bendera; 36 bahasa; 36A lambang negara; 36B lagu kebangsaan; 36C pengaturan lebih lanjut dengan UU."
  },
  {
    "id": 2624,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Hak dan kewajiban warga negara dalam upaya pembelaan negara diatur dalam Pasal ...",
    "options": [
      "31 ayat (2)",
      "29 ayat (2)",
      "33 ayat (1)",
      "27 ayat (3)",
      "28 ayat (1)"
    ],
    "answer": "D",
    "explanation": "Pasal 27 ayat (3): setiap warga negara berhak dan wajib ikut serta dalam upaya pembelaan negara."
  },
  {
    "id": 2625,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Menurut Pasal 30 ayat (2) UUD NRI 1945, dalam sistem pertahanan dan keamanan rakyat semesta ...",
    "options": [
      "TNI dan pemerintah daerah sebagai kekuatan utama, Polri sebagai pendukung",
      "TNI sebagai kekuatan utama, Polri dan rakyat sebagai kekuatan pendukung",
      "rakyat sebagai kekuatan utama, TNI dan Polri sebagai kekuatan pendukung",
      "TNI dan Polri sebagai kekuatan utama, dan rakyat sebagai kekuatan pendukung",
      "Polri sebagai kekuatan utama, TNI sebagai kekuatan pendukung"
    ],
    "answer": "D",
    "explanation": "Sishankamrata dilaksanakan oleh TNI dan Polri sebagai kekuatan utama dengan rakyat sebagai kekuatan pendukung."
  },
  {
    "id": 2626,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Urutan hierarki peraturan perundang-undangan menurut UU No. 12 Tahun 2011 dari yang tertinggi adalah ...",
    "options": [
      "UUD 1945 - UU/Perppu - Tap MPR - PP - Perpres - Perda Provinsi - Perda Kabupaten/Kota",
      "Tap MPR - UUD 1945 - UU/Perppu - PP - Perpres - Perda Provinsi - Perda Kabupaten/Kota",
      "UUD 1945 - Tap MPR - UU/Perppu - Perpres - PP - Perda Provinsi - Perda Kabupaten/Kota",
      "UUD 1945 - Tap MPR - UU/Perppu - PP - Perpres - Perda Kabupaten/Kota - Perda Provinsi",
      "UUD 1945 - Tap MPR - UU/Perppu - PP - Perpres - Perda Provinsi - Perda Kabupaten/Kota"
    ],
    "answer": "E",
    "explanation": "Pasal 7 ayat (1) UU 12/2011."
  },
  {
    "id": 2627,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Urusan pemerintahan yang BUKAN menjadi kewenangan absolut Pemerintah Pusat menurut UU No. 23 Tahun 2014 adalah ...",
    "options": [
      "pertahanan",
      "pendidikan",
      "politik luar negeri",
      "agama",
      "yustisi"
    ],
    "answer": "B",
    "explanation": "Pendidikan termasuk urusan konkuren; enam urusan absolut: politik luar negeri, pertahanan, keamanan, yustisi, moneter dan fiskal nasional, agama."
  },
  {
    "id": 2628,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Pelimpahan wewenang oleh Pemerintah Pusat kepada gubernur sebagai wakil pemerintah pusat di daerah disebut ...",
    "options": [
      "dekonsentrasi",
      "otonomi seluas-luasnya",
      "desentralisasi",
      "sentralisasi",
      "tugas pembantuan"
    ],
    "answer": "A",
    "explanation": "Desentralisasi: penyerahan urusan ke daerah otonom; dekonsentrasi: pelimpahan kepada gubernur sebagai wakil pusat."
  },
  {
    "id": 2629,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Zona Ekonomi Eksklusif menurut UNCLOS 1982 (diratifikasi Indonesia dengan UU No. 17 Tahun 1985) paling jauh ... mil laut dari garis pangkal.",
    "options": [
      "350",
      "24",
      "200",
      "100",
      "12"
    ],
    "answer": "C",
    "explanation": "Laut teritorial 12 mil, zona tambahan 24 mil, ZEE 200 mil, landas kontinen paling jauh 350 mil."
  },
  {
    "id": 2630,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Substansi pokok Deklarasi Djuanda 13 Desember 1957 adalah ...",
    "options": [
      "Indonesia memiliki ZEE sejauh 200 mil laut",
      "kapal asing bebas berlayar di laut antarpulau tanpa izin",
      "lebar laut teritorial Indonesia tiga mil laut dari garis pantai",
      "Irian Barat merupakan bagian wilayah Indonesia",
      "laut di antara dan di sekitar pulau-pulau Indonesia merupakan bagian wilayah NKRI"
    ],
    "answer": "E",
    "explanation": "Deklarasi Djuanda melahirkan konsep negara kepulauan yang diakui UNCLOS 1982."
  },
  {
    "id": 2631,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Yang termasuk Tri Gatra (aspek alamiah) dalam Ketahanan Nasional adalah ...",
    "options": [
      "ideologi, politik, dan ekonomi",
      "sosial budaya, pertahanan keamanan, dan ekonomi",
      "geografi, kekayaan alam, dan kependudukan",
      "kekayaan alam, politik, dan pertahanan keamanan",
      "geografi, ideologi, dan kependudukan"
    ],
    "answer": "C",
    "explanation": "Asta Gatra = 3 gatra alamiah + 5 gatra sosial (ipoleksosbud-hankam)."
  },
  {
    "id": 2632,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Ketua Kongres Pemuda II (27-28 Oktober 1928) yang melahirkan Sumpah Pemuda adalah ...",
    "options": [
      "Soegondo Djojopoespito",
      "Amir Sjarifuddin",
      "Johannes Leimena",
      "Mohammad Yamin",
      "Wage Rudolf Supratman"
    ],
    "answer": "A",
    "explanation": "Yamin menjadi sekretaris, Amir Sjarifuddin bendahara; W.R. Supratman memperdengarkan Indonesia Raya."
  },
  {
    "id": 2633,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Ketua pertama organisasi Boedi Oetomo (1908) adalah ...",
    "options": [
      "Dr. Wahidin Soedirohoesodo",
      "Dr. Soetomo",
      "Dr. Tjipto Mangoenkoesoemo",
      "R.A.A. Tirtokoesoemo",
      "Ki Hajar Dewantara"
    ],
    "answer": "D",
    "explanation": "Dr. Soetomo adalah pendiri; ketua pertamanya Tirtokoesoemo, Bupati Karanganyar."
  },
  {
    "id": 2634,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Organisasi pertama di Hindia Belanda yang secara terbuka bercorak politik dan menuntut kemerdekaan adalah ...",
    "options": [
      "Muhammadiyah",
      "Indische Partij",
      "Boedi Oetomo",
      "Sarekat Dagang Islam",
      "Taman Siswa"
    ],
    "answer": "B",
    "explanation": "Indische Partij (1912) didirikan Tiga Serangkai: Douwes Dekker, Tjipto Mangoenkoesoemo, Soewardi Soerjaningrat."
  },
  {
    "id": 2635,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Naskah proklamasi kemerdekaan Indonesia yang dibacakan pada 17 Agustus 1945 diketik oleh ...",
    "options": [
      "Mohammad Hatta",
      "Achmad Soebardjo",
      "Sayuti Melik",
      "Soekarni",
      "Chairul Saleh"
    ],
    "answer": "C",
    "explanation": "Naskah ditulis tangan Soekarno dan diketik Sayuti Melik di rumah Laksamana Maeda."
  },
  {
    "id": 2636,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Peristiwa yang memicu ultimatum Inggris 9 November 1945 dan Pertempuran Surabaya 10 November 1945 adalah ...",
    "options": [
      "peristiwa Bandung Lautan Api",
      "pemberontakan Westerling di Bandung",
      "tewasnya Brigjen A.W.S. Mallaby pada 30 Oktober 1945",
      "insiden perobekan bendera di Hotel Yamato 19 September 1945",
      "Agresi Militer Belanda I"
    ],
    "answer": "C",
    "explanation": "Kematian Mallaby memicu ultimatum agar pemuda Surabaya menyerahkan senjata."
  },
  {
    "id": 2637,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Dalam Perjanjian Linggarjati, Belanda mengakui secara de facto wilayah RI yang meliputi ...",
    "options": [
      "Jawa, Madura, dan Sumatra",
      "Jawa dan Yogyakarta saja",
      "Jawa, Madura, dan Bali",
      "seluruh bekas Hindia Belanda",
      "Jawa, Sumatra, dan Kalimantan"
    ],
    "answer": "A",
    "explanation": "Linggarjati: pengakuan de facto Jawa, Madura, Sumatra serta pembentukan RIS."
  },
  {
    "id": 2638,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Dampak Perjanjian Renville bagi Republik Indonesia adalah ...",
    "options": [
      "Belanda mengakui kedaulatan RI atas seluruh Hindia Belanda",
      "RI memperoleh Sumatra dan Kalimantan",
      "wilayah RI menyempit karena harus mengakui Garis Van Mook dan menarik pasukan dari kantong-gerilya",
      "terbentuknya Uni Indonesia-Belanda",
      "Belanda menyerahkan Irian Barat kepada RI"
    ],
    "answer": "C",
    "explanation": "Renville (17 Januari 1948) merugikan RI; TNI hijrah dari wilayah kantong."
  },
  {
    "id": 2639,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Hasil Konferensi Meja Bundar (1949) yang TIDAK benar adalah ...",
    "options": [
      "Irian Barat diserahkan kepada RIS bersamaan dengan penyerahan kedaulatan",
      "dibentuk Uni Indonesia-Belanda",
      "RIS menanggung utang pemerintah Hindia Belanda",
      "penyelesaian Irian Barat ditunda satu tahun",
      "Belanda menyerahkan kedaulatan kepada RIS"
    ],
    "answer": "A",
    "explanation": "Status Irian Barat ditunda dan baru kembali ke RI tahun 1963."
  },
  {
    "id": 2640,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Isi Dekrit Presiden 5 Juli 1959 yang TIDAK benar adalah ...",
    "options": [
      "pembubaran Dewan Perwakilan Rakyat hasil Pemilu 1955",
      "berlakunya kembali UUD 1945",
      "pembubaran Konstituante",
      "pembentukan MPRS dan DPAS",
      "tidak berlakunya UUDS 1950"
    ],
    "answer": "A",
    "explanation": "Yang dibubarkan adalah Konstituante, bukan DPR hasil Pemilu 1955."
  },
  {
    "id": 2641,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Rumusan Tri Tuntutan Rakyat (Tritura) yang disuarakan Januari 1966 adalah ...",
    "options": [
      "bubarkan PKI, rombak Kabinet Dwikora, adakan pemilu segera",
      "bubarkan PKI, rombak Kabinet Dwikora, turunkan harga",
      "bubarkan Kabinet Dwikora, bubarkan MPRS, turunkan harga",
      "bubarkan PKI, adili Soekarno, turunkan harga",
      "bubarkan PKI, bubarkan DPR-GR, turunkan harga"
    ],
    "answer": "B",
    "explanation": "Tritura: bubarkan PKI, bersihkan kabinet dari unsur G30S/PKI, turunkan harga."
  },
  {
    "id": 2642,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Prinsip politik luar negeri bebas aktif dikemukakan Mohammad Hatta dalam pidato 'Mendayung di Antara Dua Karang' pada 2 September 1948 di hadapan ...",
    "options": [
      "Konstituante",
      "BP-KNIP",
      "Sidang Umum PBB",
      "sidang PPKI",
      "Konferensi Asia Afrika"
    ],
    "answer": "B",
    "explanation": "Pidato disampaikan di Badan Pekerja Komite Nasional Indonesia Pusat."
  },
  {
    "id": 2643,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Negara penyelenggara (sponsor) Konferensi Asia Afrika 1955 di Bandung adalah Indonesia bersama ...",
    "options": [
      "Thailand, Filipina, Malaysia, dan Singapura",
      "Burma, Ceylon, India, dan Pakistan",
      "Burma, India, Vietnam, dan Kamboja",
      "Tiongkok, Jepang, India, dan Pakistan",
      "Mesir, India, Yugoslavia, dan Ghana"
    ],
    "answer": "B",
    "explanation": "Lima negara sponsor KAA dikenal sebagai Lima Kolombo."
  },
  {
    "id": 2644,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Deklarasi Bangkok 8 Agustus 1967 yang melahirkan ASEAN ditandatangani menteri luar negeri dari ...",
    "options": [
      "Indonesia, Malaysia, Filipina, Brunei, dan Thailand",
      "Indonesia, Vietnam, Filipina, Singapura, dan Thailand",
      "Indonesia, Malaysia, Filipina, Singapura, dan Thailand",
      "Indonesia, Malaysia, Kamboja, Laos, dan Thailand",
      "Indonesia, Malaysia, Myanmar, Singapura, dan Thailand"
    ],
    "answer": "C",
    "explanation": "Lima pendiri ASEAN: Indonesia, Malaysia, Filipina, Singapura, Thailand."
  },
  {
    "id": 2645,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Cita-cita nasional 'merdeka, bersatu, berdaulat, adil dan makmur' terdapat pada Pembukaan UUD 1945 alinea ...",
    "options": [
      "kedua",
      "keempat",
      "tidak tercantum dalam Pembukaan",
      "ketiga",
      "pertama"
    ],
    "answer": "A",
    "explanation": "Alinea kedua memuat cita-cita menuju negara yang merdeka, bersatu, berdaulat, adil dan makmur."
  },
  {
    "id": 2646,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Menurut Ernest Renan, bangsa terbentuk terutama oleh ...",
    "options": [
      "kesamaan wilayah geografis semata",
      "kesamaan agama",
      "kesamaan bahasa",
      "kehendak untuk hidup bersama",
      "kesamaan ras dan keturunan"
    ],
    "answer": "D",
    "explanation": "Renan menyebut bangsa sebagai jiwa/asas kerohanian dan 'plebisit setiap hari'."
  },
  {
    "id": 2647,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Semboyan Bhinneka Tunggal Ika dikutip dari kitab Sutasoma karya ...",
    "options": [
      "Mpu Sindok",
      "Mpu Tantular",
      "Mpu Kanwa",
      "Mpu Panuluh",
      "Mpu Prapanca"
    ],
    "answer": "B",
    "explanation": "Mpu Prapanca menulis Negarakertagama; Mpu Tantular menulis Sutasoma."
  },
  {
    "id": 2648,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Pada lambang negara Garuda Pancasila, jumlah bulu pada ekor burung Garuda adalah ...",
    "options": [
      "8",
      "19",
      "5",
      "17",
      "45"
    ],
    "answer": "A",
    "explanation": "17 bulu sayap, 8 bulu ekor, 45 bulu leher melambangkan 17-8-45 (19 bulu pangkal ekor)."
  },
  {
    "id": 2649,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Ketentuan lebih lanjut tentang Bendera, Bahasa, dan Lambang Negara, serta Lagu Kebangsaan diatur dalam Undang-Undang Nomor ...",
    "options": [
      "17 Tahun 1985",
      "12 Tahun 2011",
      "23 Tahun 2014",
      "24 Tahun 2009",
      "3 Tahun 2002"
    ],
    "answer": "D",
    "explanation": "Amanat Pasal 36C UUD NRI 1945."
  },
  {
    "id": 2650,
    "moduleId": "twk2",
    "category": "TWK#2",
    "question": "Hak angket DPR adalah hak untuk ...",
    "options": [
      "memberhentikan Presiden dalam masa jabatannya",
      "mengajukan usul rancangan undang-undang",
      "meminta keterangan kepada pemerintah tentang kebijakan penting dan strategis",
      "melakukan penyelidikan terhadap pelaksanaan undang-undang atau kebijakan pemerintah yang penting, strategis, dan berdampak luas",
      "menyatakan pendapat atas kebijakan pemerintah atau kejadian luar biasa"
    ],
    "answer": "D",
    "explanation": "Pasal 20A: interpelasi (meminta keterangan), angket (penyelidikan), menyatakan pendapat."
  }
];
