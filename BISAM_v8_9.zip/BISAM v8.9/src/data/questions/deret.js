export const DERET = [
  {
    "id": 1501,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  8, 17, 30, 47, 68, 93, ... ?",
    "options": [
      "122",
      "104",
      "110",
      "140",
      "146"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pola kuadrat: 2n² + (3)n + (3); selisih tingkat dua tetap 4."
  },
  {
    "id": 1502,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  12, 23, 38, 57, 80, 107, ... ?",
    "options": [
      "138",
      "124",
      "131",
      "152",
      "117"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pola kuadrat: 2n² + (5)n + (5); selisih tingkat dua tetap 4."
  },
  {
    "id": 1503,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  11, 19, 31, 47, 67, 91, ... ?",
    "options": [
      "131",
      "113",
      "101",
      "119",
      "143"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Pola kuadrat: 2n² + (2)n + (7); selisih tingkat dua tetap 4."
  },
  {
    "id": 1504,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  9, 13, 19, 27, 37, 49, ... ?",
    "options": [
      "51",
      "69",
      "57",
      "60",
      "63"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Pola kuadrat: 1n² + (1)n + (7); selisih tingkat dua tetap 2."
  },
  {
    "id": 1505,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  -2, 4, 14, 28, 46, 68, ... ?",
    "options": [
      "104",
      "89",
      "109",
      "79",
      "94"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Pola kuadrat: 2n² + (0)n + (-4); selisih tingkat dua tetap 4."
  },
  {
    "id": 1506,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  4, 10, 18, 28, 40, 54, ... ?",
    "options": [
      "70",
      "66",
      "86",
      "82",
      "62"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pola kuadrat: 1n² + (3)n + (0); selisih tingkat dua tetap 2."
  },
  {
    "id": 1507,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  4, 14, 36, 76, 140, 234, ... ?",
    "options": [
      "400",
      "436",
      "364",
      "328",
      "292"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola n³ + (0)n² + (3)n; selisih tingkat tiga tetap 6."
  },
  {
    "id": 1508,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 20, 51, 104, 185, 300, ... ?",
    "options": [
      "432",
      "455",
      "547",
      "478",
      "409"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Pola n³ + (2)n² + (2)n; selisih tingkat tiga tetap 6."
  },
  {
    "id": 1509,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  6, 22, 54, 108, 190, 306, ... ?",
    "options": [
      "370",
      "554",
      "393",
      "416",
      "462"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Pola n³ + (2)n² + (3)n; selisih tingkat tiga tetap 6."
  },
  {
    "id": 1510,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  4, 12, 30, 64, 120, 204, ... ?",
    "options": [
      "370",
      "322",
      "274",
      "258",
      "338"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Pola n³ + (-1)n² + (4)n; selisih tingkat tiga tetap 6."
  },
  {
    "id": 1511,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  3, 4, 5, 8, 7, 16, 9, 32, ... ?",
    "options": [
      "13",
      "10",
      "9",
      "11",
      "12"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Dua deret berselang-seling: ganjil +2, genap ×2."
  },
  {
    "id": 1512,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  16, 2, 25, 6, 34, 18, 43, 54, ... ?",
    "options": [
      "52",
      "58",
      "61",
      "40",
      "46"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Dua deret berselang-seling: ganjil +9, genap ×3."
  },
  {
    "id": 1513,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  16, 4, 23, 8, 30, 16, 37, 32, ... ?",
    "options": [
      "42",
      "44",
      "36",
      "48",
      "40"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dua deret berselang-seling: ganjil +7, genap ×2."
  },
  {
    "id": 1514,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  12, 2, 17, 6, 22, 18, 27, ... ?",
    "options": [
      "66",
      "54",
      "48",
      "63",
      "57"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Dua deret berselang-seling: ganjil +5, genap ×3."
  },
  {
    "id": 1515,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  3, 3, 11, 6, 19, 12, 27, ... ?",
    "options": [
      "28",
      "27",
      "23",
      "24",
      "20"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Dua deret berselang-seling: ganjil +8, genap ×2."
  },
  {
    "id": 1516,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  6, 4, 15, 8, 24, 16, 33, ... ?",
    "options": [
      "24",
      "40",
      "32",
      "28",
      "36"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Dua deret berselang-seling: ganjil +9, genap ×2."
  },
  {
    "id": 1517,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  20, 4, 27, 8, 34, 16, 41, ... ?",
    "options": [
      "32",
      "24",
      "40",
      "38",
      "26"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Dua deret berselang-seling: ganjil +7, genap ×2."
  },
  {
    "id": 1518,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  7, 2, 10, 4, 13, 8, 16, ... ?",
    "options": [
      "14",
      "15",
      "12",
      "19",
      "16"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Dua deret berselang-seling: ganjil +3, genap ×2."
  },
  {
    "id": 1519,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  4, 13, 41, 126, 382, 1151, ... ?",
    "options": [
      "3632",
      "3459",
      "3286",
      "3113",
      "3805"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Pola ×3 + n dengan n bertambah 1 tiap langkah (+1, +2, +3, ...)."
  },
  {
    "id": 1520,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 16, 50, 153, 463, 1394, ... ?",
    "options": [
      "5024",
      "4815",
      "4606",
      "4397",
      "4188"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Pola ×3 + n dengan n bertambah 1 tiap langkah (+1, +2, +3, ...)."
  },
  {
    "id": 1521,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  2, 5, 12, 27, 58, 121, ... ?",
    "options": [
      "284",
      "200",
      "248",
      "272",
      "224"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola ×2 + n dengan n bertambah 1 tiap langkah (+1, +2, +3, ...)."
  },
  {
    "id": 1522,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 11, 24, 51, 106, 217, ... ?",
    "options": [
      "440",
      "396",
      "418",
      "484",
      "528"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Pola ×2 + n dengan n bertambah 1 tiap langkah (+1, +2, +3, ...)."
  },
  {
    "id": 1523,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  3, 5, 10, 18, 29, 43, ... ?",
    "options": [
      "60",
      "48",
      "69",
      "54",
      "51"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Setiap suku = 2×suku sebelumnya − suku sebelum itu + 3."
  },
  {
    "id": 1524,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  1, 4, 10, 19, 31, 46, ... ?",
    "options": [
      "61",
      "76",
      "67",
      "70",
      "64"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Setiap suku = 2×suku sebelumnya − suku sebelum itu + 3."
  },
  {
    "id": 1525,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 5, 15, 25, 55, 105, ... ?",
    "options": [
      "171",
      "182",
      "215",
      "259",
      "193"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Setiap suku = suku sebelumnya + 2×suku sebelum itu."
  },
  {
    "id": 1526,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  4, 6, 11, 18, 30, 49, ... ?",
    "options": [
      "68",
      "80",
      "96",
      "84",
      "72"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Setiap suku = dua suku sebelumnya + 1."
  },
  {
    "id": 1527,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  4, 8, 16, 32, 64, 128, ... ?",
    "options": [
      "256",
      "243",
      "282",
      "269",
      "295"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Setiap suku = suku sebelumnya + 2×suku sebelum itu."
  },
  {
    "id": 1528,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  0, 4, 18, 48, 100, 180, ... ?",
    "options": [
      "294",
      "264",
      "309",
      "234",
      "354"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Suku ke-n = n²(n−1)."
  },
  {
    "id": 1529,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  2, 10, 30, 68, 130, 222, ... ?",
    "options": [
      "368",
      "386",
      "296",
      "278",
      "350"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Suku ke-n = n³ + n."
  },
  {
    "id": 1530,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  2, 7, 24, 77, 238, 723, ... ?",
    "options": [
      "2180",
      "1744",
      "2289",
      "1853",
      "2616"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Suku ke-n = 3ⁿ − n."
  },
  {
    "id": 1531,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  3, 16, 45, 96, 175, 288, ... ?",
    "options": [
      "397",
      "507",
      "441",
      "485",
      "353"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Suku ke-n = n³ + 2n²."
  },
  {
    "id": 1532,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  3, 6, 11, 20, 37, 70, ... ?",
    "options": [
      "149",
      "156",
      "135",
      "128",
      "163"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Suku ke-n = 2ⁿ + n."
  },
  {
    "id": 1533,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 7, 11, 15, 23, 27, ... ?",
    "options": [
      "39",
      "27",
      "35",
      "33",
      "43"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola: 2p + 1 (2, 3, 5, 7, 11, 13, 17, ...)."
  },
  {
    "id": 1534,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  4, 9, 25, 49, 121, 169, ... ?",
    "options": [
      "247",
      "303",
      "289",
      "233",
      "345"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola: kuadrat bilangan prima (2, 3, 5, 7, 11, 13, 17, ...)."
  },
  {
    "id": 1535,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  2, 4, 7, 10, 15, 18, ... ?",
    "options": [
      "22",
      "20",
      "24",
      "23",
      "19"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Pola: prima ke-n ditambah n (2, 3, 5, 7, 11, 13, 17, ...)."
  },
  {
    "id": 1536,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  3, 7, 21, 14, 42, 46, 138, ... ?",
    "options": [
      "124",
      "152",
      "131",
      "145",
      "103"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Operasi berulang tiap 4 langkah: +4, ×3, −7, ×3."
  },
  {
    "id": 1537,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  7, 8, 16, 13, 26, 27, 54, ... ?",
    "options": [
      "51",
      "39",
      "48",
      "60",
      "57"
    ],
    "answer": "A",
    "explanation": "Jawaban yang benar adalah A. Operasi berulang tiap 4 langkah: +1, ×2, −3, ×2."
  },
  {
    "id": 1538,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 14, 28, 25, 75, 84, 168, ... ?",
    "options": [
      "197",
      "165",
      "189",
      "149",
      "157"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Operasi berulang tiap 4 langkah: +9, ×2, −3, ×3."
  },
  {
    "id": 1539,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 14, 42, 35, 105, 114, 342, ... ?",
    "options": [
      "369",
      "386",
      "301",
      "267",
      "335"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Operasi berulang tiap 4 langkah: +9, ×3, −7, ×3."
  },
  {
    "id": 1540,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  2, 5, 10, 5, 15, 18, 36, ... ?",
    "options": [
      "29",
      "37",
      "35",
      "31",
      "39"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Operasi berulang tiap 4 langkah: +3, ×2, −5, ×3."
  },
  {
    "id": 1541,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  1, 4, 10, 20, 35, 56, ... ?",
    "options": [
      "100",
      "72",
      "84",
      "68",
      "76"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola: bilangan tetrahedral n(n+1)(n+2)/6."
  },
  {
    "id": 1542,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  1, 4, 9, 16, 25, 36, ... ?",
    "options": [
      "47",
      "41",
      "49",
      "57",
      "53"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola: n(n+1) − n = n²."
  },
  {
    "id": 1543,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  2, 5, 9, 14, 20, 27, ... ?",
    "options": [
      "37",
      "29",
      "35",
      "31",
      "39"
    ],
    "answer": "C",
    "explanation": "Jawaban yang benar adalah C. Pola: Tn + n dengan Tn = n(n+1)/2."
  },
  {
    "id": 1544,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  9, 10, 13, 19, 29, 44, ... ?",
    "options": [
      "77",
      "65",
      "74",
      "53",
      "56"
    ],
    "answer": "B",
    "explanation": "Jawaban yang benar adalah B. Selisih antarsuku adalah bilangan segitiga 1, 3, 6, 10, ..."
  },
  {
    "id": 1545,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  6, 7, 8, 10, 13, 18, ... ?",
    "options": [
      "27",
      "28",
      "29",
      "26",
      "22"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Selisih antarsuku adalah deret Fibonacci 1, 1, 2, 3, 5, ..."
  },
  {
    "id": 1546,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  5, 6, 9, 15, 25, 40, ... ?",
    "options": [
      "70",
      "58",
      "49",
      "64",
      "61"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Selisih antarsuku adalah bilangan segitiga 1, 3, 6, 10, ..."
  },
  {
    "id": 1547,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  2, 3, 4, 6, 9, 14, ... ?",
    "options": [
      "26",
      "23",
      "25",
      "24",
      "22"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Selisih antarsuku adalah deret Fibonacci 1, 1, 2, 3, 5, ..."
  },
  {
    "id": 1548,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  572, 284, 140, 68, 32, 14, ... ?",
    "options": [
      "9",
      "7",
      "6",
      "5",
      "8"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Setiap suku = (suku sebelumnya − 4) : 2."
  },
  {
    "id": 1549,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  3644, 1214, 404, 134, 44, 14, ... ?",
    "options": [
      "3",
      "7",
      "2",
      "4",
      "5"
    ],
    "answer": "D",
    "explanation": "Jawaban yang benar adalah D. Setiap suku = (suku sebelumnya − 2) : 3."
  },
  {
    "id": 1550,
    "moduleId": "deret",
    "category": "Deret Angka",
    "question": "Tentukan angka yang melengkapi deret berikut:  318, 158, 78, 38, 18, 8, ... ?",
    "options": [
      "5",
      "2",
      "4",
      "-1",
      "3"
    ],
    "answer": "E",
    "explanation": "Jawaban yang benar adalah E. Setiap suku = (suku sebelumnya − 2) : 2."
  }
];
