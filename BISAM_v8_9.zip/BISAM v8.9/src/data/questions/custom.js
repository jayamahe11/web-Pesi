/**
 * CUSTOM.JS  —  SOAL & MODUL BUATAN ADMIN (versi kode)
 * ------------------------------------------------------------------
 * File ini dibuat OTOMATIS dari soal yang diketik manual lewat web
 * (Admin > Kelola Soal / Kelola Modul). Jangan khawatir soal manual hilang:
 * selama file ini ikut tersimpan, semua soal manual ada di dalam kode.
 *
 * Arah sinkronisasi:
 *   Web (Firestore) -> kode : npm run export:custom   atau tombol "Unduh kode soal manual"
 *   Kode -> Web (Firestore) : npm run import:custom
 *
 * Kamu juga boleh menambah/mengedit soal langsung di file ini, lalu jalankan
 * `npm run import:custom` supaya muncul di web. Pakai id yang unik
 * (mis. "q-ku-001") — id yang sama akan MENIMPA soal dengan id itu.
 *
 * Field "image" boleh berisi path file (mis. "/public/assets/questions/custom/q-ku-001.jpg")
 * atau data URL (data:image/...;base64,...).
 *
 * Terakhir dibuat : (belum pernah diekspor)
 * Jumlah          : 0 modul, 0 soal
 */

export const CUSTOM_MODULES = [];

export const CUSTOM_QUESTIONS = [];
